#!/usr/bin/env python3
"""Coordinator gate: native review must actually receive the local MCP result."""
import json
from pathlib import Path

base = Path('/Users/alectaggart/orc/.fusion/evaluations/oasis-district-001')
workspace = Path('/Users/alectaggart/Oasis')
log = base / 'claude-mcp-calls.jsonl'
assert log.is_file(), 'No actual MCP exchange recorded'
rows = [json.loads(line) for line in log.read_text().splitlines()]
requests = {row['message']['id']: row['message'] for row in rows if row['direction'] == 'request'}
matched = []
for row in rows:
    if row['direction'] != 'response':
        continue
    response = row['message']
    request = requests.get(response.get('id'))
    if not request or request.get('params', {}).get('arguments', {}).get('run_id') != 'oasis-district-001':
        continue
    assert not response.get('error'), response
    result = response['result']
    assert not result.get('isError'), result
    status = json.loads(result['content'][0]['text'])
    assert status['run_id'] == 'oasis-district-001'
    assert status['status'] == 'succeeded' and status['terminal']
    for phase in ['request', 'result']:
        expected = json.loads((workspace / '.tenet/recipe-runs/oasis-district-001' / (phase+'.json')).read_text())
        assert status[phase] == expected, 'MCP differs from authoritative '+phase
    matched.append({'request_id': response['id'], 'run_id': status['run_id'],
                    'status': status['status'], 'terminal': status['terminal'],
                    'request_and_result_equal_authoritative_files': True})
assert matched, 'No successful native recipe_status exchange matched the task'
print(json.dumps({'schema': 'tenet.dogfood.native-mcp-verification.v1', 'passed': True, 'exchanges': matched}))
