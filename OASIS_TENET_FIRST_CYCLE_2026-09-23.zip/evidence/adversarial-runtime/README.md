# Independent Oasis runtime audit

`probe.py` preserves the reconstructed original inline probe. `run.py` reruns
it, records source hashes before and after, and writes `receipt.json`,
`stdout.log`, and `stderr.log`. This is a new evidence-capturing execution, not
a retroactive receipt for the earlier inline run.

```sh
python3 -B /Users/alectaggart/orc/.fusion/evaluations/oasis-district-001/adversarial-runtime/run.py
```

The probe independently calculates the expected state, prices and digest over
37 accepted commands, then checks three export/replay generations and 111
historical command retries. It also terminates real subprocesses with
`os._exit(77)` after receipt insertion and before commit for initialization,
activation, interaction and replay; it checks rollback and identical retries.
Databases live in an automatically cleaned system temporary directory. Oasis
source files are read only; bytecode writing is disabled.

This establishes the observed local API and process-crash behavior. It does not
establish machine/power-loss durability, load capacity, distributed ownership or
authorization. Import-operation receipts remain destination-local under the
frozen export format; original world-event command IDs survive replay. The
deterministic generated workload is a bounded probe, not exhaustive fuzzing.
