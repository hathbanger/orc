import copy, hashlib, json, os, random, sqlite3, subprocess, sys, tempfile
from pathlib import Path
from oasis_runtime import OasisError, Runtime

content=json.loads(Path('content/harbor.json').read_text())
behavior=json.loads(Path('content/behavior-v1.json').read_text())
world='audit-world'
init={'op':'init','world_id':world,'command_id':'init','content':content,'behavior':behavior}
def command(op,**kwargs): return {'op':op,'world_id':world,**kwargs}
def run(db,c):
    with Runtime(db) as runtime: return runtime.execute(c)
def export(db): return run(db,command('export'))
receipt={}
with tempfile.TemporaryDirectory(prefix='oasis-independent-audit-') as td:
    td=Path(td); source=td/'source.sqlite'
    history=[(init,run(source,init))]
    rng=random.Random(923)
    relationships={}; active=copy.deepcopy(behavior)
    for i in range(36):
        if i in (8,21):
            active={**active,'version':active['version']+1,'rescue_trust':3,'trust_discount':2,'debt_surcharge':5}
            c=command('activate',command_id=f'activate-{i}',behavior=active)
            history.append((c,run(source,c)))
            continue
        player=rng.choice(['alice','zoë\x00雪']); npc=rng.choice(['mara','ivo'])
        key=(player,npc); r=relationships.setdefault(key,{'revision':0,'trust':0,'debt':0,'event_ids':[]})
        action=rng.choice(['rescue','borrow','repay'] if r['debt'] else ['rescue','borrow'])
        c=command('interact',command_id=f'c{i}',player_id=player,npc_id=npc,expected_revision=r['revision'],action=action)
        if action=='borrow': c['amount']=rng.randint(1,7);r['debt']+=c['amount']
        elif action=='repay': c['amount']=rng.randint(1,r['debt']);r['debt']-=c['amount']
        else:r['trust']+=active['rescue_trust']
        r['revision']+=1;r['event_ids'].append(c['command_id'])
        result=run(source,c);history.append((c,result))
        base=next(n['base_price'] for n in content['npcs'] if n['id']==npc)
        assert result['price']==max(1,base-r['trust']*active['trust_discount']+(active['debt_surcharge'] if r['debt'] else 0))
        assert {k:result[k] for k in r}==r
    snap=export(source)
    expected={'world_id':world,'content':content,'behavior':active,'relationships':[{'player_id':p,'npc_id':n,**relationships[(p,n)]} for p,n in sorted(relationships)]}
    assert snap['state']==expected
    assert snap['state_digest']==hashlib.sha256(json.dumps(expected,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
    for cycle in range(3):
        target=td/f'replayed-{cycle}.sqlite'
        run(target,command('replay',command_id=f'restore-{cycle}',snapshot=snap))
        assert export(target)==snap
        for old,result in history: assert run(target,old)==result
        snap=export(target)
    receipt['independent_state_and_replay']={'commands':len(history),'replay_generations':3,'historical_retries':len(history)*3,'passed':True}

    child='''import json,os,sys\nfrom oasis_runtime import Runtime\nclass Crash(Runtime):\n def _record_receipt(self,command,result_json):\n  super()._record_receipt(command,result_json)\n  if command["command_id"]==sys.argv[2]: os._exit(77)\nwith Crash(sys.argv[1]) as runtime: runtime.execute(json.loads(sys.stdin.read()))\n'''
    cases=[('initialize',td/'init-crash.sqlite',init),('activate',source,command('activate',command_id='crash-activate',behavior={**active,'version':active['version']+1})),('interact',source,command('interact',command_id='crash-interact',player_id='new-player',npc_id='mara',expected_revision=0,action='rescue')),('replay',td/'import-crash.sqlite',command('replay',command_id='crash-replay',snapshot=snap))]
    for name,db,c in cases:
        before=export(db) if db==source else None
        p=subprocess.run([sys.executable,'-c',child,str(db),c['command_id']],input=json.dumps(c),text=True,capture_output=True,timeout=10)
        assert p.returncode==77,(name,p.returncode,p.stderr)
        if before is not None: assert export(db)==before
        else:
            with sqlite3.connect(db) as conn:
                assert all(conn.execute('SELECT COUNT(*) FROM '+table).fetchone()[0]==0 for table in ('worlds','events','receipts'))
        first=run(db,c);assert run(db,c)==first
    receipt['hard_process_exit_after_receipt_write']={'operations':[x[0] for x in cases],'rollback_and_retry_passed':True}
print(json.dumps(receipt,indent=2))
