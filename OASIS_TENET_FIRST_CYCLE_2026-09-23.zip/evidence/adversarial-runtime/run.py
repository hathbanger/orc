"""Capture the retained independent probe without writing into Oasis."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
WORKSPACE = Path("/Users/alectaggart/Oasis")
PROBE = ROOT / "probe.py"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sources():
    paths = sorted((WORKSPACE / "oasis_runtime").glob("*.py"))
    paths += sorted((WORKSPACE / "content").glob("*.json"))
    paths += [WORKSPACE / "specs/001-persistent-district.md", WORKSPACE / "runtime/README.md"]
    return {str(path.relative_to(WORKSPACE)): sha256(path) for path in paths}


def main():
    before = sources()
    argv = [sys.executable, "-B", str(PROBE)]
    overrides = {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONPATH": str(WORKSPACE), "PYTHONOPTIMIZE": "0"}
    environment = {**os.environ, **overrides}
    started_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
    start = time.monotonic()
    run = subprocess.run(argv, cwd=WORKSPACE, env=environment, text=True,
                         capture_output=True, timeout=60)
    (ROOT / "stdout.log").write_text(run.stdout)
    (ROOT / "stderr.log").write_text(run.stderr)
    after = sources()
    try:
        checks = json.loads(run.stdout)
    except ValueError:
        checks = None
    passed = run.returncode == 0 and before == after and checks is not None
    receipt = {
        "schema": "oasis.adversarial-runtime-probe.v1",
        "started_at": started_at,
        "duration_seconds": time.monotonic() - start,
        "argv": argv,
        "cwd": str(WORKSPACE),
        "environment_overrides": overrides,
        "python_version": platform.python_version(),
        "probe_sha256": sha256(PROBE),
        "runner_sha256": sha256(Path(__file__)),
        "source_sha256_before": before,
        "source_sha256_after": after,
        "source_unchanged": before == after,
        "exit_code": run.returncode,
        "passed": passed,
        "checks": checks,
        "stdout": {"path": str(ROOT / "stdout.log"), "sha256": sha256(ROOT / "stdout.log")},
        "stderr": {"path": str(ROOT / "stderr.log"), "sha256": sha256(ROOT / "stderr.log")},
        "scope": "Independent finite state/price/digest oracle; multi-generation replay and historical retries; forced process exits after receipt insertion before transaction commit.",
        "limitations": [
            "This retains a reconstruction of the exact prior inline probe and records a fresh execution; it is not a receipt retroactively captured from that earlier execution.",
            "Process-crash rollback is tested; OS crash, power-loss durability, storage hardware and distributed execution are not.",
            "Import-operation receipts are destination-local and not exported; original world-event command IDs survive replay.",
            "This is a bounded deterministic local API probe, not exhaustive input fuzzing, a load test or authentication testing.",
            "Only temporary databases are created; no Oasis source files are modified."
        ],
    }
    (ROOT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"passed": passed, "receipt": str(ROOT / "receipt.json"), "checks": checks}, indent=2))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
