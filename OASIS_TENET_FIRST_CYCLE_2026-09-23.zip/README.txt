First working TENET → ORC → native Codex Oasis cycle.

Read OASIS_DOGFOOD_RUN_2026-09-23.md and Oasis-START_HERE.md.
Patches are scoped to the source files changed in this cycle; source-handoff.json records their base revisions and hashes.
Oasis is committed locally; ORC and TENET patches describe existing working-tree changes.
Evidence JSON references full local artifacts; this bundle intentionally contains selected receipts, not all native transcripts or all previous research.
Paths in this local pilot refer to the original machine.
