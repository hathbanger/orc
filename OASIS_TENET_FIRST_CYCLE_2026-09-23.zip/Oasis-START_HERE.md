# Oasis: first working district

The completed research now has a runnable state prototype. Harbor and Orchard
share a Python/SQLite runtime. NPC relationships affect offers, survive restart,
and can be reconstructed from validated event history. Behavior versions change
future offers while preserving historical results and command deduplication.

## Try it

From `/Users/alectaggart/Oasis`:

```sh
python3 -m oasis_runtime.demo --db runtime/my-district.sqlite
```

Enter `rescue`, `borrow 7`, `repay 7`, `player bob`, then `player alice`.
Enter `activate content/behavior-v2.json` to change the offer policy.
Quit and reopen the same database to see the persisted relationships.
Use `history` to inspect the commands behind the current state.

Read [runtime instructions](runtime/README.md), the [frozen increment
contract](specs/001-persistent-district.md), and the existing
[platform thesis](research/PLATFORM_THESIS.md).

## Inspect the TENET build

The actual implementation ran through TENET → ORC/Fusion → native Codex.
The [recorded build inputs](dogfood/recorded-config/README.md) preserve the local
workflow and recipes separately from private run traces.
These commands inspect and reconcile that completed run; reconciliation does
not start another worker:

```sh
tenet recipe status oasis-district-001 --json
tenet recipe sync oasis-district-001 --json
```

The MCP tool `recipe_status({"run_id":"oasis-district-001"})` reads the same
request/result when its server starts in this workspace. The original receipts
are in [.tenet/recipe-runs/oasis-district-001](.tenet/recipe-runs/oasis-district-001).
The accepted workflow is in [.fusion/workflows/oasis-district-001](.fusion/workflows/oasis-district-001).
The independently maintained evaluator and run evidence are in
[/Users/alectaggart/orc/.fusion/evaluations/oasis-district-001](/Users/alectaggart/orc/.fusion/evaluations/oasis-district-001).

The build passed 15 coordinator acceptance tests and 22 implementation tests.
An additional audit exercised repeated replay, historical retries and process
crashes before commit. The first workflow revalidation passed without launching
another coding worker. These are local correctness results; performance,
multiplayer, authentication and a game client remain future increments.

## Continue the product loop

Use a new task/run ID for each new increment. Preserve the request, frozen
acceptance contract, candidate hashes, actual harness trace, acceptance receipt,
and a short account of product friction. Repair only the TENET/ORC issue the
increment exposes, then verify the same failing case and a fresh case.

The next Oasis increment should make this district visible and consequential:
a small client with two players, an NPC offer/history view, and a bounded quest
whose outcome persists through reconnect and a behavior update. Keep the state
contract behind that client. The corresponding TENET increment is a run view
showing execution, acceptance, artifacts and state reconciliation separately.

The recorded implementation success is useful engineering evidence. One public
spec with visible tests is not enough to qualify a learned router or train a
model. Keep engineering outcomes separate from future NPC/gameplay data, and
collect held-out tasks and genuine failures before evaluating training.
