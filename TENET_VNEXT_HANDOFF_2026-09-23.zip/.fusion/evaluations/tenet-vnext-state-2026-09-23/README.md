# TENET vNext state boundary evidence — September 23, 2026

Observed CLI revision: `b0ec9c4b3e26fcc16c6fec697a31c41994f2e172`.

- `probe.mts`: isolated behavioral experiments importing actual CLI TypeScript modules.
- `receipt.json`: observed results from the reviewed revision, including seven contract failures.
- `test-log.txt`: captured output of the existing 205-test state/migration suite, which passed.
- `manifest.json`: reviewed revision, source-file hashes and artifact hashes.

No production source, configuration or data was changed. No cloud/model requests or credentials were used. Queue failures are latent defects in a component with no production callers found; these experiments do not establish current production data loss.

The probe creates a fresh `data-*` fixture directory beside itself and overwrites only its `receipt.json`. Original receipt paths refer to the temporary fixture used during review. The archived script changes only the artifact-directory handling so future artifacts stay together.

## Reproduce

The source files are **not archived here**. The probe imports the current checkout at `/Users/alectaggart/CascadeProjects/tenet-cli`. Therefore a later rerun can test changed code; compare the source hashes in `manifest.json` before treating results as a reproduction of the original revision. Dependencies come from that checkout.

```sh
cd /Users/alectaggart/CascadeProjects/tenet-cli
./node_modules/.bin/tsx /Users/alectaggart/orc/.fusion/evaluations/tenet-vnext-state-2026-09-23/probe.mts
./node_modules/.bin/vitest run src/lib/state-store/__tests__ src/lib/workspace/__tests__/link-migrate.test.ts
```

Successful script execution means the scenarios ran, not that the product passed them. Inspect coherence versus actual stream membership, migration counts, queue visibility/recovery, schema versions, portfolio visibility and corruption recovery in the receipt. Copy the original receipt before rerunning if comparison is needed.

To verify the current source checkout against recorded hashes without executing product code:

```sh
python3 - <<'PYVERIFY'
from pathlib import Path
import hashlib, json
p = Path('/Users/alectaggart/orc/.fusion/evaluations/tenet-vnext-state-2026-09-23/manifest.json')
m = json.loads(p.read_text())
root = Path(m['source_root'])
for rel, expected in m['source_sha256'].items():
    f = root / rel
    actual = hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None
    print('MATCH' if actual == expected else 'CHANGED', rel)
PYVERIFY
```
