// Isolated execution of the checked-in producer with fake HOME-scoped inputs.
// No network, models, real user buffers, or production files are touched.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const vm = require('node:vm');
const ts = require('/Users/alectaggart/CascadeProjects/tenet-cli/node_modules/typescript');
const repo = '/Users/alectaggart/CascadeProjects/tenet-cli';
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tenet-training-probe-'));
const fakeHome = path.join(root, 'fixture-home');
const project = path.join(root, 'project');
fs.mkdirSync(path.join(fakeHome, '.tenet'), { recursive: true });
fs.mkdirSync(path.join(project, '.tenet'), { recursive: true });
const surfaceInput = {
  v: 1, ts: '2026-09-23T00:00:00Z', surface_identity: 'refactor-safety-reviewer',
  surface_type: 'review', reward_source: 'synthetic-fixture',
  state: { preLineCount: 10, preExports: ['f'], preEvalScore: 0.5 },
  action: { type: 'approve', rationale: 'Fixture approval, action never executed' },
  reward: 0.75, outcome: { testsHeld: true },
  metadata: { synthesized_outcome: true, driver: 'rl-surface fire', picker: 'explore' },
};
const askInput = {
  ts: '2026-09-23T00:01:00Z', task: 'Fixture question without an observed correctness result',
  completion_tokens: 500, briefing_used: true, briefing_n_kept: 2,
  briefing_tokens: 100, prompt_tokens: 200, duration_ms: 150,
};
fs.writeFileSync(path.join(fakeHome, '.tenet', 'rl-surface-buffer.jsonl'), JSON.stringify(surfaceInput) + '\n');
fs.writeFileSync(path.join(fakeHome, '.tenet', 'qwen-ask-buffer.jsonl'), JSON.stringify(askInput) + '\n');
const file = path.join(repo, 'src/commands/train-combine.ts');
const compiled = ts.transpileModule(fs.readFileSync(file, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true },
}).outputText;
const fakeChalk = new Proxy(x => x, { get: () => x => x });
const exportsObject = {};
const logs = [];
const context = {
  exports: exportsObject,
  process: { cwd: () => project },
  console: { log: (...args) => logs.push(args.join(' ')) },
  require: name => name === 'os' ? { homedir: () => fakeHome }
    : name === 'chalk' ? { __esModule: true, default: fakeChalk } : require(name),
};
vm.runInNewContext(compiled, context, { filename: file });
(async () => {
  const out = path.join(root, 'combined.jsonl');
  await exportsObject.trainCombineCommand({ out });
  const rows = fs.readFileSync(out, 'utf8').trim().split('\n').map(JSON.parse);
  const result = {
    revision: 'b0ec9c4b3e26fcc16c6fec697a31c41994f2e172',
    isolated_workspace: root, fixture_inputs: { surfaceInput, askInput }, projected_rows: rows,
    assertions: {
      all_targets_present_in_pre_action_state: rows.every(r => r.state.recent_deltas[0] === r.reward.composite_delta),
      original_synthetic_marker: surfaceInput.metadata.synthesized_outcome,
      projected_synthetic_marker_absent: !('synthesized_outcome' in rows[0].metadata),
      projected_outcome_absent: !('outcome' in rows[0]),
      projected_settlement_absent: rows.every(r => !('tuple_status' in r.reward)),
      invented_surface_quality_dimensions: rows[0].state.dimension_scores,
      ask_reward_depends_on_response_length: rows[1].reward.composite_delta === Math.tanh((askInput.completion_tokens - 100) / 200),
    }, logs,
  };
  fs.writeFileSync(path.join(__dirname, 'training-probe.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result.assertions, null, 2));
})();
