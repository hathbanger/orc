"""Exercise the repository's own acceptance fixture; no real harness/model calls."""
import contextlib
import io
import json
from pathlib import Path
import sys

REPO = Path('/Users/alectaggart/orc')
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / 'test'))
from fusion_test import FusionHarnessTest
from fusion_labeling import council_consensus
from fusion_core import mcp_result, tool_definitions

cases = []
for name, git, writes in [('git_no_change', True, False), ('git_unrelated_file_only', True, True), ('non_git_no_change', False, False)]:
    fixture = FusionHarnessTest()
    fixture.setUp()
    try:
        if git:
            fixture.git_workspace()
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            result = fixture.write_node_workflow(writes=writes)
        cases.append({
            'case': name, 'status': result['status'], 'node': result['nodes'][0],
            'written_content': (fixture.workspace / 'made.txt').read_text() if writes else None,
        })
    finally:
        fixture.tearDown()
        fixture.doCleanups()

members = [{
    'requested_agent': agent, 'status': 'success', 'model': 'identical-model-fixture',
    'answers': {'q': {'value': 'true', 'reason': 'Fixture', 'evidence': ['E1']}},
} for agent in ['codex', 'claude']]
report = {
    'revision': '1f21ac9a002b46ad715e43880f6a0023e297f6c4',
    'acceptance_cases': cases,
    'same_model_different_harness_council': council_consensus({'questions': {'q': {}}}, members),
    'mcp_tool_count': len(tool_definitions()),
    'mcp_status_structured_content_type': type(mcp_result([])['structuredContent']).__name__,
}
Path(__file__).with_name('orc-probe.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({
    'acceptance': [{k: c[k] for k in ('case', 'status')} for c in cases],
    'same_model_council_agreed': report['same_model_different_harness_council']['questions']['q']['state'],
    'mcp_tool_count': report['mcp_tool_count'],
    'mcp_structured_type': report['mcp_status_structured_content_type'],
}, indent=2))
