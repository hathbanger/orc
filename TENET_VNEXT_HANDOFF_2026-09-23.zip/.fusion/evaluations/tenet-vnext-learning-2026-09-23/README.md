# TENET vNext learning/harness evidence

Captured 2026-09-23 against ORC `1f21ac9a002b46ad715e43880f6a0023e297f6c4` and TENET CLI `b0ec9c4b3e26fcc16c6fec697a31c41994f2e172`. These are the reviewed source revisions, not a claim about current checkout HEAD. [manifest.json](manifest.json) records reviewed-source hashes, current hashes at archive time, script/result SHA-256 hashes and exact scope.

## Rerun

Run from `/Users/alectaggart/orc`:

```sh
node .fusion/evaluations/tenet-vnext-learning-2026-09-23/probe-training.cjs
node .fusion/evaluations/tenet-vnext-learning-2026-09-23/probe-runtime.cjs
PYTHONDONTWRITEBYTECODE=1 python3 .fusion/evaluations/tenet-vnext-learning-2026-09-23/probe-orc.py
```

**These scripts import/transpile the current source at their hardcoded absolute repo paths.** They do not check out the reviewed revisions. Their JSON `revision` fields are historical literal labels; those labels must be updated or disregarded when rerunning against newer source. Reruns overwrite the corresponding JSON result. Preserve this directory elsewhere first if retaining the original evidence matters. Use the reviewed commit objects and manifest hashes to compare source before interpreting differences; this manifest describes the archived files, not future reruns.

The JavaScript probes use TENET's installed TypeScript transpiler. The Python probe uses ORC's existing test fixture. No dependency installation is part of these commands.

| Script / result | Scope |
|---|---|
| [probe-training.cjs](probe-training.cjs) / [training-probe.json](training-probe.json) | Transpiles actual `train-combine.ts`; creates two synthetic input rows in a new temporary directory; injects fake home/cwd without changing real environment or user buffers; demonstrates target leakage, invented quality dimensions and lost synthetic provenance |
| [probe-runtime.cjs](probe-runtime.cjs) / [runtime-probe.json](runtime-probe.json) | Transpiles actual runtime, policy-head and tool-schema source; injects in-memory checkpoints, fake credentials and mocked fetch; verifies lost answer, embedding mismatch, reward/class-confidence conflation, runtime inventory and MCP schema count |
| [probe-orc.py](probe-orc.py) / [orc-probe.json](orc-probe.json) | Uses ORC's existing temporary-repository/fake-worker fixture; disables remote telemetry and decisions through that fixture; probes acceptance, council agreement and MCP output shape |
| [laya-summary.json](laya-summary.json) | Read-only snapshot of this workspace's existing learning records, computed through `learning_summary`; no classifier inference/training was run |

No external API/model calls, paid harness runs, installs, persistent MCP registration or production source/configuration changes were made. Temporary fixture repositories and files are local only. The runtime probe never sends its fake key anywhere; fetch is mocked. The ORC fake worker is a Python fixture executable, not Codex or another native harness.

To refresh the Laya snapshot deliberately, run the following from the ORC checkout. This reads the current workspace/configuration and overwrites the archived summary:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 - <<'PY'
import json
from pathlib import Path
from fusion_core import load_config
from fusion_learning import learning_summary
root = Path.cwd()
config, _ = load_config(root)
summary = learning_summary(root, config)
(root / '.fusion/evaluations/tenet-vnext-learning-2026-09-23/laya-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
PY
```

Six focused ORC acceptance/one-way-classifier tests and 67 TENET runtime/policy/MCP/spawnable-runtime tests passed during the review. Their output exists in the session tool transcript; no raw test-log files were saved. Tests were not repeated merely to create logs. The companion [analysis report](/Users/alectaggart/orc/TENET_VNEXT_LEARNING_HARNESS_ANALYSIS_2026-09-23.md) distinguishes passing tests, controlled reproductions and untested product claims.
