// Executes checked-in TS modules with in-memory filesystem/network dependencies.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('/Users/alectaggart/CascadeProjects/tenet-cli/node_modules/typescript');
const repo = '/Users/alectaggart/CascadeProjects/tenet-cli';
function load(relative, overrides = {}) {
  const filename = path.join(repo, relative);
  const source = fs.readFileSync(filename, 'utf8').replaceAll('import.meta.url', JSON.stringify('file://' + filename));
  const compiled = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, esModuleInterop: true },
  }).outputText;
  const output = {};
  vm.runInNewContext(compiled, {
    exports: output, require, process: { env: {}, cwd: () => '/fixture' },
    console, AbortSignal, ...overrides,
  }, { filename });
  return output;
}
(async () => {
  const responseSentinel = 'THIS_IS_THE_ACTUAL_ANSWER';
  const local = load('src/lib/agent-runtime-local.ts', {
    fetch: async () => ({ ok: true, json: async () => ({
      choices: [{ message: { content: responseSentinel } }],
      usage: { prompt_tokens: 5, completion_tokens: 8 },
    }) }),
  });
  const localResult = await local.runAgentViaLocal({ task: 'Say the answer', cwd: '/fixture' });
  const schemas = load('src/lib/tool-schemas.ts');
  const runtime = load('src/lib/agent-runtimes.ts');
  const weights = {
    version: 1, embedder: 'bge-small', embed_dim: 1, mode: 'embedding',
    target_mean: 0, target_std: 1,
    layers: { W1: [[1], [1]], b1: [0], W2: [[1]], b2: [0], W3: [[1]], b3: [0] },
  };
  const embeddingCalls = [];
  const fakeEnv = {};
  const ph = load('src/lib/policy-head.ts', {
    process: { env: fakeEnv, cwd: () => '/fixture' },
    require: name => name === 'fs' ? {
      existsSync: filename => filename === '/fixture/.tenet/policy-weights.json',
      readFileSync: () => JSON.stringify(weights),
    } : require(name),
    fetch: async (url, options) => {
      embeddingCalls.push({ url, body: JSON.parse(options.body) });
      return { ok: true, json: async () => ({ data: [{ embedding: [1] }] }) };
    },
  });
  const state = { agent: 'fixture', composite_score: .5, dimension_scores: {}, tests_passing: 0, tests_total: 0, trajectory_length: 1, recent_deltas: [] };
  const action = { type: 'fix', description: 'Fixture fix', files_affected: [], scope: 'small', branch: 'fixture' };
  const v1 = new ph.PolicyHeadInference('/fixture');
  let localWeightsWithoutApiKey;
  try { localWeightsWithoutApiKey = await v1.predictReward(state, action); }
  catch (e) { localWeightsWithoutApiKey = e.message; }
  fakeEnv.STRATUS_API_KEY = 'fixture-not-a-real-key';
  await v1.predictReward(state, action);
  const v2 = new ph.PolicyHeadInference('/fixture');
  v2.useV2 = true; v2.v2Meta = {};
  v2.selectAction = async () => ({ action: 'fix_bug', confidence: .93, alternatives: [] });
  const v2Reward = await v2.predictReward(state, action);
  const report = {
    revision: 'b0ec9c4b3e26fcc16c6fec697a31c41994f2e172',
    local: { responseSentinel, result: localResult, output_lost: !JSON.stringify(localResult).includes(responseSentinel) },
    mcp: { shared_hub: schemas.HUB_TOOLS.length, transact: schemas.TRANSACT_TOOLS.length, server_only: 3,
      total: schemas.HUB_TOOLS.length + schemas.TRANSACT_TOOLS.length + 3 },
    runtimes: runtime.AGENT_RUNTIMES.map(r => ({ id: r.id, canDispatch: r.canDispatch, mcp: r.mcp.strategy })),
    local_weights: { embedder: weights.embedder, without_api_key: localWeightsWithoutApiKey, calls_with_fixture_key: embeddingCalls },
    v2: { selection_confidence: .93, predictReward: v2Reward },
  };
  fs.writeFileSync(path.join(__dirname, 'runtime-probe.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ local_output_lost: report.local.output_lost, mcp: report.mcp,
    local_weights_require_external_api: localWeightsWithoutApiKey, requested_embedder: embeddingCalls[0].body.model,
    v2_predictReward_is_class_confidence: v2Reward === .93 }, null, 2));
})();
