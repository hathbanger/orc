// Source-level counterexamples for evaluator adequacy. No production edits or agent calls.
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const vm = require('node:vm');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const deps = createRequire('/Users/alectaggart/CascadeProjects/tenet-cli/package.json');
const ts = deps('typescript');
const sourceRoot = fs.existsSync(path.join(__dirname, 'source')) ? path.join(__dirname, 'source') : '/Users/alectaggart/CascadeProjects/tenet-cli';
const fixture = fs.mkdtempSync(path.join(os.tmpdir(), 'tenet-eval-counterexample-'));
const logs = [];
const opts = { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, removeComments: true };
function compiled(source) { return ts.transpileModule(source, { compilerOptions: opts }).outputText; }
function load(file) {
  const source = fs.readFileSync(path.join(sourceRoot, file), 'utf8').replace(/if \(import\.meta\.url ===[\s\S]*$/, '');
  const exports = {};
  vm.runInNewContext(compiled(source), { exports, require: name => {
    if (['fs', 'path'].includes(name)) return require(name);
    throw new Error('Unexpected dependency: ' + name);
  }, process: { env: { AGENT_WORKTREE: fixture }, cwd: () => fixture, stdout: { write: text => logs.push(text) } }, console: { log: (...a) => logs.push(a.join(' ')), error: (...a) => logs.push(a.join(' ')) } }, { filename: file });
  return exports;
}
const files = [
  'src/commands/peter.ts', 'src/lib/agent-outcome.ts', 'src/lib/build-journal.ts',
  'src/lib/outcome-report.ts', 'src/lib/wave-planner.ts', 'src/lib/dispatch-queue.ts'
];
async function main() {
  for (const file of files) {
    const target = path.join(fixture, file);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.copyFileSync(path.join(sourceRoot, file), target);
  }
  const evaluator = load('eval/build/epic-5-refusal-edges.reference.ts');
  const beforeScore = await evaluator.evaluate('');
  const mutations = {
    'src/commands/peter.ts': source => source + '\n/* from "./agent-outcome.js"\nrecordAgentOutcome(\nclassifyAgentOutcome(\n*/\n',
    'src/lib/build-journal.ts': source => source.replaceAll('"round-complete"', "'round-complete'") + '\n/* build:outcome build:round */\n',
    'src/lib/wave-planner.ts': source => source + '\n/* agent-outcome refused */\n',
    'src/lib/dispatch-queue.ts': source => source + '\n/* agent-outcome refused\nretry\n*/\n'
  };
  const changes = [];
  for (const [file, mutate] of Object.entries(mutations)) {
    const target = path.join(fixture, file);
    const before = fs.readFileSync(target, 'utf8');
    const after = mutate(before);
    const sameEmittedJavascript = compiled(before) === compiled(after);
    if (!sameEmittedJavascript) throw new Error('Unexpected runtime change in ' + file);
    fs.writeFileSync(target, after);
    changes.push({ file, sameEmittedJavascript, addedLines: after.split('\n').length - before.split('\n').length });
  }
  const afterScore = await evaluator.evaluate('');
  const { compareEvals } = load('src/lib/eval-parity.ts');
  const equalScoreDifferentBehavior = compareEvals(
    { path: 'generated', baseline: 0.5, totalChecks: 2, failed: ['documentation-marker-missing'] },
    { path: 'reference', baseline: 0.5, totalChecks: 2, failed: ['runtime-state-not-restored'] }
  );
  const result = {
    sourceRoot, fixture, method: 'Actual reference evaluate() body, entrypoint omitted; only comments and a type-literal quote change applied to copied sources',
    beforeScore, afterScore, changes, equalScoreDifferentBehavior, logs,
    sourceHashes: Object.fromEntries([...files, 'eval/build/epic-5-refusal-edges.reference.ts', 'src/lib/eval-parity.ts'].map(file => [file, crypto.createHash('sha256').update(fs.readFileSync(path.join(sourceRoot, file))).digest('hex')]))
  };
  fs.writeFileSync(path.join(__dirname, 'evaluator-probe.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ beforeScore, afterScore, sameEmittedJavascript: changes.every(x => x.sameEmittedJavascript), equalBaselineVerdict: equalScoreDifferentBehavior.verdict }, null, 2));
}
main().catch(error => { console.error(error); process.exitCode = 1; });
