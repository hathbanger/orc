/**
 * Peter Parker Command
 *
 * Orchestrator that wraps ralph-tui with model routing and event bridging.
 * Spidey-sense for which model to use per agent role.
 * Includes proactive experiment selection — PP picks its own next task.
 *
 * @purpose CLI command for Peter Parker orchestrator — setup, run, status, experiment
 */

import chalk from "chalk"
import { execSync, spawn, spawnSync } from "child_process"
import { createHash } from "crypto"
import * as fs from "fs"
import * as path from "path"
import type { CostProfile } from "../types/map.js"
import { writePeterParkerConfig, readCurrentProfile } from "../lib/peter-parker-config.js"
import { PeterParkerBridge } from "../lib/peter-parker-bridge.js"
import { getProjectHubUrl } from "../utils/context-hub-port.js"
import { TrajectoryLoader } from "../lib/trajectory-loader.js"
import { readEvals } from "../lib/eval-store.js"
import { budgetConfigFromEnv, checkBudget, describeLimits, detectStall, type RoundSummary } from "../lib/run-limits.js"
import type { EvalEntry } from "../types/eval.js"
import { TrainingBuffer } from "../lib/training-buffer.js"
import { PolicyHeadInference } from "../lib/policy-head.js"
import type { ActionSelection } from "../lib/policy-head.js"
import type { RLState, RLAction } from "../lib/training-buffer.js"
import { PiRpcBridge, CostMonitor, EventRouter } from "../lib/pi-sky/index.js"
import type { CostBudgetConfig } from "../lib/pi-sky/types.js"
import { PlanningLoop, createPlanningLoop } from "../lib/planning-loop.js"
import type { PlanningResult, EvaluatedAction } from "../lib/planning-loop.js"
import { signedAgentCommit } from "../utils/provenance.js"
import { tenetEnvBool } from "../utils/tenet-env.js"
import { pickExecutor } from "../lib/executor-router.js"
import { getRuntime } from "../lib/agent-runtimes.js"
import { runAgentViaLocal } from "../lib/agent-runtime-local.js"

// Wave D Ship 4: local-first executor branch. When LOCAL_INFERENCE_URL is set,
// peter prefers the on-device MLX server (see src/commands/local-serve.ts and
// the LoRA adapter trained by `local-distill`) before falling back to remote.
const LOCAL_INFERENCE_URL = process.env.LOCAL_INFERENCE_URL ?? ""

function hasLocalInferenceUrl(): boolean {
  return LOCAL_INFERENCE_URL.length > 0
}

function hasRalphTui(): boolean {
  try {
    execSync("which ralph-tui", { stdio: "ignore" })
    return true
  } catch {
    return false
  }
}

function hasPi(): boolean {
  try {
    execSync("which pi", { stdio: "ignore" })
    return true
  } catch {
    return false
  }
}

function getAuthToken(projectRoot: string): string | null {
  const tokenPath = path.join(projectRoot, ".tenet", "context-hub.token")
  if (fs.existsSync(tokenPath)) {
    return fs.readFileSync(tokenPath, "utf-8").trim()
  }
  return null
}

async function setup(projectRoot: string, profile: CostProfile) {
  const configPath = writePeterParkerConfig(projectRoot, profile)
  console.log(chalk.green(`\n  Peter Parker config generated`))
  console.log(chalk.gray(`  Profile: ${profile}`))
  console.log(chalk.gray(`  Config:  ${path.relative(projectRoot, configPath)}`))
  console.log(chalk.gray(`\n  Agents: scout, planner, builder (default), reviewer, tester`))
  console.log(chalk.gray(`  Each has a fallback agent at next tier up\n`))
}

async function run(projectRoot: string, task?: string) {
  if (!hasRalphTui()) {
    console.log(chalk.yellow("\n  ralph-tui is not installed"))
    console.log(chalk.gray("  Install: bun install -g ralph-tui\n"))
    return
  }

  const configPath = path.join(projectRoot, ".ralph-tui", "config.toml")
  if (!fs.existsSync(configPath)) {
    console.log(chalk.yellow("\n  No Peter Parker config found"))
    console.log(chalk.gray("  Run: tenet peter setup\n"))
    return
  }

  const args = ["run", "--listen"]
  let prdPath: string | null = null

  if (task) {
    const ralphDir = path.join(projectRoot, ".ralph-tui")
    if (!fs.existsSync(ralphDir)) {
      fs.mkdirSync(ralphDir, { recursive: true })
    }

    prdPath = path.join(ralphDir, "peter-task.json")
    const titleLine = task.split("\n")[0].slice(0, 80)
    const prd = {
      name: "Peter Parker Task",
      branchName: `ralph/peter-task-${Date.now()}`,
      description: task,
      userStories: [{
        id: "US-001",
        title: titleLine,
        description: task,
        acceptanceCriteria: ["Task completed as described"],
        priority: 1,
        passes: false,
        notes: "",
        dependsOn: [],
      }],
      metadata: { updatedAt: new Date().toISOString() },
    }
    fs.writeFileSync(prdPath, JSON.stringify(prd, null, 2))
    args.push("--prd", prdPath, "--headless")
  }

  console.log(chalk.cyan("\n  Starting Peter Parker orchestrator..."))
  console.log(chalk.gray(`  ralph-tui ${args.join(" ")}\n`))

  const token = getAuthToken(projectRoot)
  const hubUrl = getProjectHubUrl(projectRoot)
  let bridge: PeterParkerBridge | null = null

  if (token) {
    bridge = new PeterParkerBridge({
      contextHubUrl: hubUrl,
      authToken: token,
      onEvent: (event) => {
        console.log(chalk.gray(`  [MAP] ${event.type}`))
      },
    })
  }

  const env = { ...process.env }
  delete env.CLAUDECODE
  delete env.CLAUDE_CODE

  const child = spawn("ralph-tui", args, {
    cwd: projectRoot,
    stdio: "inherit",
    env,
  })

  if (bridge) {
    setTimeout(() => bridge!.start(), 1000)
  }

  function cleanup() {
    if (prdPath && fs.existsSync(prdPath)) {
      try { fs.unlinkSync(prdPath) } catch {}
    }
  }

  child.on("error", (error) => {
    cleanup()
    console.error(chalk.red(`Failed to start ralph-tui: ${error.message}`))
  })

  child.on("exit", (code) => {
    cleanup()
    if (bridge) bridge.stop()
    process.exit(code || 0)
  })
}

async function status(projectRoot: string) {
  console.log(chalk.bold("\n  Peter Parker Status\n"))

  const profile = readCurrentProfile(projectRoot)
  if (profile) {
    console.log(chalk.gray("  Config profile: ") + chalk.cyan(profile))
  } else {
    console.log(chalk.yellow("  No config found. Run: tenet peter setup"))
  }

  const token = getAuthToken(projectRoot)
  const hubUrl = getProjectHubUrl(projectRoot)

  if (token) {
    try {
      const params = new URLSearchParams({ pattern: "peter:*", limit: "5" })
      const response = await fetch(`${hubUrl}/api/events?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
        signal: AbortSignal.timeout(2000),
      })

      if (response.ok) {
        const data = await response.json() as { events: any[]; count: number }
        console.log(chalk.gray(`  Recent events: ${data.count}`))
        for (const event of data.events) {
          const time = new Date(event.ts).toISOString().replace("T", " ").slice(11, 19)
          console.log(chalk.gray(`    [${time}] ${event.type}`))
        }
      }
    } catch {
      console.log(chalk.gray("  Event bus: not reachable"))
    }
  } else {
    console.log(chalk.gray("  Event bus: no auth token"))
  }

  console.log()
}

function gitExec(args: string[], cwd: string): { ok: boolean; output: string } {
  const result = spawnSync("git", args, { cwd, encoding: "utf-8", stdio: "pipe" })
  return { ok: result.status === 0, output: (result.stdout || "").trim() }
}

function ghExec(args: string[], cwd: string): { ok: boolean; output: string } {
  const result = spawnSync("gh", args, { cwd, encoding: "utf-8", stdio: "pipe" })
  return { ok: result.status === 0, output: (result.stdout || "").trim() }
}

async function postHubEvent(
  projectRoot: string,
  eventType: string,
  data: Record<string, unknown>
): Promise<void> {
  const token = getAuthToken(projectRoot)
  const hubUrl = getProjectHubUrl(projectRoot)
  if (!token) return

  try {
    await fetch(`${hubUrl}/api/events`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        type: eventType,
        source: "peter-parker",
        data,
      }),
      signal: AbortSignal.timeout(5000),
    })
  } catch {
    console.log(chalk.gray("  PP: Warning - could not post event to hub"))
  }
}

// ============================================================================
// Pi-sky Runtime Integration
// ============================================================================

interface PiRuntimeState {
  bridge: PiRpcBridge | null
  costMonitor: CostMonitor | null
  eventRouter: EventRouter | null
}

async function initPiRuntime(
  projectRoot: string,
  options: { budget?: number; usePi?: boolean }
): Promise<PiRuntimeState> {
  const state: PiRuntimeState = {
    bridge: null,
    costMonitor: null,
    eventRouter: null,
  }

  // Check if Pi should be used
  const shouldUsePi = options.usePi === true || (options.usePi !== false && hasPi())
  if (!shouldUsePi) {
    return state
  }

  console.log(chalk.cyan("  Initializing Pi runtime..."))

  // Create Pi RPC bridge
  state.bridge = new PiRpcBridge({
    cwd: projectRoot,
    yolo: true,
    noSession: true,
  })

  // Initialize cost monitor if budget is set
  if (options.budget) {
    const costConfig: Partial<CostBudgetConfig> = {
      maxCost: options.budget,
      downgradeModel: { provider: "anthropic", modelId: "claude-haiku-4-5-20251001" },
      downgradeThinkingLevel: "low",
      upgradeModel: { provider: "anthropic", modelId: "claude-sonnet-4-20250514" },
      upgradeThinkingLevel: "medium",
      criticalKeywords: ["security", "auth", "payment", "migration", "deploy", "production"],
    }
    state.costMonitor = new CostMonitor(costConfig)
    state.costMonitor.on("downgrade", (data) => {
      console.log(chalk.yellow(`  CostMonitor: Downgrading ${data.agent} to ${data.model} (budget: $${data.totalCost.toFixed(2)}/$${data.budget.toFixed(2)})`))
    })
    state.costMonitor.on("upgrade", (data) => {
      console.log(chalk.cyan(`  CostMonitor: Upgrading ${data.agent} to ${data.model} (critical path: ${data.reason})`))
    })
    state.costMonitor.on("cost_update", (data) => {
      if (data.remaining < data.totalCost * 0.2) {
        console.log(chalk.yellow(`  CostMonitor: Budget low — $${data.remaining.toFixed(2)} remaining`))
      }
    })
  }

  // Initialize event router for Context Hub SSE
  const hubUrl = getProjectHubUrl(projectRoot)
  state.eventRouter = new EventRouter({
    hubUrl,
    routes: [
      {
        pattern: "eval:scored",
        action: "steer",
        messageTemplate: "SYSTEM EVENT: Eval regression detected. Agent={{data.agent}}, delta={{data.delta}}. Investigate what caused this before continuing.",
        condition: (e) => Number(e.data?.delta ?? 0) < -0.01,
      },
      {
        pattern: "scope:impact",
        action: "follow_up",
        messageTemplate: "SYSTEM EVENT: Scope impact from {{data.agent}} on {{data.pattern}}. Consider if this affects your current work.",
      },
    ],
  })

  state.eventRouter.on("route", (data) => {
    console.log(chalk.gray(`  EventRouter: ${data.event.type} → ${data.route.action}`))
  })

  state.eventRouter.on("error", (err) => {
    // Silent — hub may not be running
  })

  return state
}

async function runTaskWithPi(
  bridge: PiRpcBridge,
  task: string,
  costMonitor: CostMonitor | null,
  timeout: number = 300000
): Promise<void> {
  if (!bridge.started) {
    await bridge.start()
  }

  // TOCTOU guard: re-verify hub before starting agent (TLA+ invariant: HubRequiredForScheduling)
  // TLC found: agent can be scheduled when hub is up, then hub crashes before start
  try {
    const { guardHubAvailable } = await import("../lib/hub-health.js")
    const projectRoot = process.cwd()
    const guard = await guardHubAvailable(projectRoot, "peter-parker")
    if (!guard.proceed) {
      console.log(chalk.yellow(`\n  ⚠ Hub health check failed: ${guard.reason}`))
      console.log(chalk.gray(`  Proceeding without hub (results won't be tracked).\n`))
      // Don't block — hub is optional for execution, just warn
    }
  } catch {
    // Hub health check not available — proceed
  }

  // Check critical path for model upgrade if cost monitor is active
  if (costMonitor) {
    await costMonitor.checkCriticalPath("experiment", task)
  }

  // Create a promise that resolves when agent is done
  const agentDone = new Promise<void>((resolve) => {
    bridge.once("agent_end", () => resolve())
  })

  // Send prompt
  await bridge.prompt(task)

  // Wait for completion with timeout
  const timeoutPromise = new Promise<void>((_, reject) => {
    setTimeout(() => reject(new Error("Pi task timeout")), timeout)
  })

  try {
    await Promise.race([agentDone, timeoutPromise])
  } catch {
    await bridge.abort().catch(() => {})
  }

  // Update cost tracking
  if (costMonitor) {
    await costMonitor.checkCost("experiment")
  }
}

async function shutdownPiRuntime(state: PiRuntimeState): Promise<void> {
  state.eventRouter?.stop()
  if (state.bridge && !state.bridge.exited) {
    await state.bridge.shutdown().catch(() => {})
  }
}

/**
 * Run an agent task using claude CLI directly (~50MB vs ~500MB for Pi).
 * Karpathy pattern: all context in the prompt, agent reads/edits/exits.
 * Use TENET_AGENT_USE_PI=1 to force Pi runtime for debugging.
 */
async function runAgentWithPi(projectRoot: string, task: string): Promise<void> {
  const ppGuardrails = [
    "",
    "RULES:",
    "- Make minimal, focused changes. Don't refactor unrelated code.",
    "- Run the build (npm run build) and check for type errors before finishing.",
    "- If tests exist for the area you're changing, run them.",
    "- Do NOT create new test files unless the task specifically asks for tests.",
    "- Do NOT modify files outside the scope of the task.",
    "- When done, stop immediately. Do not ask for confirmation.",
  ].join("\n")

  const fullTask = task + ppGuardrails

  // Wave E Ship 4: tier-0 local Qwen for scan/extract/shadow agents.
  // Existing API/Pi/Claude-CLI ladder remains as fallback.
  const agentType = process.env.TENET_AGENT_TYPE
  const agentName = process.env.TENET_AGENT_NAME || "peter-parker"
  const choice = await pickExecutor({ agentType, agentName })
  if (choice === "local") {
    const cost = await runAgentViaLocal({ task: fullTask, cwd: projectRoot })
    if (cost) {
      console.log(chalk.cyan("  PP: Using local Qwen (Mac Studio, $0)"))
      console.log(chalk.gray(`  Cost: $${cost.costUsd.toFixed(4)} (${cost.turns} turns, ${cost.inputTokens + cost.outputTokens} tokens)`))
      return
    }
    console.log(chalk.yellow("  PP: local Qwen unreachable, falling back"))
  }

  // Tiers 1+: the runtime registry already decided which harness to use, via
  // pickExecutor above. This used to re-implement that ladder inline — the
  // `choice` was computed and then ignored for everything except "local".
  if (choice === "api") {
    console.log(chalk.cyan("  PP: Using API runtime (zero memory churn)"))
    try {
      const { runAgentViaAPI } = await import("../lib/agent-runtime-api.js")
      const costData = await runAgentViaAPI({ task: fullTask, cwd: projectRoot, timeoutMs: 300_000 })
      if (costData) {
        console.log(chalk.gray(`  Cost: $${costData.costUsd.toFixed(4)} (${costData.turns} turns, ${costData.inputTokens + costData.outputTokens} tokens)`))
      }
      return
    } catch (err: any) {
      console.error(chalk.yellow(`  PP: API runtime failed: ${err.message} — falling back to a CLI harness`))
    }
  }

  const cliRuntime = getRuntime(choice === "pi" ? "pi-cli" : choice === "codex-cli" ? "codex-cli" : "claude-cli")
  if (!cliRuntime?.buildDispatch) {
    console.error(chalk.red(`  PP: no CLI runtime available for choice "${choice}"`))
    return
  }
  const invocation = cliRuntime.buildDispatch(fullTask, { cwd: projectRoot, autonomous: true })
  console.log(chalk.cyan(`  PP: Using ${cliRuntime.displayName}`))
  await new Promise<void>((resolve) => {
    const child = spawn(invocation.command, invocation.args, {
      cwd: projectRoot,
      stdio: "inherit",
      env: { ...process.env, ...invocation.env } as NodeJS.ProcessEnv,
    })
    child.on("error", (error) => {
      console.error(chalk.red(`  PP: Failed to start ${invocation.command}: ${error.message}`))
      resolve()
    })
    child.on("exit", () => resolve())
  })
}

/**
 * Run an agent task using ralph-tui (legacy fallback).
 * Has session lock issues — prefer pi.
 */
async function runAgentWithRalphTui(projectRoot: string, task: string): Promise<void> {
  const configPath = path.join(projectRoot, ".ralph-tui", "config.toml")
  if (!fs.existsSync(configPath)) {
    console.log(chalk.yellow("\n  No Peter Parker config found"))
    console.log(chalk.gray("  Run: tenet peter setup\n"))
    return
  }

  // Clear stale locks — dead PIDs shouldn't block autonomous operation
  const lockPath = path.join(projectRoot, ".ralph-tui", "ralph.lock")
  if (fs.existsSync(lockPath)) {
    try {
      const lock = JSON.parse(fs.readFileSync(lockPath, "utf-8"))
      try {
        process.kill(lock.pid, 0) // Check if PID is alive
      } catch {
        // PID is dead — remove stale lock
        fs.unlinkSync(lockPath)
        console.log(chalk.gray("  PP: Cleared stale ralph-tui lock"))
      }
    } catch {
      fs.unlinkSync(lockPath)
    }
  }

  console.log(chalk.cyan("  PP: Using ralph-tui agent (legacy)"))

  await new Promise<void>((resolve) => {
    const ralphDir = path.join(projectRoot, ".ralph-tui")
    if (!fs.existsSync(ralphDir)) {
      fs.mkdirSync(ralphDir, { recursive: true })
    }

    const prdPath = path.join(ralphDir, "peter-task.json")
    const titleLine = task.split("\n")[0].slice(0, 80)
    const prd = {
      name: "Peter Parker Task",
      branchName: `ralph/peter-task-${Date.now()}`,
      description: task,
      userStories: [{
        id: "US-001",
        title: titleLine,
        description: task,
        acceptanceCriteria: ["Task completed as described"],
        priority: 1,
        passes: false,
        notes: "",
        dependsOn: [],
      }],
      metadata: { updatedAt: new Date().toISOString() },
    }
    fs.writeFileSync(prdPath, JSON.stringify(prd, null, 2))

    const args = ["run", "--listen", "--prd", prdPath, "--headless"]

    const token = getAuthToken(projectRoot)
    let bridge: PeterParkerBridge | null = null

    if (token) {
      bridge = new PeterParkerBridge({
        contextHubUrl: getProjectHubUrl(projectRoot),
        authToken: token,
        onEvent: (event) => {
          console.log(chalk.gray(`  [MAP] ${event.type}`))
        },
      })
    }

    const env = { ...process.env }
    delete env.CLAUDECODE
    delete env.CLAUDE_CODE

    const child = spawn("ralph-tui", args, {
      cwd: projectRoot,
      stdio: "inherit",
      env,
    })

    if (bridge) {
      setTimeout(() => bridge!.start(), 1000)
    }

    function cleanup() {
      if (prdPath && fs.existsSync(prdPath)) {
        try { fs.unlinkSync(prdPath) } catch {}
      }
    }

    child.on("error", (error) => {
      cleanup()
      console.error(chalk.red(`  PP: Failed to start ralph-tui: ${error.message}`))
      resolve()
    })

    child.on("exit", () => {
      cleanup()
      if (bridge) bridge.stop()
      resolve()
    })
  })
}

async function runWithPR(projectRoot: string, task?: string): Promise<void> {
  if (!task) {
    console.log(chalk.yellow("\n  --task is required for pr mode"))
    console.log(chalk.gray("  Usage: tenet peter pr --task \"fix the login bug\"\n"))
    return
  }

  if (!hasPi() && !hasRalphTui()) {
    console.log(chalk.yellow("\n  Neither pi nor ralph-tui is installed"))
    console.log(chalk.gray("  Install pi: npm i -g @mariozechner/pi-coding-agent"))
    console.log(chalk.gray("  Or ralph-tui: bun install -g ralph-tui\n"))
    return
  }

  const baseBranch = "main"
  const branchName = `pp/fix-${Date.now()}`

  console.log(chalk.cyan(`\n  PP: Creating branch ${branchName}`))

  gitExec(["fetch", "origin", baseBranch], projectRoot)

  let checkout = gitExec(["checkout", "-b", branchName, `origin/${baseBranch}`], projectRoot)
  if (!checkout.ok) {
    checkout = gitExec(["checkout", "-b", branchName, baseBranch], projectRoot)
  }
  if (!checkout.ok) {
    console.log(chalk.red(`  PP: Failed to create branch ${branchName}`))
    return
  }

  console.log(chalk.cyan(`  PP: Running agent on task: ${task}`))

  // Use pi (preferred) or fall back to ralph-tui
  if (hasPi()) {
    await runAgentWithPi(projectRoot, task)
  } else {
    await runAgentWithRalphTui(projectRoot, task)
  }

  const diffCheck = gitExec(["diff", "--quiet", "HEAD"], projectRoot)
  const untrackedResult = spawnSync("git", ["ls-files", "--others", "--exclude-standard"], {
    cwd: projectRoot,
    encoding: "utf-8",
    stdio: "pipe",
  })
  const untracked = (untrackedResult.stdout || "").trim()

  if (diffCheck.ok && !untracked) {
    console.log(chalk.yellow("\n  PP: No changes made, cleaning up"))
    gitExec(["checkout", baseBranch], projectRoot)
    gitExec(["branch", "-D", branchName], projectRoot)
    return
  }

  console.log(chalk.cyan("  PP: Changes detected, committing..."))

  const commitMsg = `fix(pp): ${task}`
  const commitHash = signedAgentCommit(projectRoot, commitMsg, {
    agentId: "peter-parker",
    sessionId: branchName,
  })
  if (!commitHash) {
    console.log(chalk.red("  PP: Commit failed"))
    return
  }

  console.log(chalk.cyan("  PP: Pushing branch..."))

  const pushResult = gitExec(["push", "-u", "origin", branchName], projectRoot)
  if (!pushResult.ok) {
    console.log(chalk.red("  PP: Push failed"))
    console.log(chalk.gray(`  ${pushResult.output}`))
    return
  }

  console.log(chalk.cyan("  PP: Creating PR..."))

  const prTitle = `PP: ${task.slice(0, 60)}`

  // Extract issue number from task text (e.g. "GitHub #20: ..." or "Closes #20")
  const issueMatch = task.match(/GitHub #(\d+)/i) || task.match(/(?:Closes|Fixes|Resolves) #(\d+)/i)
  const linkedIssue = issueMatch ? issueMatch[1] : null

  const prBody = [
    "## Auto-generated by Peter Parker",
    "",
    `**Task:** ${task}`,
    `**Branch:** \`${branchName}\``,
    "",
    ...(linkedIssue ? [`Closes #${linkedIssue}`, ""] : []),
    "### Eval Suite",
    "This PR will be evaluated by the CI eval suite.",
    "Auto-merge will trigger if eval score improves over baseline.",
    "",
    "---",
    "*Generated by TENET self-driving loop*",
  ].join("\n")

  let prResult = ghExec([
    "pr", "create",
    "--title", prTitle,
    "--body", prBody,
    "--base", baseBranch,
    "--head", branchName,
    "--label", "pp-generated",
  ], projectRoot)

  if (!prResult.ok) {
    prResult = ghExec([
      "pr", "create",
      "--title", prTitle,
      "--body", prBody,
      "--base", baseBranch,
      "--head", branchName,
    ], projectRoot)
  }

  if (!prResult.ok) {
    console.log(chalk.red("  PP: Failed to create PR"))
    console.log(chalk.gray(`  ${prResult.output}`))
  } else {
    const prUrl = prResult.output
    console.log(chalk.green(`\n  PP: PR created at ${prUrl}`))

    await postHubEvent(projectRoot, "pr:created", {
      task,
      pr_url: prUrl,
      branch: branchName,
    })
  }

  gitExec(["checkout", baseBranch], projectRoot)
  console.log(chalk.green("  PP: Done\n"))
}

// ============================================================================
// Pickup — self-driving loop: poll backlog → pick → branch → execute → PR
// ============================================================================

function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40)
}

/**
 * Extract cross-repo close reference from issue body metadata.
 * Looks for patterns like "10et-ai/cli#25" in the tenet metadata block,
 * or falls back to same-repo #N.
 */
function extractCloseRef(card: { number: number; description: string }): string {
  // Check for explicit cross-repo ref in metadata block
  const metaMatch = card.description.match(/<!--\s*tenet:([\s\S]*?)-->/)
  if (metaMatch) {
    const meta = metaMatch[1]
    const crossRepoMatch = meta.match(/close_ref:\s*(.+)/)
    if (crossRepoMatch) return crossRepoMatch[1].trim()
  }
  // Default: same-repo reference
  return `#${card.number}`
}

/**
 * Append an entry to the pickup queue for audit/tracking.
 */
function appendPickupQueue(projectRoot: string, entry: Record<string, unknown>): void {
  const queuePath = path.join(projectRoot, ".tenet", "pickup-queue.jsonl")
  const dir = path.dirname(queuePath)
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
  fs.appendFileSync(queuePath, JSON.stringify(entry) + "\n")
}

/**
 * Poll tenet/backlog for source:linear issues, pick the highest priority,
 * move to in_progress, create branch, execute, create PR, close on merge.
 */
async function runPickup(projectRoot: string): Promise<void> {
  console.log(chalk.bold("\n  Peter Parker — Backlog Pickup\n"))
  console.log(chalk.gray("  Polling tenet/backlog for all issues...\n"))

  if (!hasPi() && !hasRalphTui()) {
    console.log(chalk.yellow("  Neither pi nor ralph-tui is installed"))
    console.log(chalk.gray("  Install pi: npm i -g @mariozechner/pi-coding-agent"))
    console.log(chalk.gray("  Or ralph-tui: bun install -g ralph-tui\n"))
    return
  }

  const { GitHubKanban } = await import("../lib/kanban-github.js")
  let kb: InstanceType<typeof GitHubKanban>
  try {
    kb = new GitHubKanban(projectRoot)
  } catch (err: any) {
    console.log(chalk.red(`  PP: ${err.message}`))
    return
  }

  // Fetch all backlog cards regardless of source (agent, human, linear, findings)
  let cards: Awaited<ReturnType<typeof kb.getCards>>
  try {
    cards = await kb.getCards({ column: "backlog" })
  } catch (err: any) {
    console.log(chalk.red(`  PP: Failed to fetch backlog: ${err.message}`))
    return
  }

  if (cards.length === 0) {
    console.log(chalk.yellow("  No issues in tenet/backlog. Nothing to pick up.\n"))
    return
  }

  // Already sorted by priority desc from getCards
  const card = cards[0]

  console.log(chalk.cyan(`  Picked: #${card.number} — ${card.title}`))
  console.log(chalk.gray(`  Priority: ${card.priority}  Source: ${card.source}`))
  if (card.labels.length > 0) {
    console.log(chalk.gray(`  Labels: ${card.labels.join(", ")}`))
  }
  console.log()

  // Move to in_progress
  try {
    kb.pick(card.number, "peter-parker")
    console.log(chalk.gray(`  📋 Issue #${card.number} → in_progress (assigned: peter-parker)`))
  } catch (err: any) {
    console.log(chalk.yellow(`  PP: Could not move issue: ${err.message}`))
    // Continue anyway — don't block on label move failure
  }

  // Build task prompt from issue title + description
  const taskLines = [`GitHub #${card.number}: ${card.title}`]
  if (card.description) {
    // Strip the tenet metadata block from the description for the prompt
    const cleanDesc = card.description.replace(/<!--\s*tenet:[\s\S]*?-->/g, "").trim()
    if (cleanDesc) taskLines.push("", cleanDesc)
  }
  const task = taskLines.join("\n")

  // Create branch
  const baseBranch = "main"
  const slug = slugify(card.title)
  const branchName = `pp/issue-${card.number}-${slug}`

  console.log(chalk.cyan(`\n  PP: Creating branch ${branchName}`))

  gitExec(["fetch", "origin", baseBranch], projectRoot)

  let checkout = gitExec(["checkout", "-b", branchName, `origin/${baseBranch}`], projectRoot)
  if (!checkout.ok) {
    checkout = gitExec(["checkout", "-b", branchName, baseBranch], projectRoot)
  }
  if (!checkout.ok) {
    console.log(chalk.red(`  PP: Failed to create branch ${branchName}`))
    // Revert kanban move
    try { kb.move(card.number, "backlog") } catch {}
    return
  }

  // Track pickup
  appendPickupQueue(projectRoot, {
    ts: new Date().toISOString(),
    issue: card.number,
    title: card.title,
    branch: branchName,
    source: card.source,
    priority: card.priority,
    status: "in_progress",
  })

  // Run the agent
  console.log(chalk.cyan(`  PP: Running agent on task...\n`))

  if (hasPi()) {
    await runAgentWithPi(projectRoot, task)
  } else {
    await runAgentWithRalphTui(projectRoot, task)
  }

  // Check for changes
  const diffCheck = gitExec(["diff", "--quiet", "HEAD"], projectRoot)
  const untrackedResult = spawnSync("git", ["ls-files", "--others", "--exclude-standard"], {
    cwd: projectRoot,
    encoding: "utf-8",
    stdio: "pipe",
  })
  const untracked = (untrackedResult.stdout || "").trim()

  if (diffCheck.ok && !untracked) {
    console.log(chalk.yellow("\n  PP: No changes made, reverting to backlog"))
    gitExec(["checkout", baseBranch], projectRoot)
    gitExec(["branch", "-D", branchName], projectRoot)
    try { kb.move(card.number, "backlog") } catch {}
    appendPickupQueue(projectRoot, {
      ts: new Date().toISOString(),
      issue: card.number,
      branch: branchName,
      status: "no_changes",
    })
    return
  }

  // Commit
  console.log(chalk.cyan("  PP: Changes detected, committing..."))

  const commitMsg = `fix(pp): #${card.number} ${card.title}`
  const commitHash = signedAgentCommit(projectRoot, commitMsg, {
    agentId: "peter-parker",
    sessionId: branchName,
  })
  if (!commitHash) {
    console.log(chalk.red("  PP: Commit failed"))
    gitExec(["checkout", baseBranch], projectRoot)
    try { kb.move(card.number, "backlog") } catch {}
    return
  }

  // Push
  console.log(chalk.cyan("  PP: Pushing branch..."))

  const pushResult = gitExec(["push", "-u", "origin", branchName], projectRoot)
  if (!pushResult.ok) {
    console.log(chalk.red("  PP: Push failed"))
    console.log(chalk.gray(`  ${pushResult.output}`))
    gitExec(["checkout", baseBranch], projectRoot)
    try { kb.move(card.number, "backlog") } catch {}
    return
  }

  // Create PR
  console.log(chalk.cyan("  PP: Creating PR..."))

  const closeRef = extractCloseRef(card)
  const prTitle = `PP: #${card.number} ${card.title.slice(0, 60)}`
  const prBody = [
    "## Auto-generated by Peter Parker (Backlog Pickup)",
    "",
    `**Issue:** #${card.number} — ${card.title}`,
    `**Branch:** \`${branchName}\``,
    `**Source:** ${card.source}`,
    "",
    `Closes ${closeRef}`,
    "",
    "### Eval Suite",
    "This PR will be evaluated by the CI eval suite.",
    "Auto-merge will trigger if eval score improves over baseline.",
    "",
    "---",
    "*Generated by TENET self-driving loop (pickup)*",
  ].join("\n")

  let prResult = ghExec([
    "pr", "create",
    "--title", prTitle,
    "--body", prBody,
    "--base", baseBranch,
    "--head", branchName,
    "--label", "pp-generated",
  ], projectRoot)

  if (!prResult.ok) {
    prResult = ghExec([
      "pr", "create",
      "--title", prTitle,
      "--body", prBody,
      "--base", baseBranch,
      "--head", branchName,
    ], projectRoot)
  }

  if (!prResult.ok) {
    console.log(chalk.red("  PP: Failed to create PR"))
    console.log(chalk.gray(`  ${prResult.output}`))
  } else {
    const prUrl = prResult.output
    console.log(chalk.green(`\n  PP: PR created at ${prUrl}`))

    // Move to eval column
    try { kb.move(card.number, "eval") } catch {}

    // Track completion
    appendPickupQueue(projectRoot, {
      ts: new Date().toISOString(),
      issue: card.number,
      branch: branchName,
      pr_url: prUrl,
      status: "pr_created",
    })

    await postHubEvent(projectRoot, "peter:pickup-complete", {
      issue: card.number,
      title: card.title,
      branch: branchName,
      pr_url: prUrl,
      source: card.source,
    })
  }

  // Write journal entry
  writeJournalEntry(projectRoot, {
    v: 1,
    ts: new Date().toISOString(),
    session: branchName,
    type: "feature",
    status: "complete",
    title: `Pickup: #${card.number} ${card.title}`,
    summary: `Auto-picked issue from backlog (source:${card.source}) and executed. Branch: ${branchName}`,
    detail: `Issue: #${card.number} — ${card.title}\nSource: ${card.source}\nPriority: ${card.priority}`,
    agent_id: "peter-parker",
  })

  gitExec(["checkout", baseBranch], projectRoot)
  console.log(chalk.green("  PP: Pickup complete.\n"))
}

interface ExperimentProposal {
  task: string
  predicted_delta: number
  reasoning: string
  risk: string
}

function buildRLState(evals: EvalEntry[], trajectoryLength: number, recentDeltas: number[]): RLState {
  const latest = evals.sort((a, b) => b.ts.localeCompare(a.ts))[0]
  return {
    composite_score: latest?.composite ?? 0,
    dimension_scores: latest?.metrics ?? {},
    tests_passing: (latest?.metrics?.tests_passed as number) ?? 0,
    tests_total: (latest?.metrics?.tests_total as number) ?? 1,
    trajectory_length: trajectoryLength,
    recent_deltas: recentDeltas,
    agent: "peter-parker",
  }
}

function proposalToRLAction(p: ExperimentProposal): RLAction {
  return {
    type: "experiment",
    description: p.task,
    files_affected: [],
    scope: "medium",
    branch: "",
  }
}

/**
 * Passive policy-head observation for build-cycle agents.
 *
 * After each round of `agentRun`, the chosen task and its actual outcome
 * (reward delta, kept/reverted) are known. This function asks the policy
 * head what reward IT would have predicted for that (state, action), then
 * appends a `policy_decision` event to `.tenet/policy-decisions.jsonl`.
 *
 * Behavior change: NONE. The agent picks its action exactly as before. We
 * only observe the model's prediction so we can compare predicted-vs-actual
 * across real production runs. This is the cheap-and-safe first half of
 * the gated wedge — once we have a few weeks of (predicted, actual) pairs
 * from real build cycles, we can decide whether to enable active re-ranking.
 *
 * Errors are swallowed — observation must never fail a build.
 */
async function logPolicyObservation(
  projectRoot: string,
  agentName: string,
  sessionId: string,
  branch: string,
  round: number,
  task: string,
  metricBefore: number,
  result: { delta: number; kept: boolean; metricAfter: number },
  transitions: Array<{ reward?: number }>,
  briefing?: { used: boolean; hash: string },
): Promise<void> {
  try {
    const ph = new PolicyHeadInference(projectRoot)
    if (!ph.isLoaded) return

    const state: RLState = {
      composite_score: metricBefore,
      dimension_scores: {},
      tests_passing: 0,
      tests_total: 1,
      trajectory_length: round,
      recent_deltas: transitions.slice(-5).map(t => t.reward ?? 0),
      agent: agentName,
    }
    const action: RLAction = {
      type: "experiment",
      description: task,
      files_affected: [],
      scope: "medium",
      branch,
    }

    const predicted = await ph.predictReward(state, action)
    const stats = ph.stats

    const event = {
      schema_version: 1,
      ts: new Date().toISOString(),
      mode: "passive",
      agent: agentName,
      session_id: sessionId,
      round,
      task: task.slice(0, 500),
      predicted_reward: predicted,
      actual_reward: result.delta,
      kept: result.kept,
      metric_before: metricBefore,
      metric_after: result.metricAfter,
      policy_head: {
        version: ph.version,
        trained_on: stats?.trained_on,
        direction_accuracy: stats?.direction_accuracy,
        rank_correlation: stats?.rank_correlation,
      },
      // Ship 3: track whether briefings were in play. Once we have ~20 build
      // runs each with briefings on/off, we can compute briefing-relevance
      // signal as predicted-vs-actual lift conditional on briefing_used.
      briefing_used: briefing?.used ?? false,
      briefing_hash: briefing?.hash ?? null,
    }

    const outDir = path.join(projectRoot, ".tenet")
    if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true })
    const outPath = path.join(outDir, "policy-decisions.jsonl")
    fs.appendFileSync(outPath, JSON.stringify(event) + "\n")
  } catch {
    // Observation only — never fail the build cycle on a prediction error
  }
}

async function rerankWithPolicyHead(
  projectRoot: string,
  proposals: ExperimentProposal[],
  evals: EvalEntry[],
  recentDeltas: number[],
): Promise<ExperimentProposal[]> {
  const ph = new PolicyHeadInference(projectRoot)
  if (!ph.isLoaded || proposals.length < 2) return proposals

  const state = buildRLState(evals, 0, recentDeltas)
  const actions = proposals.map(proposalToRLAction)

  try {
    const ranked = await ph.rankActions(state, actions)
    const reordered = ranked.map(r => proposals[actions.indexOf(r.action)])

    const stats = ph.stats!
    console.log(chalk.magenta(`  Policy head re-ranked ${proposals.length} proposals (trained on ${stats.trained_on} tuples, rank_corr=${stats.rank_correlation.toFixed(3)})`))

    for (let i = 0; i < ranked.length; i++) {
      const r = ranked[i]
      const p = reordered[i]
      console.log(chalk.gray(`    #${i + 1} [pred=${r.predictedReward.toFixed(4)}] ${p.task.slice(0, 60)}`))
    }
    console.log()

    return reordered
  } catch (err: any) {
    console.log(chalk.yellow(`  Policy head ranking failed: ${err.message}`))
    return proposals
  }
}

/**
 * Use the planning loop (PH → WM rollouts → select) to choose the best action.
 * Falls back to rerankWithPolicyHead if planning loop fails.
 */
async function planWithRollouts(
  projectRoot: string,
  agentId: string,
  goal: string,
  proposals: ExperimentProposal[],
  evals: EvalEntry[],
  recentDeltas: number[],
  verbose: boolean = false,
): Promise<{ proposals: ExperimentProposal[]; planningResult: PlanningResult | null }> {
  try {
    const planner = createPlanningLoop(projectRoot, {
      topK: Math.min(5, proposals.length),
      verbose,
      maxPlanningTimeMs: 10000, // 10s for experiment selection
    })

    if (!planner.isReady) {
      if (verbose) console.log(chalk.gray("  Planning loop: PolicyHead not loaded, using rerank fallback"))
      const reranked = await rerankWithPolicyHead(projectRoot, proposals, evals, recentDeltas)
      return { proposals: reranked, planningResult: null }
    }

    console.log(chalk.magenta("  Planning loop: PH → WM rollouts → select"))

    const result = await planner.plan(agentId, goal)

    if (result.selectedAction) {
      console.log(chalk.magenta(`  Planning completed in ${result.planningTimeMs}ms, ${result.rolloutsPerformed} rollouts`))

      // Map planning results back to proposals by scoring alignment
      const scoredProposals = proposals.map(p => {
        // Find best matching evaluated action
        const bestMatch = result.allActions
          .filter(a => !a.filtered)
          .sort((a, b) => {
            // Score by how well the action type matches the proposal
            const aMatch = proposalMatchesAction(p, a) ? 1 : 0
            const bMatch = proposalMatchesAction(p, b) ? 1 : 0
            if (aMatch !== bMatch) return bMatch - aMatch
            return b.combinedScore - a.combinedScore
          })[0]

        return {
          proposal: p,
          score: bestMatch?.combinedScore ?? 0,
          prediction: bestMatch?.prediction,
        }
      })

      scoredProposals.sort((a, b) => b.score - a.score)

      // Log the ranked results
      for (let i = 0; i < scoredProposals.length; i++) {
        const s = scoredProposals[i]
        const predDelta = s.prediction?.outcome?.immediate?.evalScoreChange
        const conf = s.prediction?.confidence
        console.log(chalk.gray(
          `    #${i + 1} [score=${s.score.toFixed(3)}` +
          (predDelta !== undefined ? ` pred_delta=${predDelta > 0 ? "+" : ""}${predDelta.toFixed(4)}` : "") +
          (conf !== undefined ? ` conf=${conf.toFixed(2)}` : "") +
          `] ${s.proposal.task.slice(0, 60)}`
        ))
      }
      console.log()

      return {
        proposals: scoredProposals.map(s => s.proposal),
        planningResult: result,
      }
    } else {
      console.log(chalk.yellow(`  Planning loop: no valid action selected (${result.noSelectionReason})`))
      const reranked = await rerankWithPolicyHead(projectRoot, proposals, evals, recentDeltas)
      return { proposals: reranked, planningResult: result }
    }
  } catch (err: any) {
    console.log(chalk.yellow(`  Planning loop failed: ${err.message}`))
    const reranked = await rerankWithPolicyHead(projectRoot, proposals, evals, recentDeltas)
    return { proposals: reranked, planningResult: null }
  }
}

/** Check if a proposal's task description matches an evaluated action type */
function proposalMatchesAction(proposal: ExperimentProposal, action: EvaluatedAction): boolean {
  const task = proposal.task.toLowerCase()
  const actionType = action.action.actionType

  const matches: Record<string, string[]> = {
    "fix": ["fix", "bug", "error", "crash", "broken"],
    "refactor": ["refactor", "clean", "simplify", "extract", "dedup"],
    "feature": ["add", "implement", "create", "build", "new"],
    "test": ["test", "coverage", "spec", "assert"],
    "config": ["config", "setting", "env", "deploy"],
    "experiment": ["experiment", "try", "investigate", "explore"],
    "eval": ["eval", "score", "metric", "measure"],
    "research": ["research", "read", "analyze", "understand"],
  }

  const keywords = matches[actionType] || []
  return keywords.some(kw => task.includes(kw))
}

function writeJournalEntry(projectRoot: string, entry: Record<string, unknown>): void {
  const journalDir = path.join(projectRoot, ".tenet", "journal")
  if (!fs.existsSync(journalDir)) {
    fs.mkdirSync(journalDir, { recursive: true })
  }
  const journalFile = path.join(journalDir, "peter-experiment.jsonl")
  fs.appendFileSync(journalFile, JSON.stringify(entry) + "\n")
}

function buildEvalSummary(evals: EvalEntry[], limit: number = 10): string {
  if (evals.length === 0) return "No eval entries found."

  const recent = evals
    .sort((a, b) => b.ts.localeCompare(a.ts))
    .slice(0, limit)

  const lines: string[] = []
  for (const e of recent) {
    const metricsStr = Object.entries(e.metrics)
      .map(([k, v]) => `${k}=${typeof v === "number" ? v.toFixed(4) : v}`)
      .join(", ")
    lines.push(
      `[${e.ts}] agent=${e.agent} composite=${e.composite?.toFixed(4) ?? "N/A"} ${metricsStr}`
    )
  }
  return lines.join("\n")
}

function findLowestDimension(evals: EvalEntry[]): { dimension: string; score: number } | null {
  if (evals.length === 0) return null

  const latest = evals
    .sort((a, b) => b.ts.localeCompare(a.ts))[0]

  if (!latest.metrics || Object.keys(latest.metrics).length === 0) return null

  let lowestDim = ""
  let lowestScore = Infinity
  for (const [dim, score] of Object.entries(latest.metrics)) {
    if (typeof score === "number" && score < lowestScore) {
      lowestScore = score
      lowestDim = dim
    }
  }

  if (!lowestDim) return null
  return { dimension: lowestDim, score: lowestScore }
}

function findRegressedDimensions(evals: EvalEntry[]): Array<{ dimension: string; delta: number }> {
  if (evals.length < 2) return []

  const sorted = evals.sort((a, b) => b.ts.localeCompare(a.ts))
  const latest = sorted[0]
  const previous = sorted[1]

  if (!latest?.metrics || !previous?.metrics) return []

  const regressed: Array<{ dimension: string; delta: number }> = []
  for (const [dim, score] of Object.entries(latest.metrics)) {
    const prevScore = previous.metrics[dim]
    if (typeof score === "number" && typeof prevScore === "number" && score < prevScore) {
      regressed.push({ dimension: dim, delta: score - prevScore })
    }
  }

  return regressed.sort((a, b) => a.delta - b.delta)
}

async function runExperiment(projectRoot: string): Promise<void> {
  console.log(chalk.bold("\n  Peter Parker - Proactive Experiment Selection\n"))

  const loader = new TrajectoryLoader(projectRoot)
  const evals = readEvals(projectRoot)

  if (evals.length === 0) {
    console.log(chalk.yellow("  No eval history yet -- run `tenet peter pr` first to build a baseline.\n"))
    return
  }

  const trajectoryEntries = loader.load({ maxAge: "30d", limit: 50 })
  const experimentEntries = loader.load({ type: "experiment", maxAge: "30d", limit: 20 })
  const pastTitles = experimentEntries.map(e => e.title)

  console.log(chalk.gray(`  Loaded ${evals.length} eval entries, ${trajectoryEntries.length} trajectory entries`))

  let proposal: ExperimentProposal | null = null

  const stratusKey = process.env.STRATUS_API_KEY
  const stratusUrl = process.env.STRATUS_API_URL || "https://api.stratus.run"

  if (stratusKey) {
    console.log(chalk.gray("  Using Stratus to rank experiment proposals...\n"))

    try {
      const { StratusClient } = await import("../lib/stratus-client.js")
      const stratus = new StratusClient({
        baseUrl: stratusUrl,
        apiKey: stratusKey,
        model: "stratus-x1ac-base-claude-sonnet-4-6",
        timeout: 60000,
      })

      const evalSummary = buildEvalSummary(evals, 15)
      const trajectoryContext = loader.renderForContext(
        loader.deduplicate(experimentEntries.slice(0, 10))
      )

      const prompt = `Given the following experiment trajectory and eval history, suggest the top 3 improvements that would most increase the composite eval score.

Recent eval entries:
${evalSummary}

Recent experiment outcomes:
${trajectoryContext}

What has been tried (avoid repeats):
${pastTitles.length > 0 ? pastTitles.map(t => `- ${t}`).join("\n") : "Nothing yet"}

For each suggestion, provide a JSON array with objects having these fields:
- task: one-line description of what to implement
- predicted_delta: estimated score improvement (0.0 to 1.0)
- reasoning: why this would help
- risk: what could go wrong

Respond with ONLY a JSON array, no other text.`

      const response = await stratus.reason(prompt, {
        temperature: 0.7,
        maxTokens: 1500,
        featureContext: "experiment-selection",
      })

      const content = response.choices[0]?.message?.content || ""

      const jsonMatch = content.match(/\[[\s\S]*\]/)
      if (jsonMatch) {
        let proposals: ExperimentProposal[] = JSON.parse(jsonMatch[0])
        if (proposals.length > 0) {
          proposals.sort((a, b) => b.predicted_delta - a.predicted_delta)

          const recentDeltas = experimentEntries
            .slice(0, 5)
            .map(e => (e as any).score_delta ?? 0)
            .filter((d: number) => typeof d === "number")

          // Use planning loop (PH → WM rollouts) when available, fallback to rerank
          const planResult = await planWithRollouts(
            projectRoot, "peter-parker",
            "Select highest-impact experiment for eval score improvement",
            proposals, evals, recentDeltas,
          )
          proposals = planResult.proposals

          console.log(chalk.bold("  Top 3 Proposals:\n"))
          for (let i = 0; i < Math.min(3, proposals.length); i++) {
            const p = proposals[i]
            const rank = i + 1
            console.log(chalk.cyan(`  ${rank}. ${p.task}`))
            console.log(chalk.gray(`     Delta: +${p.predicted_delta.toFixed(4)}  |  Risk: ${p.risk}`))
            console.log(chalk.gray(`     Reasoning: ${p.reasoning}\n`))
          }

          proposal = proposals[0]
        }
      }

      if (!proposal) {
        console.log(chalk.yellow("  Stratus returned no parseable proposals, falling back to heuristic"))
      }
    } catch (err: any) {
      console.log(chalk.yellow(`  Stratus call failed: ${err.message}`))
      console.log(chalk.gray("  Falling back to heuristic approach\n"))
    }
  }

  if (!proposal) {
    console.log(chalk.gray("  Using heuristic: targeting lowest-scoring eval dimension\n"))

    const regressed = findRegressedDimensions(evals)
    const lowest = findLowestDimension(evals)

    if (regressed.length > 0) {
      const worst = regressed[0]
      proposal = {
        task: `Improve ${worst.dimension} score which regressed by ${worst.delta.toFixed(4)} in the latest eval. Analyze recent changes that may have caused the regression and fix them.`,
        predicted_delta: Math.abs(worst.delta),
        reasoning: `${worst.dimension} regressed by ${worst.delta.toFixed(4)} -- recovering this regression is the highest-value action`,
        risk: "Fix may not fully recover the regression if root cause is structural",
      }
      console.log(chalk.cyan(`  Target: ${worst.dimension} (regressed by ${worst.delta.toFixed(4)})`))
    } else if (lowest) {
      proposal = {
        task: `Improve ${lowest.dimension} score (currently ${lowest.score.toFixed(4)}) which is the lowest-performing eval dimension. Focus changes on improving this specific metric.`,
        predicted_delta: Math.max(0.01, (1 - lowest.score) * 0.1),
        reasoning: `${lowest.dimension} at ${lowest.score.toFixed(4)} is the weakest dimension -- improving it has the most room for composite score gains`,
        risk: "Improvements to one dimension may trade off against others",
      }
      console.log(chalk.cyan(`  Target: ${lowest.dimension} (score: ${lowest.score.toFixed(4)})`))
    } else {
      console.log(chalk.yellow("  Could not determine a target dimension from eval history.\n"))
      return
    }
  }

  console.log(chalk.bold(`\n  Selected experiment:`))
  console.log(chalk.white(`  Task: ${proposal.task}`))
  console.log(chalk.gray(`  Predicted delta: +${proposal.predicted_delta.toFixed(4)}`))
  console.log(chalk.gray(`  Risk: ${proposal.risk}\n`))

  writeJournalEntry(projectRoot, {
    v: 1,
    ts: new Date().toISOString(),
    session: "peter-experiment",
    type: "experiment",
    status: "incomplete",
    title: `Experiment: ${proposal.task.slice(0, 80)}`,
    summary: `Proactive experiment selected. Predicted delta: +${proposal.predicted_delta.toFixed(4)}. ${proposal.reasoning}`,
    detail: `Task: ${proposal.task}\nRisk: ${proposal.risk}`,
    hypothesis: `Implementing "${proposal.task}" will improve composite score by ~${proposal.predicted_delta.toFixed(4)}`,
    agent_id: "peter-parker",
  })

  await postHubEvent(projectRoot, "peter:task-selected", {
    task: proposal.task,
    predicted_delta: proposal.predicted_delta,
    source: "experiment",
    reasoning: proposal.reasoning,
  })

  // Create GitHub Issue for the experiment
  try {
    const { GitHubKanban } = await import("../lib/kanban-github.js")
    const kb = new GitHubKanban(projectRoot)
    const issueNum = await kb.create({
      title: proposal.task.slice(0, 120),
      description: `Predicted delta: +${proposal.predicted_delta.toFixed(4)}. ${proposal.reasoning}\n\nAuthored-by: peter-parker (tenet-cli)`,
      source: "agent",
      priority: Math.round(proposal.predicted_delta * 10),
      agent: "peter-parker",
      labels: ["agent"],
    })
    if (issueNum) {
      kb.pick(issueNum, "peter-parker")
      console.log(chalk.gray(`  📋 Issue #${issueNum} → in_progress`))
    }
  } catch {}

  console.log(chalk.cyan("  Dispatching to Peter Parker PR workflow...\n"))
  await runWithPR(projectRoot, proposal.task)
}

interface AutoresearchOptions {
  rounds: number
  budget?: number
  usePi?: boolean
  reviewer_model?: string
  scope_files?: string[]
}

async function runAutoresearch(projectRoot: string, options: AutoresearchOptions): Promise<void> {
  const { rounds, budget, usePi, reviewer_model, scope_files } = options

  console.log(chalk.bold(`\n  Peter Parker - Autoresearch Mode (${rounds} rounds)\n`))
  console.log(chalk.gray("  Pattern: branch → change → eval → keep|revert → repeat"))
  console.log(chalk.gray("  Only the winning experiment gets a PR."))
  if (budget) {
    console.log(chalk.gray(`  Budget: $${budget.toFixed(2)}`))
  }
  if (usePi || (usePi !== false && hasPi())) {
    console.log(chalk.cyan("  Runtime: Pi (RPC)"))
  } else {
    console.log(chalk.gray("  Runtime: claude CLI"))
  }
  console.log()

  // Initialize Pi runtime if available
  const piState = await initPiRuntime(projectRoot, { budget, usePi })
  const usePiRuntime = piState.bridge !== null

  // Start event router to listen for eval regressions
  if (piState.eventRouter && piState.bridge) {
    piState.eventRouter.registerBridge("experiment", piState.bridge)
    try {
      await piState.eventRouter.startSse()
    } catch {
      // Fall back to polling if SSE not available
      await piState.eventRouter.startPolling(5000)
    }
  }

  // Register bridge with cost monitor
  if (piState.costMonitor && piState.bridge) {
    piState.costMonitor.registerBridge("experiment", piState.bridge)
  }

  // Only require ralph-tui if not using Pi
  if (!usePiRuntime && !hasRalphTui()) {
    console.log(chalk.yellow("  ralph-tui is not installed (and Pi not available)"))
    console.log(chalk.gray("  Install: bun install -g ralph-tui\n"))
    return
  }

  if (!usePiRuntime) {
    const configPath = path.join(projectRoot, ".ralph-tui", "config.toml")
    if (!fs.existsSync(configPath)) {
      console.log(chalk.yellow("  No Peter Parker config found"))
      console.log(chalk.gray("  Run: tenet peter setup\n"))
      return
    }
  }

  const loader = new TrajectoryLoader(projectRoot)
  const evals = readEvals(projectRoot)

  if (evals.length === 0) {
    console.log(chalk.yellow("  No eval history. Run `tenet peter pr` first.\n"))
    return
  }

  const baseBranch = "main"
  const latestEval = evals.sort((a, b) => b.ts.localeCompare(a.ts))[0]
  const baselinePassRate = latestEval?.composite ?? 0
  const baselineTotal = (latestEval?.metrics?.tests_total as number) ?? 0
  const baselineScore = baselinePassRate + (baselineTotal > 0 ? baselineTotal * 0.001 : 0)

  console.log(chalk.gray(`  Baseline composite: ${baselineScore.toFixed(4)} (${baselineTotal} tests)`))

  interface ExperimentResult {
    round: number
    task: string
    score: number
    delta: number
    testsPassing: number
    testsTotal: number
    branch: string
    review?: string
    reviewVerdict?: "approve" | "request_changes" | "comment"
  }

  const results: ExperimentResult[] = []
  let bestResult: ExperimentResult | null = null

  for (let round = 1; round <= rounds; round++) {
    console.log(chalk.bold(`\n  ── Round ${round}/${rounds} ${"─".repeat(40)}\n`))

    const experimentEntries = loader.load({ type: "experiment", maxAge: "30d", limit: 20 })
    const pastTitles = [
      ...experimentEntries.map(e => e.title),
      ...results.map(r => r.task),
    ]

    let proposal: ExperimentProposal | null = null

    const stratusKey = process.env.STRATUS_API_KEY
    if (stratusKey) {
      try {
        const { StratusClient } = await import("../lib/stratus-client.js")
        const stratus = new StratusClient({
          baseUrl: process.env.STRATUS_API_URL || "https://api.stratus.run",
          apiKey: stratusKey,
          model: "stratus-x1ac-base-claude-sonnet-4-6",
          timeout: 60000,
        })

        const evalSummary = buildEvalSummary(evals.concat(
          results.map(r => ({
            v: 1 as const, ts: new Date().toISOString(), agent: "autoresearch",
            run_id: `autoresearch-r${r.round}`,
            metrics: { composite: r.score }, composite: r.score,
            model_version: `round-${r.round}`,
          }))
        ), 15)

        const policyHead = new PolicyHeadInference(projectRoot)
        const useMultiProposal = policyHead.isLoaded

        // v2 policy head: get recommended action type before generating proposals
        let actionGuidance = ""
        if (policyHead.isLoaded && policyHead.version >= 2) {
          try {
            const rlState = buildRLState(evals, round, results.slice(-5).map(r => r.delta))
            const selection = await policyHead.selectAction(rlState, "Improve codebase quality")
            actionGuidance = `\nPolicy head recommends action type: "${selection.action}" (confidence: ${(selection.confidence * 100).toFixed(0)}%).`
            if (selection.alternatives.length > 0) {
              actionGuidance += ` Alternatives: ${selection.alternatives.map(a => `${a.action}(${(a.confidence * 100).toFixed(0)}%)`).join(", ")}.`
            }
            actionGuidance += `\nFavor proposals that align with the "${selection.action}" action type.`
            console.log(chalk.magenta(`  Policy head v2 recommends: ${selection.action} (${(selection.confidence * 100).toFixed(0)}%)`))
          } catch {
            // v2 not available, continue without guidance
          }
        }

        const prompt = useMultiProposal
          ? `Autoresearch round ${round}/${rounds}. Suggest 3 specific improvements ranked by expected impact.
${actionGuidance}
Eval history:
${evalSummary}

Already tried (avoid these):
${pastTitles.map(t => `- ${t}`).join("\n") || "Nothing yet"}

Previous rounds this session:
${results.map(r => `- Round ${r.round}: "${r.task}" → delta=${r.delta > 0 ? "+" : ""}${r.delta.toFixed(4)}`).join("\n") || "None yet"}

Respond with ONLY a JSON array of 3 objects: [{"task": "...", "predicted_delta": 0.0-1.0, "reasoning": "...", "risk": "..."}, ...]`
          : `Autoresearch round ${round}/${rounds}. Suggest ONE specific improvement.
${actionGuidance}
Eval history:
${evalSummary}

Already tried (avoid these):
${pastTitles.map(t => `- ${t}`).join("\n") || "Nothing yet"}

Previous rounds this session:
${results.map(r => `- Round ${r.round}: "${r.task}" → delta=${r.delta > 0 ? "+" : ""}${r.delta.toFixed(4)}`).join("\n") || "None yet"}

Suggest the SINGLE highest-value change. JSON format:
{"task": "...", "predicted_delta": 0.0-1.0, "reasoning": "...", "risk": "..."}`

        const response = await stratus.reason(prompt, {
          temperature: 0.8 + (round * 0.05),
          maxTokens: useMultiProposal ? 1500 : 500,
          featureContext: "autoresearch",
        })

        const content = response.choices[0]?.message?.content || ""

        if (useMultiProposal) {
          const jsonMatch = content.match(/\[[\s\S]*\]/)
          if (jsonMatch) {
            let proposals: ExperimentProposal[] = JSON.parse(jsonMatch[0])
            const recentDeltas = results.slice(-5).map(r => r.delta)
            // Use planning loop (PH → WM rollouts) when available
            const planResult = await planWithRollouts(
              projectRoot, "peter-parker",
              `Autoresearch round ${round}: improve eval score`,
              proposals, evals, recentDeltas,
            )
            proposals = planResult.proposals
            if (proposals.length > 0) proposal = proposals[0]
          }
        }

        if (!proposal) {
          const jsonMatch = content.match(/\{[\s\S]*\}/)
          if (jsonMatch) {
            proposal = JSON.parse(jsonMatch[0]) as ExperimentProposal
          }
        }
      } catch (err: any) {
        console.log(chalk.yellow(`  Stratus failed: ${err.message}`))
      }
    }

    if (!proposal) {
      const regressed = findRegressedDimensions(evals)
      const lowest = findLowestDimension(evals)

      if (regressed.length > 0) {
        const worst = regressed[0]
        proposal = {
          task: `Improve ${worst.dimension} score (regressed by ${worst.delta.toFixed(4)})`,
          predicted_delta: Math.abs(worst.delta),
          reasoning: `Recovering ${worst.dimension} regression`,
          risk: "May not fully recover",
        }
      } else if (lowest) {
        proposal = {
          task: `Improve ${lowest.dimension} score (currently ${lowest.score.toFixed(4)})`,
          predicted_delta: Math.max(0.01, (1 - lowest.score) * 0.1),
          reasoning: `${lowest.dimension} is weakest dimension`,
          risk: "May trade off against others",
        }
      } else {
        console.log(chalk.yellow("  No target found, skipping round"))
        continue
      }
    }

    console.log(chalk.cyan(`  Task: ${proposal.task}`))
    console.log(chalk.gray(`  Predicted: +${proposal.predicted_delta.toFixed(4)}\n`))

    const branchName = `pp/autoresearch-r${round}-${Date.now()}`

    gitExec(["stash", "--include-untracked"], projectRoot)
    gitExec(["fetch", "origin", baseBranch], projectRoot)

    let checkout = gitExec(["checkout", "-b", branchName, `origin/${baseBranch}`], projectRoot)
    if (!checkout.ok) {
      checkout = gitExec(["checkout", "-b", branchName, baseBranch], projectRoot)
    }
    if (!checkout.ok) {
      console.log(chalk.red(`  Failed to create branch ${branchName}`))
      continue
    }

    // Run the task using Pi runtime or claude CLI
    if (usePiRuntime && piState.bridge) {
      try {
        await runTaskWithPi(piState.bridge, proposal!.task, piState.costMonitor, 300000)
      } catch (err: any) {
        console.log(chalk.yellow(`  Pi task failed: ${err.message}`))
      }
    } else {
      // Fall back to claude CLI
      await new Promise<void>((resolve) => {
        const ralphDir = path.join(projectRoot, ".ralph-tui")
        if (!fs.existsSync(ralphDir)) fs.mkdirSync(ralphDir, { recursive: true })

        const prdPath = path.join(ralphDir, "autoresearch-task.json")
        const prd = {
          name: "Autoresearch Task",
          branchName: `ralph/autoresearch-${Date.now()}`,
          description: proposal!.task,
          userStories: [{
            id: "US-001",
            title: proposal!.task.slice(0, 80),
            description: proposal!.task,
            acceptanceCriteria: ["Task completed"],
            priority: 1, passes: false, notes: "", dependsOn: [],
          }],
          metadata: { updatedAt: new Date().toISOString() },
        }
        fs.writeFileSync(prdPath, JSON.stringify(prd, null, 2))

        const env = { ...process.env }
        delete env.CLAUDECODE
        delete env.CLAUDE_CODE

        const child = spawn("claude", [
          "--dangerously-skip-permissions",
          "-p", proposal!.task,
          "--output-format", "text",
        ], {
          cwd: projectRoot, stdio: "inherit", env,
        })

        child.on("error", () => { try { fs.unlinkSync(prdPath) } catch {} resolve() })
        child.on("exit", () => { try { fs.unlinkSync(prdPath) } catch {} resolve() })
      })
    }

    const diffCheck = gitExec(["diff", "--quiet", "HEAD"], projectRoot)
    const untrackedResult = spawnSync("git", ["ls-files", "--others", "--exclude-standard"], {
      cwd: projectRoot, encoding: "utf-8", stdio: "pipe",
    })
    const hasChanges = !diffCheck.ok || (untrackedResult.stdout || "").trim().length > 0

    if (!hasChanges) {
      console.log(chalk.yellow(`  Round ${round}: No changes, skipping eval`))
      gitExec(["checkout", baseBranch], projectRoot)
      gitExec(["branch", "-D", branchName], projectRoot)
      continue
    }

    signedAgentCommit(projectRoot, `autoresearch: round ${round} - ${proposal.task}`, {
      agentId: "peter-parker",
      sessionId: `autoresearch-r${round}`,
    })

    console.log(chalk.gray("  Running local eval..."))
    const testResult = spawnSync("npx", ["jest", "--json", "--silent"], {
      cwd: projectRoot, encoding: "utf-8", stdio: "pipe", timeout: 120000,
    })

    let passing = 0, total = 1
    try {
      const json = JSON.parse(testResult.stdout || "{}")
      passing = json.numPassedTests || 0
      total = json.numTotalTests || 1
    } catch {}

    const passRate = total > 0 ? passing / total : 0
    const testsAdded = total - baselineTotal
    const score = passRate + (testsAdded > 0 ? testsAdded * 0.001 : 0)
    const delta = score - baselineScore

    const result: ExperimentResult = {
      round,
      task: proposal.task,
      score,
      delta,
      testsPassing: passing,
      testsTotal: total,
      branch: branchName,
    }
    results.push(result)

    const emoji = delta > 0 ? "+" : delta < 0 ? "" : "="
    console.log(chalk.bold(`  Round ${round} result: ${score.toFixed(4)} (${emoji}${delta.toFixed(4)})`))
    console.log(chalk.gray(`  Tests: ${passing}/${total}${testsAdded > 0 ? chalk.green(` (+${testsAdded} new)`) : ""}`))

    // Cross-model review: if reviewer_model is configured, get qualitative feedback
    if (reviewer_model && (delta > 0 || testsAdded > 0)) {
      try {
        const diffStat = gitExec(["diff", "HEAD~1", "--stat"], projectRoot)
        const diffFiles = scope_files?.length ? ["--", ...scope_files] : []
        const diffFull = gitExec(["diff", "HEAD~1", ...diffFiles], projectRoot)
        const diffPreview = (diffFull.output || "").slice(0, 3000)

        console.log(chalk.cyan(`  Cross-model review (${reviewer_model})...`))
        const reviewPrompt = `You are a code reviewer using a DIFFERENT model than the author. Review this diff for quality issues the author's model might be blind to.\n\nTask: ${proposal.task}\nScore delta: ${delta > 0 ? "+" : ""}${delta.toFixed(4)}\n\nDiff:\n${diffPreview}\n\nRate: APPROVE / REQUEST_CHANGES / COMMENT\nBe brief (2-3 sentences max).`

        const { spawnSync: sp } = await import("child_process")
        const reviewResult = sp("claude", ["-p", reviewPrompt, "--output-format", "text", "--model", reviewer_model], {
          cwd: projectRoot, encoding: "utf-8", timeout: 60000, stdio: "pipe",
          env: { ...process.env, CLAUDECODE: undefined, CLAUDE_CODE: undefined },
        })
        const reviewText = (reviewResult.stdout || "").trim()
        if (reviewText) {
          const verdict = reviewText.includes("REQUEST_CHANGES") ? chalk.yellow("REQUEST_CHANGES") :
                          reviewText.includes("APPROVE") ? chalk.green("APPROVE") : chalk.gray("COMMENT")
          console.log(`  Review: ${verdict}`)
          console.log(chalk.gray(`  ${reviewText.split("\n").slice(0, 3).join("\n  ")}`))
          result.review = reviewText
          result.reviewVerdict = reviewText.includes("REQUEST_CHANGES") ? "request_changes" : reviewText.includes("APPROVE") ? "approve" : "comment"
        }
      } catch {
        // Non-fatal — cross-model review is advisory
      }
    }

    if (!bestResult || result.delta > bestResult.delta) {
      bestResult = result
      console.log(chalk.green(`  New best! (round ${round})`))
    }

    writeJournalEntry(projectRoot, {
      v: 1,
      ts: new Date().toISOString(),
      session: "autoresearch",
      type: "experiment",
      status: (delta > 0 || testsAdded > 0) ? "complete" : "incomplete",
      title: `Autoresearch R${round}: ${proposal.task.slice(0, 60)}`,
      summary: `Score: ${score.toFixed(4)}, delta: ${delta > 0 ? "+" : ""}${delta.toFixed(4)}`,
      detail: `Task: ${proposal.task}\nResult: ${passing}/${total} tests passing`,
      hypothesis: `"${proposal.task}" improves composite by ~${proposal.predicted_delta.toFixed(4)}`,
      outcome: delta > 0 ? "confirmed" : delta < 0 ? "rejected" : "inconclusive",
      score_delta: delta,
      agent_id: "peter-parker",
    })

    const tb = new TrainingBuffer(projectRoot)
    tb.append({
      agent: "peter-parker",
      state: {
        composite_score: baselineScore,
        dimension_scores: evals.sort((a, b) => b.ts.localeCompare(a.ts))[0]?.metrics ?? {},
        tests_passing: evals.sort((a, b) => b.ts.localeCompare(a.ts))[0]?.metrics?.tests_passed as number ?? 0,
        tests_total: evals.sort((a, b) => b.ts.localeCompare(a.ts))[0]?.metrics?.tests_total as number ?? 1,
        trajectory_length: results.length,
        recent_deltas: results.slice(-5).map(r => r.delta),
        agent: "peter-parker",
      },
      action: {
        type: "experiment",
        description: proposal.task,
        files_affected: [],
        scope: "medium",
        branch: branchName,
      },
      reward: {
        composite_delta: delta,
        dimension_deltas: {},
        tests_added: testsAdded,
        quality_score: passRate,
        improved: delta > 0 || testsAdded > 0,
        prediction_error: Math.abs(proposal.predicted_delta - delta),
        // reward_tuple_v2 (#3047) — peter autoresearch round is settled
        // at the eval boundary; merge/PR fields follow on dispatch.
        tuple_status: "settled",
        eval_delta: delta,
      },
      metadata: {
        branch: branchName,
        autoresearch_round: round,
        source: "autoresearch",
        reward_source: "peter-autoresearch",
      },
    })

    // Update GitHub Issue — move done or revert to backlog
    try {
      const { GitHubKanban } = await import("../lib/kanban-github.js")
      const kb = new GitHubKanban(projectRoot)
      const cards = await kb.getCards({ column: "in_progress" })
      const ppCards = cards.filter(c => c.agent === "peter-parker")
      if (ppCards.length > 0) {
        const card = ppCards[ppCards.length - 1]
        if (delta > 0 || testsAdded > 0) {
          kb.move(card.number, "done")
          console.log(chalk.gray(`  📋 Issue ${card.id} → done (${score.toFixed(4)})`))
        } else {
          kb.move(card.number, "backlog")
          console.log(chalk.gray(`  📋 Issue ${card.id} → backlog (no improvement)`))
        }
      }
    } catch {}

    gitExec(["checkout", baseBranch], projectRoot)
  }

  console.log(chalk.bold(`\n  ── Autoresearch Complete ${"─".repeat(35)}\n`))
  console.log(chalk.gray(`  Rounds: ${rounds}`))
  console.log(chalk.gray(`  Results:`))

  for (const r of results) {
    const emoji = r.delta > 0 ? chalk.green("+") : r.delta < 0 ? chalk.red("-") : chalk.gray("=")
    const best = bestResult && r.round === bestResult.round ? chalk.yellow(" ★") : ""
    console.log(chalk.gray(`    R${r.round}: ${r.score.toFixed(4)} (${emoji}${Math.abs(r.delta).toFixed(4)}) ${r.task.slice(0, 50)}${best}`))
  }

  if (bestResult && bestResult.delta > 0) {
    console.log(chalk.green(`\n  Winner: Round ${bestResult.round} (${bestResult.delta > 0 ? "+" : ""}${bestResult.delta.toFixed(4)})`))
    console.log(chalk.cyan("  Creating PR for winning experiment...\n"))

    gitExec(["checkout", bestResult.branch], projectRoot)
    const pushResult = gitExec(["push", "-u", "origin", bestResult.branch], projectRoot)

    if (pushResult.ok) {
      const prTitle = `PP autoresearch: ${bestResult.task.slice(0, 50)} (+${bestResult.delta.toFixed(4)})`
      const prBody = [
        "## Autoresearch Winner",
        "",
        `**Task:** ${bestResult.task}`,
        `**Score:** ${bestResult.score.toFixed(4)} (delta: +${bestResult.delta.toFixed(4)})`,
        `**Tests:** ${bestResult.testsPassing}/${bestResult.testsTotal}`,
        `**Round:** ${bestResult.round}/${rounds}`,
        "",
        "### All Rounds",
        ...results.map(r =>
          `- R${r.round}: ${r.score.toFixed(4)} (${r.delta > 0 ? "+" : ""}${r.delta.toFixed(4)}) ${r.task.slice(0, 60)}${r.round === bestResult!.round ? " **← winner**" : ""}`
        ),
        "",
        "---",
        "*Generated by TENET autoresearch loop*",
      ].join("\n")

      let prResult = ghExec([
        "pr", "create", "--title", prTitle, "--body", prBody,
        "--base", baseBranch, "--head", bestResult.branch, "--label", "pp-generated",
      ], projectRoot)
      if (!prResult.ok) {
        prResult = ghExec([
          "pr", "create", "--title", prTitle, "--body", prBody,
          "--base", baseBranch, "--head", bestResult.branch,
        ], projectRoot)
      }

      if (prResult.ok) {
        console.log(chalk.green(`  PR created: ${prResult.output}`))
        await postHubEvent(projectRoot, "autoresearch:complete", {
          rounds,
          winner_round: bestResult.round,
          winner_task: bestResult.task,
          winner_delta: bestResult.delta,
          pr_url: prResult.output,
          all_results: results.map(r => ({
            round: r.round, task: r.task, score: r.score, delta: r.delta,
          })),
        })
      } else {
        console.log(chalk.red(`  Failed to create PR: ${prResult.output}`))
      }
    } else {
      console.log(chalk.red(`  Failed to push: ${pushResult.output}`))
    }

    gitExec(["checkout", baseBranch], projectRoot)
  } else {
    console.log(chalk.yellow("\n  No improvement found across all rounds."))
    console.log(chalk.gray("  All experiment branches preserved for review.\n"))
  }

  for (const r of results) {
    if (!bestResult || r.round !== bestResult.round) {
      gitExec(["branch", "-D", r.branch], projectRoot)
    }
  }

  gitExec(["stash", "pop"], projectRoot)

  // Shutdown Pi runtime
  if (piState.bridge || piState.eventRouter) {
    console.log(chalk.gray("  Shutting down Pi runtime..."))
    await shutdownPiRuntime(piState)
    if (piState.costMonitor) {
      console.log(chalk.gray(`  Total cost: $${piState.costMonitor.totalCost.toFixed(4)}`))
    }
  }

  console.log()
}

// ============================================================================
// Scoped Agent Commands
// ============================================================================

async function agentCreate(projectRoot: string): Promise<void> {
  const { writeAgentConfig, generateAgentToml } = await import("../lib/agent-config.js")
  const readline = await import("readline")

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  })

  const ask = (q: string): Promise<string> =>
    new Promise(resolve => rl.question(q, resolve))

  console.log(chalk.bold("\n  Create Scoped Agent\n"))

  const name = await ask("  Agent name (e.g., search-quality): ")
  const scope = await ask("  Scope (e.g., search, tests, quality): ")
  const metric = await ask("  Metric (e.g., ndcg@10, test_pass_rate): ")
  const direction = await ask("  Direction (maximize/minimize) [maximize]: ") || "maximize"
  const timeBudget = await ask("  Time budget seconds [300]: ") || "300"
  const evalScript = await ask("  Eval script path [eval/eval.ts]: ") || "eval/eval.ts"
  const evalData = await ask("  Eval data path [eval/fixtures/data.jsonl]: ") || "eval/fixtures/data.jsonl"
  const filesInScope = await ask("  Files in scope (glob, comma-sep) [src/**]: ") || "src/**"

  rl.close()

  const configPath = writeAgentConfig(projectRoot, {
    name,
    scope,
    metric,
    direction: direction as "maximize" | "minimize",
    time_budget_seconds: parseInt(timeBudget, 10),
    eval: {
      script: evalScript,
      data: evalData,
    },
    constraints: {
      files_in_scope: filesInScope.split(",").map(s => s.trim()),
      files_readonly: ["eval/**"],
      max_file_changes: 10,
    },
    policy: {
      embedding_model: "stratus-x1ac-base-claude-sonnet-4-6",
      exploration_rate: 0.2,
      decay_per_round: 0.01,
      min_exploration: 0.05,
    },
  })

  console.log(chalk.green(`\n  Agent config created: ${configPath}\n`))
}

async function agentList(projectRoot: string): Promise<void> {
  const { listAgentConfigs, loadAgentConfig } = await import("../lib/agent-config.js")

  const agents = listAgentConfigs(projectRoot)

  if (agents.length === 0) {
    console.log(chalk.yellow("\n  No agents configured."))
    console.log(chalk.gray("  Run: tenet peter agent create\n"))
    return
  }

  console.log(chalk.bold("\n  Configured Agents\n"))

  for (const name of agents) {
    try {
      const config = loadAgentConfig(projectRoot, name)
      console.log(chalk.cyan(`  ${name}`))
      console.log(chalk.gray(`    Scope: ${config.scope}`))
      console.log(chalk.gray(`    Metric: ${config.metric} (${config.direction})`))
      console.log(chalk.gray(`    Time budget: ${config.time_budget_seconds}s`))
      console.log(chalk.gray(`    Files: ${config.constraints.files_in_scope.join(", ")}`))
      console.log()
    } catch (err: any) {
      console.log(chalk.red(`  ${name}: Error loading config - ${err.message}`))
    }
  }
}

async function agentRun(
  projectRoot: string,
  agentName: string,
  roundsOverride?: number,
  opts: { fast?: boolean; fromIssue?: number } = {}
): Promise<void> {
  const { loadAgentConfig, validateAgentConfig } = await import("../lib/agent-config.js")
  const { startSession, runBaseline, runRound, endSession, saveSessionState, writeExperimentHistory } = await import("../lib/agent-session.js")
  const { ReplayBuffer } = await import("../lib/replay-buffer.js")
  const { StratusClient } = await import("../lib/stratus-client.js")

  // Load and validate config
  let config
  try {
    config = loadAgentConfig(projectRoot, agentName)
  } catch (err: any) {
    // Surface the actual error so the operator sees the real cause
    // (e.g. "eval.data is required") rather than a misleading
    // "Agent not found" — that masked the build-q3032 silent failure
    // for hours on 2026-04-30 night. Per F-004 in FAILURE_MODES.md.
    const msg = err?.message ?? String(err)
    console.log(chalk.red(`\n  Could not load agent config for "${agentName}":`))
    console.log(chalk.red(`    ${msg}`))
    console.log(chalk.gray(`\n  TOML path: ${path.join(projectRoot, ".tenet", "agents", `${agentName}.toml`)}`))
    console.log(chalk.gray("  Run: tenet peter agent list\n"))
    // Exit non-zero. The note above says louder output was the fix for the
    // build-q3032 silent failure, but a caller does not read output — the
    // fleet daemon routes on exit codes, and a config that never loaded
    // exiting 0 is indistinguishable from an agent that ran and succeeded.
    process.exitCode = 1
    return
  }

  const validation = validateAgentConfig(config, projectRoot)
  if (!validation.valid) {
    console.log(chalk.red(`\n  Invalid agent config:`))
    for (const err of validation.errors) {
      console.log(chalk.red(`    - ${err}`))
    }
    console.log()
    // Same reason: nothing ran, so the process must not report success.
    process.exitCode = 1
    return
  }

  // #3084 — `--from-issue N` injects the issue number into config.task.issue
  // so downstream code (agent-session.startSession + createPR + the PR-body
  // builder in endSession) picks it up via `(config as any).task?.issue` and
  // emits `Closes #N` in the converged PR. The TOML value (if any) wins on
  // mismatch ONLY when --from-issue is omitted; when the flag is provided it
  // overrides — the warn-on-mismatch already fired in build.runBuildAgent.
  if (opts.fromIssue !== undefined) {
    const cfg = config as any
    cfg.task = { ...(cfg.task || {}), issue: opts.fromIssue }
  }

  // Pre-flight guards — verify environment before starting session
  const { runGuards } = await import("../lib/agent-guards.js")
  const guardSummary = await runGuards(projectRoot, agentName, config)

  // Log guard results
  for (const result of guardSummary.results) {
    if (result.passed) {
      console.log(chalk.green(`  ✓ Guard: ${result.name}`))
    } else if (result.critical) {
      console.log(chalk.red(`  ✗ Guard: ${result.name} — ${result.reason}`))
    } else {
      console.log(chalk.yellow(`  ⚠ Guard: ${result.name} — ${result.reason}`))
    }
  }

  if (!guardSummary.proceed) {
    console.log(chalk.red(`\n  Blocked by ${guardSummary.blockers.length} critical guard(s). Fix the issues above and retry.\n`))
    return
  }

  if (guardSummary.warnings.length > 0) {
    console.log(chalk.yellow(`\n  ${guardSummary.warnings.length} warning(s) — proceeding anyway.\n`))
  } else {
    console.log()
  }

  // Use config.rounds as default (Karpathy: ~50 experiments per session)
  // Allow override via CLI for debugging/testing
  const rounds = roundsOverride ?? config.rounds ?? 50

  // Get scope_files for display
  const rawScopeFiles = config.constraints.scope_files || config.constraints.files_in_scope || []
  const displayScopeFiles = Array.isArray(rawScopeFiles) ? rawScopeFiles : [String(rawScopeFiles)]
  const scopeFilesDisplay = displayScopeFiles.slice(0, 3).join(", ") + (displayScopeFiles.length > 3 ? "..." : "")

  console.log(chalk.bold(`\n  Running Scoped Agent: ${agentName} (${rounds} rounds)\n`))
  console.log(chalk.gray(`  Metric: ${config.metric} (${config.direction})`))
  console.log(chalk.gray(`  Time budget: ${config.time_budget_seconds}s per round`))
  console.log(chalk.gray(`  Focus files: ${scopeFilesDisplay}`))
  console.log(chalk.gray(`  Pattern: branch → change → eval → keep|revert → repeat\n`))

  // Start session
  const session = startSession(config, projectRoot)
  saveSessionState(session)

  console.log(chalk.cyan(`  Session: ${session.id}`))
  console.log(chalk.cyan(`  Branch: ${session.branch}`))
  console.log(chalk.gray(`  Eval snapshot: ${session.evalSnapshot.hash.slice(0, 8)}\n`))

  // Run baseline
  console.log(chalk.gray("  Running baseline eval..."))
  let baseline
  try {
    baseline = await runBaseline(session)
  } catch (err: any) {
    console.log(chalk.red(`  Baseline eval failed: ${err.message}`))
    return
  }
  console.log(chalk.green(`  Baseline: ${baseline.toFixed(4)}\n`))

  const replayBuffer = new ReplayBuffer(projectRoot)
  const transitions: any[] = []

  // Stratus for task generation
  const stratus = process.env.STRATUS_API_KEY
    ? new StratusClient({ apiKey: process.env.STRATUS_API_KEY })
    : null

  // Get scope_files from config (Karpathy pattern: focused file list)
  const rawScope = (config.constraints as any).scope_files || config.constraints.files_in_scope || []
  const scopeFiles = Array.isArray(rawScope) ? rawScope : [String(rawScope)]
  const scopeFilesStr = scopeFiles.slice(0, 5).join(", ")

  // ── Build rich context for agent (autoresearch pattern: read before write) ──

  // 1. Read scope files from worktree so agent knows what code it's modifying
  let codeContext = ""
  for (const scopeFile of scopeFiles.slice(0, 4)) {
    const filePath = path.join(session.worktreePath, scopeFile)
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, "utf-8")
      const lines = content.split("\n").slice(0, 150) // First 150 lines
      codeContext += `\n--- ${scopeFile} (first ${lines.length} lines) ---\n${lines.join("\n")}\n`
    }
  }

  // 2. Parse eval diagnostics from baseline run (which queries fail, what scores broke down)
  let evalDiagnostics = ""
  const rawEvalOutput = (session as any).lastEvalOutput || ""
  if (rawEvalOutput) {
    try {
      const evalJson = JSON.parse(rawEvalOutput)
      // Extract failing queries/tests/dimensions for the agent to focus on
      if (evalJson.failed_queries) {
        evalDiagnostics = `\n\nFAILING QUERIES (fix these to improve the metric):\n${evalJson.failed_queries.map((q: string) => `  ✗ ${q}`).join("\n")}`
      }
      if (evalJson.per_query) {
        const failing = evalJson.per_query.filter((q: any) => q.hits < q.expected)
        if (failing.length > 0) {
          evalDiagnostics += `\n\nDETAILED FAILURES:\n${failing.slice(0, 5).map((q: any) =>
            `  Query: "${q.query}" — got ${q.hits}/${q.expected} hits. Found IDs: [${(q.found || []).join(",")}]`
          ).join("\n")}`
        }
      }
      // Generic: show any dimension breakdowns (easy/medium/hard, per-category scores)
      const dimKeys = Object.keys(evalJson).filter(k =>
        k.endsWith("_recall") || k.endsWith("_score") || k.endsWith("_pct") || k.endsWith("_count")
      )
      if (dimKeys.length > 0) {
        evalDiagnostics += `\n\nMETRIC BREAKDOWN:\n${dimKeys.map(k => `  ${k}: ${evalJson[k]}`).join("\n")}`
      }
    } catch {
      // Not JSON — include raw stderr/stdout hints
      const lines = rawEvalOutput.split("\n").filter((l: string) => l.includes("✗") || l.includes("fail") || l.includes("error") || l.includes("FAIL"))
      if (lines.length > 0) {
        evalDiagnostics = `\n\nEVAL DIAGNOSTICS:\n${lines.slice(0, 10).join("\n")}`
      }
    }
  }

  // ── Inject epistemic context ──────────────────────────────────────────
  try {
    const { mapBoundaries } = await import("../lib/epistemic-boundaries.js")
    const map = mapBoundaries(projectRoot)
    const relevantBlindSpots = map.blindSpots.filter((b: string) =>
      scopeFiles.some((f: string) => f.startsWith(b.replace(/\/$/, "")) || b.startsWith(f.split("/").slice(0, 2).join("/")))
    )
    if (relevantBlindSpots.length > 0) {
      console.log(chalk.yellow(`  ⚠ Epistemic blind spots in scope: ${relevantBlindSpots.slice(0, 3).join(", ")}`))
      const expPath = path.join(session.worktreePath, "EXPERIMENTS.md")
      fs.appendFileSync(expPath, `\n\n## Epistemic Context\nBlind spots in your file scope (approach carefully, read before writing):\n${relevantBlindSpots.map((b: string) => `- ${b}`).join("\n")}\n`)
    }
    console.log(chalk.gray(`  Epistemic coverage: ${map.coverage.toFixed(1)}%`))
  } catch {}

  // ── Write presence ────────────────────────────────────────────────────
  const presenceFile = path.join(projectRoot, ".tenet", "presence", `${config.name}.json`)
  try {
    const presenceDir = path.join(projectRoot, ".tenet", "presence")
    if (!fs.existsSync(presenceDir)) fs.mkdirSync(presenceDir, { recursive: true })
    fs.writeFileSync(presenceFile, JSON.stringify({
      agent: config.name, files: scopeFiles, started: new Date().toISOString(), pid: process.pid,
    }))
  } catch {}

  // ── Graph-guided briefing (Ship 3) ──────────────────────────────────
  // Assembled once per session and reused across rounds — corpus doesn't
  // change much within a session and assembleBrief loads the 2MB
  // journal-graph each call. v1 will refresh per round once that's a
  // measurable win. Errors swallowed: briefing is bonus context, not
  // load-bearing — if assembler can't reach the graph or scoring is empty,
  // the round still runs with existing historyContext + productContext +
  // evalDiagnostics chain.
  let briefContext = ""
  let briefingUsed = false
  let briefingHash = ""
  try {
    const { assembleBrief } = await import("../lib/briefing/assembler.js")
    const taskForBrief = (config as any).task?.description || `Improve ${config.metric}`
    const result = assembleBrief({
      task: taskForBrief,
      projectRoot,
      scope: undefined, // workspace-relative scoping not yet wired through
      filesInFocus: scopeFiles,
      budgetTokens: 2500, // half the default 4000 — leave room for evalDiagnostics + history + code
      agent: config.name,
      strategy: "tight",
    })
    if (result.provenance.n_kept > 0) {
      briefingHash = createHash("sha256")
        .update(result.markdown)
        .digest("hex")
        .slice(0, 12)
      briefContext = `\n\n## Graph-guided briefing (${result.provenance.n_kept} entries from journal-graph, ~${result.provenance.estimated_tokens} tokens)\n${result.markdown}\n`
      briefingUsed = true
      console.log(chalk.magenta(`  Briefing: ${result.provenance.n_kept} entries, ~${result.provenance.estimated_tokens} tokens, hash ${briefingHash}`))
    } else {
      console.log(chalk.gray("  Briefing: no relevant entries above MAD threshold (corpus too sparse?)"))
    }
  } catch (err: any) {
    // bonus context — never fail the build
    console.log(chalk.gray(`  Briefing: skipped (${err?.message?.slice(0, 60) ?? "unknown error"})`))
  }

  // Announce the run's stop conditions up front rather than discovering them
  // when one trips (Chadwick: posture is stated, never silent).
  const budgetConfig = budgetConfigFromEnv()
  console.log(chalk.gray(`  Limits: ${describeLimits(budgetConfig)}`))
  const roundSummaries: RoundSummary[] = []
  let runSpendUsd = 0

  for (let round = 1; round <= rounds; round++) {
    const budget = checkBudget(projectRoot, { spentThisRunUsd: runSpendUsd, config: budgetConfig })
    if (!budget.allowed) {
      console.log(chalk.yellow(`\n  ⚠ Stopping before round ${round}: ${budget.reason}`))
      break
    }

    console.log(chalk.bold(`\n  ── Round ${round}/${rounds} ${"─".repeat(40)}\n`))

    // Generate task — use TOML [task] description if present, otherwise default RL task
    let task: string
    if ((config as any).task?.description) {
      // Build agent — use spec task, prepend action-oriented instruction
      task = `BUILD TASK — Create the files described below. Write code immediately. Do NOT spend turns exploring — the eval diagnostics tell you exactly what's missing.

FAILED CHECKS (from eval):
${evalDiagnostics || 'Run eval to see what is missing.'}

YOUR TASK:
${(config as any).task.description}

IMPORTANT: Use write_file to create complete files. Every failed check above is something you need to fix. Start writing code NOW.`
    } else {
      task = `Improve ${config.metric} by modifying: ${scopeFilesStr}. Read the code context and eval diagnostics below. Make ONE small, focused change to the actual source files.${evalDiagnostics}`
    }

    // Build history context from replay buffer + current session transitions
    const pastTuples = replayBuffer.getForAgent(config.name).slice(-20) // Last 20 tuples
    const keptExperiments: string[] = []
    const rejectedExperiments: string[] = []

    // From replay buffer (past sessions)
    for (const t of pastTuples) {
      const action = t.action?.description || "unknown"
      const reward = t.reward ?? 0
      if (reward > 0) {
        keptExperiments.push(`"${action.slice(0, 50)}" (+${reward.toFixed(4)})`)
      } else {
        rejectedExperiments.push(`"${action.slice(0, 50)}"`)
      }
    }

    // From current session transitions
    for (const t of transitions) {
      const action = t.action?.description || "unknown"
      const reward = t.reward ?? 0
      if (reward > 0) {
        keptExperiments.push(`"${action.slice(0, 50)}" (+${reward.toFixed(4)})`)
      } else {
        rejectedExperiments.push(`"${action.slice(0, 50)}"`)
      }
    }

    let historyContext = ""
    if (keptExperiments.length > 0 || rejectedExperiments.length > 0) {
      historyContext = `

Experiment history for ${config.name}:
KEPT (these worked — build on them): ${keptExperiments.slice(-5).join(", ") || "none yet"}
REJECTED (do NOT repeat these): ${rejectedExperiments.slice(-5).join(", ") || "none yet"}

CRITICAL: Do NOT repeat rejected experiments. Try something NEW and DIFFERENT.`
    }

    // Read product context (Layer 2) if available
    let productContext = ""
    const productContextPath = path.join(projectRoot, ".tenet", "product-context.md")
    if (fs.existsSync(productContextPath)) {
      const pc = fs.readFileSync(productContextPath, "utf-8")
      // Extract agent-specific guidance if present
      const agentSection = pc.match(new RegExp(`${config.name}[:\\s].*?(?=\\n[A-Z#]|$)`, "s"))
      productContext = agentSection
        ? `\n\nProduct context for this agent:\n${agentSection[0].slice(0, 500)}`
        : `\n\nProduct context (summary):\n${pc.slice(0, 500)}`
    }

    if (stratus) {
      try {
        // Enhanced prompt with full context: briefing + eval failures + code + history.
        // briefContext is additive (per Ship 3 design) — historyContext +
        // productContext + evalDiagnostics each exist because of a documented
        // prior failure; do not remove them. Briefing is prepended because
        // narrative-thread context is most useful when read first.
        const prompt = `Suggest ONE specific code change to improve the ${config.metric} metric (${config.direction}).

FOCUS FILES (modify only these): ${scopeFilesStr}
CURRENT METRIC: ${session.baselineMetric.toFixed(4)}
ROUND: ${round}/${rounds}
${briefContext}
${evalDiagnostics}
${historyContext}${productContext}

CODE CONTEXT (first 150 lines of each scope file):
${codeContext.slice(0, 3000)}

Based on the failing queries/tests and the actual code, suggest ONE concrete change. Be specific about which function to modify and how. Return just the task description (2-3 sentences).`
        const response = await stratus.reason(prompt, { maxTokens: 300, temperature: 0.5 + round * 0.05 })
        task = response.choices[0]?.message?.content || task
      } catch {
        // Stratus failed — use the eval-diagnostics-enriched default task (still much better than before)
      }
    }

    const hypothesis = `Implementing this will improve ${config.metric}`

    console.log(chalk.cyan(`  Task: ${task.slice(0, 80)}...`))

    // Pass transitions to runRound so it can build experiment history (Karpathy pattern)
    const metricBefore = session.baselineMetric + transitions.reduce((acc, t) => acc + (t.reward ?? 0), 0)
    const { result, transition } = await runRound(session, round, task, hypothesis, transitions, undefined)
    transitions.push(transition)

    // Passive policy-head observation: ask the model what reward IT predicts
    // for this (state, action) and log alongside the actual outcome. Behavior
    // unchanged — pure observation. Feeds the gated-wedge decision in a
    // follow-up PR (active re-ranking) once we have enough real
    // (predicted, actual) pairs from build runs.
    await logPolicyObservation(
      projectRoot,
      config.name,
      session.id,
      session.branch ?? "",
      round,
      task,
      metricBefore,
      result,
      transitions.slice(0, -1),  // recent_deltas: prior to this round
      { used: briefingUsed, hash: briefingHash },  // Ship 3: A/B signal
    )

    // Write to replay buffer
    replayBuffer.write({
      agent: config.name,
      session_id: session.id,
      state_hash: transition.state_hash,
      state: transition.state,
      action_diff: transition.action_diff,
      action: transition.action,
      hypothesis,
      reward: result.delta,
      timestamp: new Date().toISOString(),
    })

    const emoji = result.kept ? chalk.green("✓") : chalk.red("✗")
    const deltaStr = result.delta > 0 ? `+${result.delta.toFixed(4)}` : result.delta.toFixed(4)
    console.log(`  ${emoji} Result: ${result.metricAfter.toFixed(4)} (${deltaStr}) ${result.kept ? "KEPT" : "REVERTED"}`)

    // Supervisor: detect patterns, inject hints for next round
    // Works for ALL agents — not just scope:"build"
    {
      try {
        const { checkRound, logLearning } = await import("../lib/build-supervisor.js")
        
        // Build round history from transitions
        let runningScore = session.baselineMetric
        const roundHistory = transitions.map((t, i) => {
          const scoreBefore = runningScore
          const delta = t.reward ?? 0
          const kept = delta > 0
          if (kept) runningScore += delta
          return {
            agent: config.name,
            round: i + 1,
            scoreBefore,
            scoreAfter: kept ? scoreBefore + delta : scoreBefore,
            delta,
            kept,
            filesCreated: [] as string[],  // TODO: parse from transition
            failedChecks: (() => {
                try {
                  const raw = (session as any).lastEvalOutput || ""
                  const lines = raw.trim().split("\n").filter((l: string) => l.startsWith("{"))
                  for (const line of lines) {
                    try {
                      const p = JSON.parse(line)
                      if (p.failed_checks?.length > 0) return p.failed_checks as string[]
                      if (p.checks?.length > 0) return (p.checks as any[]).filter((c: any) => !c.pass).map((c: any) => c.name as string)
                    } catch {}
                  }
                } catch {}
                return [] as string[]
              })(),
          }
        })
        
        const hint = checkRound(roundHistory)
        if (hint) {
          console.log(chalk.yellow(`  🔍 Supervisor: ${hint.slice(0, 120)}...`))
          // Inject into EXPERIMENTS.md for next round
          const { appendFileSync: appendFs } = await import("fs")
          const expPath = path.join(session.worktreePath, "EXPERIMENTS.md")
          appendFs(expPath, `\n\n## Supervisor Hint (after round ${round})\n${hint}\n`)
          
          // Log the learning (supervisor's teacup memory)
          logLearning(projectRoot, {
            ts: new Date().toISOString(),
            agent: config.name,
            pattern: hint.split(":")[0] || "unknown",
            resolution: "hint injected, awaiting next round",
            failedChecks: roundHistory[roundHistory.length - 1]?.failedChecks || [],
          })
        }
      } catch { /* supervisor not built yet — graceful degradation */ }
    }

    // Agent journal: one line per round to .tenet/build-journal.jsonl
    {
      try {
        const { appendFileSync } = await import("fs")
        const journalPath = path.join(projectRoot, ".tenet", "build-journal.jsonl")
        appendFileSync(journalPath, JSON.stringify({
          type: "build:round",
          agent: config.name,
          round,
          score: result.metricAfter,
          delta: result.delta,
          kept: result.kept,
          ts: new Date().toISOString(),
        }) + "\n")
      } catch { /* journal write failed — not critical */ }
    }

    runSpendUsd += result.costUsd ?? 0
    roundSummaries.push({ diff: result.diff, reward: result.delta, kept: result.kept })

    // Early termination at 1.0 — any agent that hits perfect score stops
    if (result.metricAfter >= 1.0) {
      console.log(chalk.green(`  ✅ Score hit 1.0 — stopping early`))
      break
    }

    // A loop that keeps re-proposing the same diff, or keeps nothing for
    // several rounds, is spending budget without moving. Neither is visible
    // to an exit code, so stop on it explicitly.
    const stall = detectStall(roundSummaries)
    if (stall.stalled) {
      console.log(chalk.yellow(`\n  ⚠ Stopping: ${stall.reason} (${stall.kind})`))
      break
    }
  }

  // Clean up presence
  try { fs.unlinkSync(presenceFile) } catch {}

  // End session
  const summary = await endSession(session, transitions)

  // Compute quality dimensions from session outcome for training tuple enrichment
  const _b = summary.baseline
  const _s = summary.finalMetric
  const _d = summary.totalDelta
  const _kept = summary.improvedRounds
  const _rounds = summary.rounds
  const dimCorrectness = _s.toFixed(3)
  const dimCoverage = Math.min(1, Math.max(0, _d / Math.max(0.001, 1 - _b))).toFixed(3)
  const dimArchitecture = _rounds > 0 ? (_kept / _rounds).toFixed(3) : "0.000"
  const dimValue = Math.min(1, Math.max(0, _d * 2)).toFixed(3)
  const qualityScore = ((parseFloat(dimCorrectness) + parseFloat(dimValue)) / 2).toFixed(3)

  // Post eval:scored to hub event bus — triggers auto-merge, flag-regression, training flows
  await postHubEvent(projectRoot, "eval:scored", {
    agent: agentName,
    metric: config.metric,
    baseline: _b.toFixed(4),
    composite: _s.toFixed(4),
    delta: _d.toFixed(4),
    improved: String(summary.improvedRounds > 0),
    rounds: _rounds,
    kept: _kept,
    branch: session.branch,
    pr_number: summary.prUrl ? summary.prUrl.split("/").pop() : "",
    score: _s.toFixed(4),
    quality_score: qualityScore,
    dim_correctness: dimCorrectness,
    dim_coverage: dimCoverage,
    dim_architecture: dimArchitecture,
    dim_value: dimValue,
  })

  console.log(chalk.bold(`\n  ── Session Complete ${"─".repeat(35)}\n`))
  console.log(chalk.gray(`  Rounds: ${summary.rounds}`))
  console.log(chalk.gray(`  Improved: ${summary.improvedRounds}`))
  console.log(chalk.gray(`  Total delta: ${summary.totalDelta > 0 ? "+" : ""}${summary.totalDelta.toFixed(4)}`))
  console.log(chalk.gray(`  Best delta: +${summary.bestDelta.toFixed(4)}`))

  if (summary.branchUrl) {
    console.log(chalk.green(`\n  Branch pushed for review: ${summary.branchUrl}`))
  }
  if (summary.prUrl) {
    console.log(chalk.green(`  PR: ${summary.prUrl}`))
  }

  // ── Backward arm: harvest skill learnings from this session ──────────
  // The build agent just ran using skills — extract what worked/didn't
  // and write learnings back to skill files for cross-GTM propagation.
  try {
    const { harvestLearnings, propagateToPortfolio } = await import("../lib/skill-learner.js")
    const skillsDir = path.join(projectRoot, ".claude", "skills")
    const piSkillsDir = path.join(projectRoot, "packages", "pi", "skills")

    // Harvest from the session journals + training buffer
    const skillNames = ["build-agent", "eval", "context", "spec"]
    let totalExtracted = 0
    let totalSaved = 0

    for (const skill of skillNames) {
      const result = harvestLearnings(projectRoot, skill)
      if (result.saved > 0) {
        totalExtracted += result.extracted
        totalSaved += result.saved
      }
    }

    if (totalSaved > 0) {
      console.log(chalk.gray(`  📚 Learnings: ${totalSaved} new from ${totalExtracted} extracted (backward arm)`))
    }
  } catch {
    // Skill learner not critical — never block session completion
  }

  console.log()

  // F-012: PolicyHeadInference lazily spawns `infer_server.py` as a child
  // process and never calls stopServer (it's defined but unused). Node's
  // event loop refuses to exit while a child process with open stdio pipes
  // is alive, so the parent hangs after Session Complete. The hung wrapper
  // then suppresses launchd's next StartCalendarInterval fire (caught by
  // doctor's Cron-log-activity check). Force-exit here is the standard CLI
  // pattern for "all work done, kill stragglers." The infer_server is a
  // descendant of this process so it dies with us.
  process.exit(0)
}

// ============================================================================
// Telemetry Agent V2 Commands
// ============================================================================

async function runTelemetryAgent(projectRoot: string): Promise<void> {
  const { TelemetryAgentV2 } = await import("../lib/telemetry-agent-v2.js")

  console.log(chalk.bold("\n  Telemetry Agent V2 - Platform Digest Analysis\n"))

  const agent = new TelemetryAgentV2({
    projectRoot,
    emitEvent: (type, data) => {
      console.log(chalk.gray(`  [EVENT] ${type}`))
    },
  })

  console.log(chalk.gray("  Fetching platform digest..."))

  const result = await agent.run()

  if (!result.digest24h) {
    console.log(chalk.yellow("\n  Could not fetch platform digest."))
    console.log(chalk.gray("  Check TENET_PLATFORM_URL and network connectivity.\n"))
    return
  }

  console.log(chalk.green(`\n  Digest fetched for ${result.digest24h.periodHours}h period\n`))

  // Show metrics
  if (result.metrics) {
    console.log(chalk.bold("  Current Metrics:"))
    console.log(chalk.gray(`    Command Success Rate:  ${(result.metrics.command_success_rate * 100).toFixed(1)}%`))
    console.log(chalk.gray(`    Command P90 Latency:   ${result.metrics.command_p90_latency_ms}ms`))
    console.log(chalk.gray(`    Session Crash Rate:    ${(result.metrics.session_crash_rate * 100).toFixed(2)}%`))
    console.log(chalk.gray(`    Hub Crash Rate:        ${(result.metrics.hub_crash_rate * 100).toFixed(2)}%`))
    console.log(chalk.gray(`    Flow Completion Rate:  ${(result.metrics.flow_completion_rate * 100).toFixed(1)}%`))
    console.log(chalk.gray(`    Cost Per Session:      $${result.metrics.cost_per_session_usd.toFixed(4)}`))
    console.log(chalk.gray(`    Active Installs:       ${result.metrics.active_installs}`))
    console.log(chalk.gray(`    Error Clusters:        ${result.metrics.error_cluster_count}`))
    console.log()
  }

  // Show alerts
  if (result.alerts.length > 0) {
    console.log(chalk.bold(chalk.red("  Alerts:")))
    for (const alert of result.alerts) {
      console.log(chalk.red(`    ⚠ ${alert.name}: ${alert.percentChange.toFixed(1)}% decline`))
      console.log(chalk.gray(`      ${alert.previous.toFixed(4)} → ${alert.current.toFixed(4)}`))
    }
    console.log()
  }

  // Show wins
  if (result.wins.length > 0) {
    console.log(chalk.bold(chalk.green("  Wins:")))
    for (const win of result.wins) {
      console.log(chalk.green(`    ✓ ${win.name}: ${win.percentChange.toFixed(1)}% improvement`))
      console.log(chalk.gray(`      ${win.previous.toFixed(4)} → ${win.current.toFixed(4)}`))
    }
    console.log()
  }

  // Show proposed agents
  if (result.proposedAgents.length > 0) {
    console.log(chalk.bold("  Proposed Agents:"))
    for (const agent of result.proposedAgents) {
      const priority = agent.priority === "high" ? chalk.red(agent.priority) :
                       agent.priority === "medium" ? chalk.yellow(agent.priority) :
                       chalk.gray(agent.priority)
      console.log(chalk.cyan(`    ${agent.name} [${priority}]`))
      console.log(chalk.gray(`      ${agent.reason}`))
    }
    console.log(chalk.gray(`\n  Agent configs written to .tenet/agents/proposed/\n`))
  }

  // Show status
  const status = agent.getStatus()
  console.log(chalk.gray(`  Run #${status.runCount}`))
  console.log(chalk.gray(`  Training tuples generated: ${status.totalTrainingTuples}`))
  console.log()
}

async function runSentinelReview(projectRoot: string): Promise<void> {
  const { SentinelRL } = await import("../lib/sentinel-rl.js")

  console.log(chalk.bold("\n  Sentinel - Nightly System Review\n"))

  const sentinel = new SentinelRL({
    projectRoot,
    emitEvent: (type, data) => {
      console.log(chalk.gray(`  [EVENT] ${type}`))
    },
  })

  console.log(chalk.gray("  Collecting inputs..."))

  const { scores, recommendations, inputs } = await sentinel.run()

  // Show scores
  console.log(chalk.bold("\n  System Scores:"))
  console.log(chalk.gray(`    Product Health:       ${(scores.productHealth * 100).toFixed(0)}% ${scoreEmoji(scores.productHealth)}`))
  console.log(chalk.gray(`    Development Velocity: ${(scores.developmentVelocity * 100).toFixed(0)}% ${scoreEmoji(scores.developmentVelocity)}`))
  console.log(chalk.gray(`    Agent Effectiveness:  ${(scores.agentEffectiveness * 100).toFixed(0)}% ${scoreEmoji(scores.agentEffectiveness)}`))
  console.log(chalk.gray(`    Data Quality:         ${(scores.dataQuality * 100).toFixed(0)}% ${scoreEmoji(scores.dataQuality)}`))
  console.log(chalk.bold(`    Composite:            ${(scores.composite * 100).toFixed(0)}% ${scoreEmoji(scores.composite)}`))
  console.log()

  // Show recommendations
  if (recommendations.length > 0) {
    console.log(chalk.bold("  Recommendations:"))
    for (const rec of recommendations) {
      const priority = rec.priority === "high" ? chalk.red(`[${rec.priority}]`) :
                       rec.priority === "medium" ? chalk.yellow(`[${rec.priority}]`) :
                       chalk.gray(`[${rec.priority}]`)
      console.log(`    ${priority} ${rec.description}`)
      console.log(chalk.gray(`      ${rec.reason}`))
    }
    console.log()
  } else {
    console.log(chalk.green("  No recommendations at this time.\n"))
  }

  // Show data summary
  console.log(chalk.gray(`  Journal entries analyzed: ${inputs.journalEntries.length}`))
  console.log(chalk.gray(`  Eval entries analyzed: ${inputs.evalHistory.length}`))
  console.log(chalk.gray(`  PR reviews analyzed: ${inputs.prReviews.length}`))
  console.log(chalk.gray(`  Training tuples: ${inputs.trainingStats.total}`))
  console.log(chalk.gray(`  Replay entries: ${inputs.replayStats.totalEntries}`))
  console.log(chalk.gray(`\n  Report written to .tenet/SENTINEL-REPORT.md\n`))
}

function scoreEmoji(score: number): string {
  if (score >= 0.8) return chalk.green("●")
  if (score >= 0.5) return chalk.yellow("●")
  return chalk.red("●")
}

async function showMetrics(projectRoot: string): Promise<void> {
  const { TelemetryAgentV2 } = await import("../lib/telemetry-agent-v2.js")

  console.log(chalk.bold("\n  Current Platform Metrics\n"))

  const agent = new TelemetryAgentV2({ projectRoot })
  const metrics = await agent.getMetrics()

  if (!metrics) {
    console.log(chalk.yellow("  Could not fetch metrics from platform."))
    console.log(chalk.gray("  Check TENET_PLATFORM_URL and network connectivity.\n"))
    return
  }

  const format = (value: number, isPercent: boolean = false) => {
    if (isPercent) return `${(value * 100).toFixed(1)}%`
    return value.toFixed(4)
  }

  console.log(chalk.cyan("  Health Metrics:"))
  console.log(chalk.gray(`    Command Success Rate:  ${format(metrics.command_success_rate, true)}`))
  console.log(chalk.gray(`    Session Crash Rate:    ${format(metrics.session_crash_rate, true)}`))
  console.log(chalk.gray(`    Hub Crash Rate:        ${format(metrics.hub_crash_rate, true)}`))
  console.log(chalk.gray(`    Flow Completion Rate:  ${format(metrics.flow_completion_rate, true)}`))
  console.log()

  console.log(chalk.cyan("  Performance Metrics:"))
  console.log(chalk.gray(`    Command P90 Latency:   ${metrics.command_p90_latency_ms}ms`))
  console.log(chalk.gray(`    MCP Avg Latency:       ${metrics.mcp_avg_latency_ms.toFixed(1)}ms`))
  console.log()

  console.log(chalk.cyan("  Usage Metrics:"))
  console.log(chalk.gray(`    Active Installs:       ${metrics.active_installs}`))
  console.log(chalk.gray(`    Error Clusters:        ${metrics.error_cluster_count}`))
  console.log(chalk.gray(`    Hook Hit Rate:         ${format(metrics.hook_hit_rate, true)}`))
  console.log()

  console.log(chalk.cyan("  Cost Metrics:"))
  console.log(chalk.gray(`    Cost Per Session:      $${metrics.cost_per_session_usd.toFixed(4)}`))
  console.log()
}



// ============================================================================
// Synthesis — distill journals + events into product context for agents
// ============================================================================

async function runSynthesis(projectRoot: string) {
  console.log(chalk.bold("\n  Peter Parker - Product Context Synthesis\n"))

  const { StratusClient } = await import("../lib/stratus-client.js")
  const stratus = process.env.STRATUS_API_KEY
    ? new StratusClient({ apiKey: process.env.STRATUS_API_KEY })
    : null

  if (!stratus) {
    console.log(chalk.red("  STRATUS_API_KEY required for synthesis"))
    return
  }

  // 1. Read recent journals (last 7 days)
  const journalDir = path.join(projectRoot, ".tenet", "journal")
  let journalEntries: string[] = []
  if (fs.existsSync(journalDir)) {
    const files = fs.readdirSync(journalDir).filter(f => f.endsWith(".jsonl"))
    for (const file of files.slice(-10)) { // Last 10 journal files
      const content = fs.readFileSync(path.join(journalDir, file), "utf-8").trim()
      if (content) journalEntries.push(...content.split("\n").slice(-20)) // Last 20 entries per file
    }
  }
  console.log(chalk.gray(`  Read ${journalEntries.length} journal entries`))

  // 2. Read recent events
  const eventsPath = path.join(projectRoot, ".tenet", "service-events.jsonl")
  let events: string[] = []
  if (fs.existsSync(eventsPath)) {
    events = fs.readFileSync(eventsPath, "utf-8").trim().split("\n").slice(-30) // Last 30 events
  }
  console.log(chalk.gray(`  Read ${events.length} events`))

  // 3. Read agent results from training buffer
  const bufferPath = path.join(projectRoot, ".tenet", "training-buffer.jsonl")
  let tuples: string[] = []
  if (fs.existsSync(bufferPath)) {
    tuples = fs.readFileSync(bufferPath, "utf-8").trim().split("\n").slice(-20)
  }
  console.log(chalk.gray(`  Read ${tuples.length} training tuples`))

  // 4. Read current agent configs
  const { listAgentConfigs, loadAgentConfig } = await import("../lib/agent-config.js")
  const agentNames = listAgentConfigs(projectRoot)
  const configs = agentNames.map(name => { try { return loadAgentConfig(projectRoot, name) } catch { return null } }).filter(Boolean)
  const agentSummary = configs.map((c: any) => `${c.name}: ${c.metric} (${c.direction}), target: ${c.target_repo || "self"}`).join("\n")

  // 5. Send to Stratus for synthesis
  console.log(chalk.gray("\n  Synthesizing with Stratus...\n"))

  const prompt = `You are Peter Parker, the orchestrator for a software product portfolio.

Your job: read the recent activity (journals, events, experiment results) and produce a PRODUCT CONTEXT document that tells scoped RL agents what the product is, what's been happening, and what to focus on.

## Current Agents
${agentSummary}

## Recent Journal Entries (last 7 days)
${journalEntries.slice(-15).map(e => e.slice(0, 200)).join("\n")}

## Recent Events
${events.slice(-15).join("\n")}

## Recent Experiment Results
${tuples.slice(-10).join("\n")}

---

Produce a concise product-context.md with these sections:
1. **Product State** — what is this product, what's working, what's broken
2. **Recent Activity** — what the team has been building/fixing (distilled from journals)
3. **Agent Guidance** — for each active agent, specific guidance based on recent context (e.g. "cli-speed: startup is already fast, focus on subcommand latency")
4. **Priority Shifts** — any metrics that should be deprioritized or new metrics to consider
5. **Open Questions** — things that need human input

Be concise. This document is consumed by agents, not humans. Skip fluff.`

  try {
    const response = await stratus.reason(prompt, { maxTokens: 1500, temperature: 0.3 })
    const synthesis = response.choices[0]?.message?.content || ""

    if (synthesis) {
      const outputPath = path.join(projectRoot, ".tenet", "product-context.md")
      fs.writeFileSync(outputPath, `# Product Context\n\n_Synthesized by Peter Parker at ${new Date().toISOString()}_\n\n${synthesis}\n`)
      console.log(chalk.green(`  ✓ Product context written to .tenet/product-context.md`))
      console.log(chalk.gray(`  (${synthesis.length} chars)\n`))
    }
  } catch (err: any) {
    console.log(chalk.red(`  Synthesis failed: ${err.message}`))
  }
}

// ============================================================================
// Review — check autoresearch branches, audit with Stratus, prepare PRs
// ============================================================================

async function runReview(projectRoot: string) {
  console.log(chalk.bold("\n  Peter Parker - Autoresearch Review\n"))

  const { spawnSync } = await import("child_process")

  // Find session branches on remote
  const result = spawnSync("git", ["branch", "-r", "--list", "origin/session/*"], { cwd: projectRoot, encoding: "utf-8" })
  const branches = (result.stdout || "").trim().split("\n").map(b => b.trim()).filter(Boolean)

  if (branches.length === 0) {
    console.log(chalk.yellow("  No autoresearch branches found.\n"))
    return
  }

  console.log(chalk.gray(`  Found ${branches.length} session branch(es):\n`))

  for (const branch of branches) {
    const shortBranch = branch.replace("origin/", "")

    // Get diff stats
    const diffStat = spawnSync("git", ["diff", "--stat", `origin/main...${branch}`], { cwd: projectRoot, encoding: "utf-8" })
    const logResult = spawnSync("git", ["log", "--oneline", `origin/main..${branch}`], { cwd: projectRoot, encoding: "utf-8" })
    const commits = (logResult.stdout || "").trim().split("\n").filter(Boolean)

    console.log(chalk.cyan(`  ${shortBranch}`))
    console.log(chalk.gray(`    ${commits.length} commits`))
    if (diffStat.stdout) {
      const lastLine = diffStat.stdout.trim().split("\n").pop() || ""
      console.log(chalk.gray(`    ${lastLine.trim()}`))
    }
    console.log()
  }

  console.log(chalk.gray("  To create PRs from these branches:"))
  console.log(chalk.gray("    gh pr create --base main --head <branch> --title '...'\n"))
}

export async function peterCommand(
  action?: string,
  options: { cost?: boolean; quality?: boolean; balanced?: boolean; task?: string; rounds?: string; mode?: string; name?: string; budget?: string; pi?: boolean; scope?: string; output?: string; fast?: boolean; fromIssue?: number } = {}
) {
  const projectRoot = process.cwd()

  if (options.scope === "qa") {
    const { runQAChecks } = await import("../lib/qa-runner.js")
    const { postQAComment } = await import("../lib/qa-reporter.js")
    const results = await runQAChecks()
    postQAComment(results)
    return
  }

  // Handle "agent" subcommand
  if (action === "agent") {
    const subAction = options.name || options.task  // name is the subcommand, task might be agent name
    if (subAction === "create") {
      await agentCreate(projectRoot)
      return
    } else if (subAction === "list") {
      await agentList(projectRoot)
      return
    } else if (subAction === "run") {
      // tenet peter agent run <name> --rounds N
      // The agent name would be in a different position
      console.log(chalk.yellow("\n  Usage: tenet peter agent run <name> --rounds N\n"))
      return
    } else if (subAction === "swarm") {
      console.log(chalk.yellow("\n  swarm subcommand removed — meta-orchestrator deprecated."))
      console.log(chalk.gray("  Run agents sequentially: for a in ...; do tenet peter agent $a; done\n"))
      return
    } else if (subAction) {
      // Assume it's an agent name for "run"
      // Use CLI override if provided, otherwise use config.rounds (default 50)
      const roundsOverride = options.rounds ? parseInt(options.rounds, 10) : undefined
      // #2735 — propagate --fast subsample mode through to agentRun
      // #3084 — propagate --from-issue so the converged PR closes the issue
      await agentRun(projectRoot, subAction, roundsOverride, {
        fast: options.fast === true,
        fromIssue: options.fromIssue,
      })
      return
    }

    // Show agent help
    console.log(chalk.bold("\n  Peter Parker - Scoped Agent Commands\n"))
    console.log(chalk.gray("  Commands:"))
    console.log("    tenet peter agent create                    Interactive agent creation")
    console.log("    tenet peter agent list                      List configured agents")
    console.log("    tenet peter agent run <name> [--rounds N]   Run a specific agent")
    console.log("    tenet peter agent <name> [--rounds N]       Run single agent")
    console.log()
    return
  }

  switch (action) {
    case "setup": {
      let profile: CostProfile = "balanced"
      if (options.cost) profile = "cost-optimized"
      if (options.quality) profile = "quality-first"
      if (options.balanced) profile = "balanced"
      await setup(projectRoot, profile)
      break
    }

    case "run": {
      await run(projectRoot, options.task)
      break
    }

    case "status": {
      await status(projectRoot)
      break
    }

    case "pr": {
      await runWithPR(projectRoot, options.task)
      break
    }

    case "dashboard": {
      const { startEventDashboard } = await import("../ui/event-dashboard.js")
      await startEventDashboard()
      break
    }

    case "experiment": {
      if (options.mode === "autoresearch") {
        const rounds = parseInt(options.rounds || "5", 10)
        const budget = options.budget ? parseFloat(options.budget) : undefined
        await runAutoresearch(projectRoot, { rounds, budget, usePi: options.pi })
      } else {
        await runExperiment(projectRoot)
      }
      break
    }

    case "autoresearch": {
      const rounds = parseInt(options.rounds || "5", 10)
      const budget = options.budget ? parseFloat(options.budget) : undefined
      await runAutoresearch(projectRoot, { rounds, budget, usePi: options.pi })
      break
    }

    case "telemetry": {
      await runTelemetryAgent(projectRoot)
      break
    }

    case "sentinel": {
      await runSentinelReview(projectRoot)
      break
    }

    case "metrics": {
      await showMetrics(projectRoot)
      break
    }

    case "daily":
    case "nightly": {
      console.log(chalk.yellow("\n  daily/nightly subcommand removed — meta-orchestrator deprecated."))
      console.log(chalk.gray("  Use scripts/overnight-build.sh (sequential loop) or cron your own script.\n"))
      break
    }

    case "synthesize": {
      await runSynthesis(projectRoot)
      break
    }

    case "review": {
      await runReview(projectRoot)
      break
    }

    case "pickup": {
      await runPickup(projectRoot)
      break
    }

    case "qa": {
      // QA scope — read-only checks against the codebase
      const { runQAChecks } = await import("../lib/qa-runner.js")
      const { postQAComment } = await import("../lib/qa-reporter.js")
      const results = await runQAChecks()
      postQAComment(results, options.name)
      break
    }

    default: {
      console.log(chalk.bold("\n  Peter Parker - Model-Routed Agent Orchestrator\n"))
      console.log(chalk.gray("  Commands:"))
      console.log("    tenet peter setup [--cost|--balanced|--quality]  Generate agent config")
      console.log("    tenet peter run [--task <task>]                  Run orchestrator")
      console.log("    tenet peter pr --task <task>                     Run + branch + PR")
      console.log("    tenet peter pickup                               Poll backlog, pick source:linear issue, execute, PR")
      console.log("    tenet peter experiment                           Proactive: pick + execute next experiment")
      console.log("    tenet peter autoresearch [--rounds N] [--budget $] [--pi]")
      console.log("                                                   Autoresearch mode with Pi runtime")
      console.log("    tenet peter status                               Show status + recent events")
      console.log("    tenet peter dashboard                            Live event stream dashboard")
      console.log()
      console.log(chalk.bold("  Pi-sky Runtime Options:\n"))
      console.log("    --budget <amount>    Cost budget in USD (auto-downgrades model when exceeded)")
      console.log("    --pi                 Force Pi runtime (default: auto-detect)")
      console.log()
      console.log(chalk.bold("  Telemetry & RL:\n"))
      console.log("    tenet peter telemetry                       Run telemetry agent (platform digest)")
      console.log("    tenet peter sentinel                        Run Sentinel nightly review")
      console.log("    tenet peter metrics                         Show current platform metrics")
      console.log("    tenet peter daily                           Daily RL loop (check stale agents, schedule next)")
      console.log()
      console.log(chalk.bold("  Scoped Agents:\n"))
      console.log("    tenet peter agent create                    Interactive agent creation")
      console.log("    tenet peter agent list                      List configured agents")
      console.log("    tenet peter agent run <name> [--rounds N]   Run a specific scoped agent")
      console.log("    tenet peter agent swarm [--rounds N]        Run all agents with orchestrator")
      console.log()
    }
  }
}
