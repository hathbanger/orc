/**
 * Wave planner — turn a set of issues into the firing groups that actually
 * worked, deterministically.
 *
 * Reconstructed from the artifacts that produced 5+ waves and 50+ agents:
 * `.tenet/recipes/build-cycle.yaml` and `specs/dependency-graph-v2.md`. Two
 * things in those are easy to miss and both matter:
 *
 *  1. PARALLELISM IS CONSTRAINED BY FILES, NOT ONLY BY DECLARED DEPENDENCIES.
 *     The real artifact labels its batches "PARALLEL GROUP 1 (disjoint
 *     files)", and build-cycle's scan-and-split step spells out the rule:
 *     "Same-file agents run SERIAL (queued in same bucket). Different-file
 *     agents run PARALLEL." Two issues with no dependency between them still
 *     cannot run together if they edit the same file — they would collide in
 *     git. A planner that only reads `depends on #N` will happily schedule
 *     exactly that collision.
 *
 *  2. PRIORITY IS V × U / C, AND U IS NOT AN INPUT.
 *     V is value, C is cost, and U is "how many other issues become possible
 *     after this one" — which is the transitive dependent count, a property
 *     of the graph itself. `rl-surfaces/wave-optimizer.ts` ranks by
 *     `valueScore / cost` and drops U entirely, so a low-value issue that
 *     unblocks nine others ranks below a high-value leaf. Here U is computed.
 *
 * Also from build-cycle, enforced here: "FIRE 1 proved 6-issue agents stall.
 * 1-2 issue agents converge" — hence a cap on how much work lands in a bucket.
 *
 * @purpose Deterministic wave planning: file-disjoint parallel groups ranked by V×U/C
 */

import { topoOrder } from "./topo.js"

export interface WaveIssue {
  number: number
  title?: string
  /** Files this issue will touch. Two issues sharing one cannot run together. */
  files?: string[]
  /** Structural dependencies — these MUST land first. */
  deps?: number[]
  /** Value 1-5. Defaults to 3 so an unscored issue is neither starved nor favoured. */
  value?: number
  /** Cost 1-5 (rounds estimate). Defaults to 3. */
  cost?: number
}

export interface ScoredIssue extends WaveIssue {
  /** Transitive dependents — how many issues this one unblocks. */
  unlocks: number
  /** V × (U + 1) / C. U+1 so a leaf scores its own value rather than zero. */
  score: number
}

export interface Wave {
  index: number
  issues: ScoredIssue[]
  /** Why this wave ended where it did. */
  reason: string
}

export interface WavePlan {
  waves: Wave[]
  scored: ScoredIssue[]
  cycles: number[][]
  /** Pairs forced apart by a shared file, as `#a|#b|path`. */
  fileConflicts: string[]
  maxParallel: number
}

const DEFAULT_VALUE = 3
const DEFAULT_COST = 3

function norm(issue: WaveIssue): Required<Pick<WaveIssue, "files" | "deps" | "value" | "cost">> {
  const value = Number.isFinite(issue.value) ? Math.min(5, Math.max(1, issue.value as number)) : DEFAULT_VALUE
  const cost = Number.isFinite(issue.cost) ? Math.min(5, Math.max(1, issue.cost as number)) : DEFAULT_COST
  return {
    files: [...new Set((issue.files ?? []).filter(f => typeof f === "string" && f.trim() !== ""))],
    deps: [...new Set(issue.deps ?? [])],
    value,
    cost,
  }
}

/**
 * How many issues transitively depend on `target` — the U in V×U/C.
 * Computed from the graph rather than taken as input, because "unlocks" is
 * not something an author can reliably self-report.
 */
export function unlocksCount(issues: WaveIssue[], target: number): number {
  const dependents = new Map<number, number[]>()
  for (const i of issues) {
    for (const d of norm(i).deps) {
      if (!dependents.has(d)) dependents.set(d, [])
      dependents.get(d)!.push(i.number)
    }
  }
  const seen = new Set<number>()
  const stack = [...(dependents.get(target) ?? [])]
  while (stack.length > 0) {
    const n = stack.pop()!
    if (seen.has(n) || n === target) continue
    seen.add(n)
    for (const next of dependents.get(n) ?? []) stack.push(next)
  }
  return seen.size
}

export function scoreIssues(issues: WaveIssue[]): ScoredIssue[] {
  return issues.map(issue => {
    const n = norm(issue)
    const unlocks = unlocksCount(issues, issue.number)
    return {
      ...issue,
      ...n,
      unlocks,
      // U+1: a leaf that unblocks nothing should still rank by its own value,
      // not collapse to zero and sort below everything.
      score: (n.value * (unlocks + 1)) / n.cost,
    }
  })
}

function shareAFile(a: ScoredIssue, b: ScoredIssue): string | null {
  const bFiles = new Set(b.files ?? [])
  for (const f of a.files ?? []) if (bFiles.has(f)) return f
  return null
}

/**
 * Build the firing plan.
 *
 * An issue becomes eligible once every dependency has landed in an earlier
 * wave. Among the eligible, highest V×U/C goes first; an issue is added to the
 * current wave only if it shares no file with anything already in it and the
 * wave is under `maxParallel`. Anything displaced falls to the next wave.
 */
export function planWaves(
  issues: WaveIssue[],
  options: { maxParallel?: number } = {},
): WavePlan {
  const maxParallel = Math.max(1, options.maxParallel ?? 4)
  const scored = scoreIssues(issues)
  const byNumber = new Map(scored.map(i => [i.number, i]))

  // Cycle check first — never emit a partial order for a cyclic graph.
  const topo = topoOrder({
    nodes: scored,
    idOf: i => String(i.number),
    depsOf: i => (i.deps ?? []).filter(d => byNumber.has(d)).map(String),
  })
  if (topo.cycles.length > 0) {
    return {
      waves: [],
      scored,
      cycles: topo.cycles.map(c => c.map(Number)),
      fileConflicts: [],
      maxParallel,
    }
  }

  const landed = new Set<number>()
  const remaining = [...scored]
  const waves: Wave[] = []
  const fileConflicts: string[] = []

  while (remaining.length > 0) {
    const eligible = remaining
      .filter(i => (i.deps ?? []).every(d => !byNumber.has(d) || landed.has(d)))
      .sort((a, b) => b.score - a.score || a.number - b.number)

    if (eligible.length === 0) {
      // Unreachable given the cycle check above, but a planner that silently
      // drops issues is worse than one that says it is stuck.
      waves.push({
        index: waves.length + 1,
        issues: [],
        reason: `stuck: ${remaining.length} issue(s) have unmet dependencies outside the set`,
      })
      break
    }

    const wave: ScoredIssue[] = []
    let blockedByFile = 0
    for (const candidate of eligible) {
      if (wave.length >= maxParallel) break
      let conflict: string | null = null
      for (const placed of wave) {
        const f = shareAFile(candidate, placed)
        if (f) {
          conflict = f
          fileConflicts.push(`#${Math.min(candidate.number, placed.number)}|#${Math.max(candidate.number, placed.number)}|${f}`)
          break
        }
      }
      if (conflict) { blockedByFile++; continue }
      wave.push(candidate)
    }

    const reasonBits: string[] = []
    if (wave.length >= maxParallel && eligible.length > wave.length) reasonBits.push(`hit maxParallel ${maxParallel}`)
    if (blockedByFile > 0) reasonBits.push(`${blockedByFile} held back by file overlap`)
    waves.push({
      index: waves.length + 1,
      issues: wave,
      reason: reasonBits.length > 0 ? reasonBits.join("; ") : "all eligible issues fit",
    })

    for (const i of wave) {
      landed.add(i.number)
      remaining.splice(remaining.findIndex(r => r.number === i.number), 1)
    }
  }

  return { waves, scored, cycles: [], fileConflicts: [...new Set(fileConflicts)], maxParallel }
}

/** Machine-readable graph — the `.tenet/dependency-graph.json` that build-dependency-graph.yaml promises and never wrote. */
export function toGraphJson(plan: WavePlan): string {
  return JSON.stringify(
    {
      generated: new Date().toISOString(),
      maxParallel: plan.maxParallel,
      issues: plan.scored.map(i => ({
        number: i.number,
        title: i.title,
        value: i.value,
        cost: i.cost,
        unlocks: i.unlocks,
        score: Number(i.score.toFixed(3)),
        deps: i.deps ?? [],
        files: i.files ?? [],
      })),
      waves: plan.waves.map(w => ({ index: w.index, issues: w.issues.map(i => i.number), reason: w.reason })),
      fileConflicts: plan.fileConflicts,
      cycles: plan.cycles,
    },
    null,
    2,
  )
}

export function formatWavePlan(plan: WavePlan): string {
  if (plan.cycles.length > 0) {
    return [
      "Cannot plan: the dependency graph has a cycle.",
      ...plan.cycles.map(c => `  ✗ ${c.map(n => `#${n}`).join(" -> ")}`),
    ].join("\n")
  }

  const lines: string[] = []
  const total = plan.scored.length
  lines.push(`${total} issue(s) → ${plan.waves.length} wave(s), max ${plan.maxParallel} concurrent.`)
  lines.push("")
  for (const wave of plan.waves) {
    lines.push(`PARALLEL GROUP ${wave.index} (${wave.issues.length} issue${wave.issues.length === 1 ? "" : "s"}, disjoint files) — ${wave.reason}`)
    for (const i of wave.issues) {
      const deps = (i.deps ?? []).length > 0 ? ` after ${(i.deps ?? []).map(d => `#${d}`).join(",")}` : ""
      lines.push(
        `  #${i.number} ${i.title ?? ""}  V${i.value}×U${i.unlocks}/C${i.cost} = ${i.score.toFixed(1)}${deps}`,
      )
    }
    lines.push("")
  }

  if (plan.fileConflicts.length > 0) {
    lines.push("Serialized by shared files (would have collided in git):")
    for (const c of plan.fileConflicts.slice(0, 10)) {
      const [a, b, file] = c.split("|")
      lines.push(`  ${a} ↔ ${b} both touch ${file}`)
    }
    if (plan.fileConflicts.length > 10) lines.push(`  …and ${plan.fileConflicts.length - 10} more`)
    lines.push("")
  }

  lines.push("Highest value first (V × U / C):")
  for (const i of [...plan.scored].sort((a, b) => b.score - a.score).slice(0, 8)) {
    lines.push(`  ${i.score.toFixed(1).padStart(5)}  #${i.number} ${i.title ?? ""}`)
  }
  return lines.join("\n")
}
