/**
 * Shadow a generated eval against a hand-written reference.
 *
 * The generator cannot write behaviour checks — `eval-coverage.ts:23-26`
 * refuses that deliberately, because "any regex claiming to verify 'retries
 * with backoff' is measuring wording". So it emits structural checks, and
 * measured on EPIC 5 that produced 19 checks scoring 0.9474 against untouched
 * code while a hand-written reference for the same spec scored 0.1538.
 *
 * Rather than trust or discard the generator, run both and record the gap.
 * Same move as the state layer's shadow-dual and ORC's Laya: the generated
 * eval is the candidate, the hand-written one is ground truth, and nothing
 * flips until the divergence is small on real work.
 *
 * THE METRIC IS BASELINE, NOT CHECK COUNT. Counting checks is Goodhart bait —
 * a generator can emit thirty hygiene checks and look thorough. What
 * distinguishes a decomposed eval is that it FAILS on current code, so the
 * baseline score is the discriminator and the headroom gap is the finding.
 *
 * @purpose Compare a generated eval against its hand-written reference
 */

export interface EvalRun {
  /** Path of the eval that produced this. */
  path: string
  /** Score against unmodified code. */
  baseline: number
  /** Total checks, when the eval reported them. */
  totalChecks?: number
  /** Names of the checks that failed. */
  failed: string[]
}

export type ParityVerdict =
  /** The generated eval measures comparable work. */
  | "parity"
  /** Generated has materially less headroom — it is grading the past. */
  | "generated-vacuous"
  /** Generated has materially more headroom — it may be asserting the impossible. */
  | "generated-overreaching"
  /** Not enough information to judge. */
  | "unmeasured"

export interface ParityResult {
  generated: EvalRun
  reference: EvalRun
  /** generated.baseline − reference.baseline. Positive means less to earn. */
  baselineGap: number
  /** Checks left to earn on each side, when totals are known. */
  headroomChecks: { generated?: number; reference?: number }
  verdict: ParityVerdict
  reason: string
}

/**
 * How far the baselines may drift before the generated eval is judged to be
 * measuring something else. 0.25 is deliberately loose: the two evals are
 * different check sets, so exact agreement is not the goal and demanding it
 * would push toward generating a copy of the reference rather than an
 * independent grader.
 */
export const PARITY_TOLERANCE = 0.25

/** Parse one eval's stdout/stderr into a run record. */
export function parseEvalRun(path: string, output: string): EvalRun {
  let baseline = Number.NaN
  let failed: string[] = []
  let totalChecks: number | undefined

  for (const line of output.split("\n")) {
    const t = line.trim()
    if (t.startsWith("{")) {
      try {
        const j = JSON.parse(t)
        if (Array.isArray(j.failed_checks)) failed = j.failed_checks
        if (typeof j.score === "number") baseline = j.score
        if (typeof j.metric === "number" && !Number.isFinite(baseline)) baseline = j.metric
      } catch {
        // Not a JSON line — evals also print prose.
      }
      continue
    }
    // `[eval] 18/19: …` is the canonical stderr form and carries the total
    // directly, which is more reliable than deriving it from the ratio.
    const m = t.match(/^\[eval\]\s+(\d+)\/(\d+):/)
    if (m) {
      totalChecks = Number(m[2])
      if (!Number.isFinite(baseline) && totalChecks > 0) baseline = Number(m[1]) / totalChecks
    }
  }

  return { path, baseline, totalChecks, failed }
}

export function compareEvals(generated: EvalRun, reference: EvalRun): ParityResult {
  const usable = Number.isFinite(generated.baseline) && Number.isFinite(reference.baseline)
  const baselineGap = usable ? generated.baseline - reference.baseline : Number.NaN

  const headroomChecks = {
    generated: generated.totalChecks
      ? Math.round((1 - generated.baseline) * generated.totalChecks)
      : undefined,
    reference: reference.totalChecks
      ? Math.round((1 - reference.baseline) * reference.totalChecks)
      : undefined,
  }

  let verdict: ParityVerdict
  let reason: string

  if (!usable) {
    verdict = "unmeasured"
    reason = "one side produced no readable score — not judging"
  } else if (baselineGap > PARITY_TOLERANCE) {
    verdict = "generated-vacuous"
    reason =
      `generated baseline ${generated.baseline.toFixed(4)} vs reference ` +
      `${reference.baseline.toFixed(4)} (+${baselineGap.toFixed(4)}). The generated eval is ` +
      `already satisfied by code the reference says has not been written; it is grading ` +
      `structure, not the work.`
  } else if (baselineGap < -PARITY_TOLERANCE) {
    verdict = "generated-overreaching"
    reason =
      `generated baseline ${generated.baseline.toFixed(4)} vs reference ` +
      `${reference.baseline.toFixed(4)} (${baselineGap.toFixed(4)}). The generated eval fails ` +
      `far more than the reference — check it is not asserting things the spec never asked for.`
  } else {
    verdict = "parity"
    reason =
      `baselines agree within ${PARITY_TOLERANCE} ` +
      `(generated ${generated.baseline.toFixed(4)}, reference ${reference.baseline.toFixed(4)})`
  }

  return { generated, reference, baselineGap, headroomChecks, verdict, reason }
}

export function formatParity(r: ParityResult): string {
  const mark = r.verdict === "parity" ? "✓" : r.verdict === "unmeasured" ? "·" : "✗"
  const lines = [
    `  ${mark} eval parity: ${r.verdict}`,
    `      generated  ${fmt(r.generated)}`,
    `      reference  ${fmt(r.reference)}`,
    `      ${r.reason}`,
  ]
  // The checks only the reference catches are the actionable part: they name
  // exactly what the generator did not think to grade.
  const onlyReference = r.reference.failed.filter(c => !r.generated.failed.includes(c))
  if (r.verdict === "generated-vacuous" && onlyReference.length > 0) {
    lines.push(`      reference catches ${onlyReference.length} the generator missed:`)
    for (const c of onlyReference.slice(0, 6)) lines.push(`        · ${c}`)
    if (onlyReference.length > 6) lines.push(`        … and ${onlyReference.length - 6} more`)
  }
  return lines.join("\n")
}

function fmt(run: EvalRun): string {
  const total = run.totalChecks ? `/${run.totalChecks}` : ""
  const passed = run.totalChecks ? Math.round(run.baseline * run.totalChecks) : "?"
  return `${run.baseline.toFixed(4)}  (${passed}${total} passing, ${run.failed.length} failing)`
}
