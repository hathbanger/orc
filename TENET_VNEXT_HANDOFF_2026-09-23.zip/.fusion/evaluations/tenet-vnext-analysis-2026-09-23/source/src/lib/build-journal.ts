/**
 * Build Journal
 * 
 * Event logger for build activities. Tracks rounds, agents, sessions.
 * Emits to MAP event bus and writes JSONL entries.
 * 
 * @purpose Build activity journaling with MAP integration
 */

import * as fs from "fs"
import * as path from "path"
import { MAPEventBus } from "./map-event-bus.js"

export interface JournalEntry {
  type: "round-complete" | "agent-complete" | "session-start"
  timestamp: string
  data: any
}

export class BuildJournal {
  private mapEventBus: MAPEventBus
  private journalPath: string
  
  constructor(mapEventBus: MAPEventBus, journalPath: string = ".tenet/build-journal.jsonl") {
    this.mapEventBus = mapEventBus
    this.journalPath = journalPath
    
    // Ensure directory exists
    const dir = path.dirname(this.journalPath)
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true })
    }
  }
  
  emit(entry: JournalEntry): void {
    // Write to JSONL file
    const jsonEntry = JSON.stringify(entry) + "\n"
    fs.appendFileSync(this.journalPath, jsonEntry)
    
    // Emit to MAP event bus
    this.mapEventBus.emit({
      type: "build-journal-entry" as any,
      source: "build-journal",
      data: entry as unknown as Record<string, unknown>
    })
  }
  
  recent(count: number = 10): JournalEntry[] {
    if (!fs.existsSync(this.journalPath)) {
      return []
    }
    
    const content = fs.readFileSync(this.journalPath, "utf-8")
    const lines = content.trim().split("\n").filter(line => line.length > 0)
    
    return lines
      .slice(-count)
      .map(line => JSON.parse(line))
  }
  
  status(): { entryCount: number; lastEntry?: JournalEntry; subwayAware: boolean } {
    const entries = this.recent(1)
    return {
      entryCount: this.recent(1000).length,
      lastEntry: entries[0],
      subwayAware: true // Indicates subway pattern awareness
    }
  }
}