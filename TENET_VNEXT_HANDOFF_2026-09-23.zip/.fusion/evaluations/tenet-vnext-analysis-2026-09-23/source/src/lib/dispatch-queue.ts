/**
 * Dispatch queue — pick what to fire next, given what is already running.
 *
 * This is the model that actually shipped. `wave-planner.ts` computes batches,
 * which is the right shape for *planning* a roadmap, but the fleet that merged
 * 152 agent PRs across 27 waves did not run batches: it ran a SLOT POOL. As a
 * slot frees, it picks the best eligible issue and fires it. Batching is
 * strictly worse here for two reasons the operators wrote down:
 *
 *   - A batch runs at the speed of its slowest member; a pool never idles.
 *   - "3 waves max per cycle. More than 3 waves and the later waves are based
 *     on stale assumptions." (dep-graph SKILL.md) — so long batch plans decay.
 *
 * The routing tiers here are lifted from `scripts/fleet/build-fleet-daemon.sh`:
 *
 *     0 = leaf (zero open deps) — preferred
 *     5 = unknown (graph missing this node) — neutral
 *     9 = conflict (files_in_scope overlaps an IN-FLIGHT branch's scope)
 *     blocked nodes are skipped entirely — never dispatched
 *
 * The part worth not losing: conflict is measured against work that is
 * RUNNING RIGHT NOW, not against the rest of the batch. Two issues editing one
 * file collide whether or not they were planned together, and the fleet learned
 * this expensively — a shared worktree let concurrent dispatches `git reset
 * --hard` over each other and "10/34 overnight branches had 0 commits ahead of
 * origin/main despite agents actually producing code."
 *
 * @purpose Slot-pool dispatch selection with in-flight conflict avoidance
 */

export type NodeState = "leaf" | "blocked" | "in-flight" | "shipped"

export interface QueueIssue {
  number: number
  title?: string
  /** Dependencies still open. Empty means dispatchable now. */
  openDeps?: number[]
  /** Files this issue will touch. */
  files?: string[]
  /** Max chain depth; 0 is a leaf. Shallower is a quicker win. */
  depth?: number
  /** Priority tier: lower fires first. Derive from labels. */
  priority?: number
  /** ISO timestamp, oldest-first stable tiebreak. */
  created?: string
  state?: NodeState
}

export interface InFlight {
  number: number
  files?: string[]
}

export const TIER_LEAF = 0
export const TIER_UNKNOWN = 5
export const TIER_CONFLICT = 9

export interface Candidate {
  issue: QueueIssue
  tier: number
  /** Files that collide with in-flight work, when tier is TIER_CONFLICT. */
  conflictsWith: Array<{ issue: number; file: string }>
  reason: string
}

export interface SelectionResult {
  /** Fire these now, in order. Never longer than the free slot count. */
  dispatch: Candidate[]
  /** Everything considered and not chosen, with the reason. */
  held: Candidate[]
  freeSlots: number
}

function filesOf(x: { files?: string[] }): string[] {
  return (x.files ?? []).filter(f => typeof f === "string" && f.trim() !== "")
}

/**
 * Score one issue against the current in-flight set.
 *
 * An issue with no declared files gets TIER_UNKNOWN rather than TIER_LEAF even
 * when it has no dependencies: we cannot prove it is collision-free, and the
 * daemon treats unknown as neutral rather than preferred for exactly that
 * reason. Claiming leaf status for an unknown scope is how two agents end up
 * in the same file.
 */
export function classify(issue: QueueIssue, inFlight: InFlight[]): Candidate {
  const openDeps = issue.openDeps ?? []
  if (openDeps.length > 0) {
    return {
      issue,
      tier: TIER_CONFLICT,
      conflictsWith: [],
      reason: `blocked by ${openDeps.map(d => `#${d}`).join(", ")}`,
    }
  }

  const mine = filesOf(issue)
  const conflictsWith: Array<{ issue: number; file: string }> = []
  for (const running of inFlight) {
    if (running.number === issue.number) continue
    const theirs = new Set(filesOf(running))
    for (const f of mine) if (theirs.has(f)) conflictsWith.push({ issue: running.number, file: f })
  }

  if (conflictsWith.length > 0) {
    return {
      issue,
      tier: TIER_CONFLICT,
      conflictsWith,
      reason: `files overlap in-flight ${conflictsWith.map(c => `#${c.issue} (${c.file})`).join(", ")}`,
    }
  }
  if (mine.length === 0) {
    return { issue, tier: TIER_UNKNOWN, conflictsWith: [], reason: "no declared file scope — cannot prove collision-free" }
  }
  return { issue, tier: TIER_LEAF, conflictsWith: [], reason: "leaf: no open deps, no in-flight file overlap" }
}

/**
 * Choose what to fire. Sort key mirrors the daemon:
 * priority, then routing tier, then depth, then created (oldest first).
 *
 * Selection is sequential rather than a simple filter: each pick is added to
 * the in-flight set before the next is classified, so two candidates sharing a
 * file cannot both be chosen in one call.
 */
export function selectDispatchable(
  issues: QueueIssue[],
  options: { inFlight?: InFlight[]; parallel?: number } = {},
): SelectionResult {
  const parallel = Math.max(0, options.parallel ?? 4)
  const inFlight = [...(options.inFlight ?? [])]
  const running = new Set(inFlight.map(i => i.number))
  const freeSlots = Math.max(0, parallel - inFlight.length)

  const eligible = issues.filter(i => {
    if (running.has(i.number)) return false
    if (i.state === "shipped" || i.state === "in-flight") return false
    return true
  })

  const rank = (c: Candidate) => [
    c.issue.priority ?? 50,
    c.tier,
    c.issue.depth ?? 0,
    c.issue.created ?? "",
    c.issue.number,
  ]

  const dispatch: Candidate[] = []
  const held: Candidate[] = []
  const remaining = [...eligible]

  while (dispatch.length < freeSlots && remaining.length > 0) {
    const scored = remaining
      .map(i => classify(i, inFlight))
      .sort((a, b) => {
        const ra = rank(a)
        const rb = rank(b)
        for (let i = 0; i < ra.length; i++) {
          if (ra[i] < rb[i]) return -1
          if (ra[i] > rb[i]) return 1
        }
        return 0
      })

    const next = scored[0]
    // Never dispatch a conflicted or blocked node — the daemon skips these
    // entirely rather than firing them and hoping.
    if (!next || next.tier >= TIER_CONFLICT) break

    dispatch.push(next)
    inFlight.push({ number: next.issue.number, files: filesOf(next.issue) })
    remaining.splice(remaining.findIndex(r => r.number === next.issue.number), 1)
  }

  for (const i of remaining) held.push(classify(i, inFlight))
  held.sort((a, b) => a.tier - b.tier || a.issue.number - b.issue.number)

  return { dispatch, held, freeSlots }
}

export function formatSelection(result: SelectionResult): string {
  const lines: string[] = []
  lines.push(`${result.freeSlots} free slot(s) → dispatching ${result.dispatch.length}`)
  lines.push("")
  if (result.dispatch.length === 0) {
    lines.push("Nothing dispatchable right now.")
  } else {
    for (const c of result.dispatch) {
      lines.push(`  FIRE #${c.issue.number} ${c.issue.title ?? ""}`)
      lines.push(`       tier ${c.tier} · depth ${c.issue.depth ?? 0} · ${c.reason}`)
    }
  }

  const blocked = result.held.filter(c => c.reason.startsWith("blocked by"))
  const conflicted = result.held.filter(c => c.conflictsWith.length > 0)
  if (conflicted.length > 0) {
    lines.push("")
    lines.push(`Held — would collide with running work (${conflicted.length}):`)
    for (const c of conflicted.slice(0, 8)) lines.push(`  #${c.issue.number} ${c.reason}`)
  }
  if (blocked.length > 0) {
    lines.push("")
    lines.push(`Held — dependencies still open (${blocked.length}):`)
    for (const c of blocked.slice(0, 8)) lines.push(`  #${c.issue.number} ${c.reason}`)
  }
  return lines.join("\n")
}

/**
 * Parse the `## Files in scope` section the fleet's issue template uses, which
 * is what `dep-graph-rebuilder.sh` reads. Falls back to nothing rather than
 * guessing: a wrong file list produces a wrong collision verdict, and an empty
 * one at least routes the issue to TIER_UNKNOWN honestly.
 */
export function parseFilesInScope(body: string | undefined): string[] {
  if (!body) return []
  const lines = body.split("\n")
  const out: string[] = []
  let inSection = false
  for (const line of lines) {
    if (/^#{1,6}\s*files?\s+in\s+scope/i.test(line)) { inSection = true; continue }
    if (inSection && /^#{1,6}\s+/.test(line)) break
    if (!inSection) continue
    const m = line.match(/^\s*[-*]\s+`?([A-Za-z0-9_\-./]+\.[A-Za-z0-9]+)`?/)
    if (m) out.push(m[1])
  }
  return [...new Set(out)]
}
