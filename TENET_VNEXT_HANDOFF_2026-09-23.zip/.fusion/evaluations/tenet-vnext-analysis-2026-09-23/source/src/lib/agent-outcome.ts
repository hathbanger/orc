/**
 * Agent outcome contract — one vocabulary every dispatch path reports in.
 *
 * Classifies what an agent run actually did from evidence that code owns
 * (exit status, artifact fingerprints, eval score), never from the worker's
 * own claim of success. Exit codes follow the Chadwick contract:
 * 0 completed, 3 refused, 4 truncated/turn-limited, 5 context exceeded.
 *
 * Gate mode (TENET_OUTCOME_GATE): "shadow" (default) classifies and records
 * every outcome but leaves each path's legacy verdict in force, so the
 * divergence between the two is measurable before "enforce" flips it.
 *
 * @purpose Verified agent-run outcomes for build-dispatch, flow engines and agent-session
 */

import { createHash } from "crypto"
import { appendFileSync, existsSync, mkdirSync, readFileSync } from "fs"
import { spawnSync } from "child_process"
import { dirname, join, resolve } from "path"

export type AgentOutcomeStatus =
  | "completed"
  | "unverified"
  | "refused"
  | "truncated"
  | "context_exceeded"
  | "failed"

export const OUTCOME_EXIT_CODES: Record<AgentOutcomeStatus, number> = {
  completed: 0,
  failed: 1,
  unverified: 2,
  refused: 3,
  truncated: 4,
  context_exceeded: 5,
}

export type OutcomeGateMode = "off" | "shadow" | "enforce"

export interface OutcomeEvidence {
  exitCode?: number | null
  signal?: string | null
  timedOut?: boolean
  /** The runtime reported hitting its turn cap (API runtimes expose this directly). */
  turnLimitHit?: boolean
  /** Combined stdout/stderr or log contents. Scanned for markers only. */
  output?: string
  /** Files the task must create or modify. */
  requiredFiles?: string[]
  /** "none" declares a task that legitimately produces no artifacts. */
  artifacts?: "required" | "none"
  changedFiles?: string[]
  fingerprintsBefore?: Record<string, string | null>
  fingerprintsAfter?: Record<string, string | null>
  eval?: { score?: number; success?: boolean }
}

export interface AgentOutcome {
  status: AgentOutcomeStatus
  exitCode: number | null
  changedFiles: string[]
  requiredFiles: string[]
  missingRequired: string[]
  evalScore?: number
  reasons: string[]
  classifiedAt: string
}

export interface OutcomeRecord {
  type: "build:outcome"
  ts: string
  path: "build-dispatch" | "flow-dag" | "flow-reactive" | "agent-session"
  agent: string
  status: AgentOutcomeStatus
  exitCode: number | null
  files: string[]
  missingRequired: string[]
  evalScore?: number
  reasons: string[]
  mode: OutcomeGateMode
  /** What the path would have decided on its own; diverges from status in shadow mode. */
  legacyVerdict?: string
  [key: string]: unknown
}

// Markers are deterministic string tests, not judgments: a marker only ever
// downgrades an exit-0 run to a more specific non-success status.
const CONTEXT_EXCEEDED_MARKERS = [
  /context[ _-]?(window|length)[ _-]?exceeded/i,
  /prompt is too long/i,
  /maximum context length/i,
  /context_length_exceeded/i,
]
const TRUNCATED_MARKERS = [
  /max(imum)? (number of )?turns/i,
  /turn limit (reached|exceeded)/i,
  /output (was )?truncated/i,
  /time budget exceeded/i,
]
const REFUSED_MARKERS = [
  /\bI (can't|cannot|won't|will not) (help with|do|assist with|comply)/i,
  /\brefus(e|ed|ing) to\b/i,
  /request (was )?declined/i,
]

function firstMarker(output: string | undefined, markers: RegExp[]): string | null {
  if (!output) return null
  for (const re of markers) {
    const m = output.match(re)
    if (m) return m[0]
  }
  return null
}

export function getOutcomeGateMode(env: NodeJS.ProcessEnv = process.env): OutcomeGateMode {
  const raw = (env.TENET_OUTCOME_GATE || "shadow").trim().toLowerCase()
  if (raw === "off" || raw === "enforce") return raw
  return "shadow"
}

export function shouldEnforceOutcome(env: NodeJS.ProcessEnv = process.env): boolean {
  return getOutcomeGateMode(env) === "enforce"
}

export function fingerprintFiles(root: string, files: string[]): Record<string, string | null> {
  const out: Record<string, string | null> = {}
  for (const f of files) {
    const full = resolve(root, f)
    try {
      out[f] = existsSync(full)
        ? createHash("sha256").update(readFileSync(full)).digest("hex")
        : null
    } catch {
      out[f] = null
    }
  }
  return out
}

/**
 * Tracked modifications plus untracked files, relative to `cwd`'s repo. Best
 * effort: a non-git directory yields [].
 */
export function changedFilesFromGit(cwd: string, base?: string): string[] {
  const run = (args: string[]) => {
    const r = spawnSync("git", args, { cwd, encoding: "utf-8", stdio: "pipe" })
    return r.status === 0 ? (r.stdout || "") : ""
  }
  const diffArgs = base ? ["diff", "--name-only", base] : ["diff", "--name-only", "HEAD"]
  const tracked = run(diffArgs)
  const untracked = run(["ls-files", "--others", "--exclude-standard"])
  const files = new Set<string>()
  for (const line of `${tracked}\n${untracked}`.split("\n")) {
    const f = line.trim()
    if (f) files.add(f)
  }
  return [...files].sort()
}

export function classifyAgentOutcome(evidence: OutcomeEvidence): AgentOutcome {
  const reasons: string[] = []
  const exitCode = evidence.exitCode ?? null
  const requiredFiles = evidence.requiredFiles ?? []
  const changedFiles = [...(evidence.changedFiles ?? [])].sort()
  const evalScore = evidence.eval?.score

  const missingRequired = requiredFiles.filter(f => {
    const before = evidence.fingerprintsBefore?.[f]
    const after = evidence.fingerprintsAfter?.[f]
    if (evidence.fingerprintsAfter && f in evidence.fingerprintsAfter) {
      return after === null || after === before
    }
    return !changedFiles.includes(f)
  })

  const finish = (status: AgentOutcomeStatus): AgentOutcome => ({
    status,
    exitCode,
    changedFiles,
    requiredFiles,
    missingRequired,
    evalScore,
    reasons,
    classifiedAt: new Date().toISOString(),
  })

  if (evidence.timedOut) {
    reasons.push("run exceeded its time budget")
    return finish("truncated")
  }
  if (evidence.signal) {
    reasons.push(`process killed by ${evidence.signal}`)
    return finish("failed")
  }
  if (evidence.turnLimitHit) {
    reasons.push("runtime hit its turn cap")
    return finish("truncated")
  }

  if (exitCode === OUTCOME_EXIT_CODES.refused) {
    reasons.push("exit code 3 (refused)")
    return finish("refused")
  }
  if (exitCode === OUTCOME_EXIT_CODES.truncated) {
    reasons.push("exit code 4 (truncated)")
    return finish("truncated")
  }
  if (exitCode === OUTCOME_EXIT_CODES.context_exceeded) {
    reasons.push("exit code 5 (context exceeded)")
    return finish("context_exceeded")
  }

  const ctxMarker = firstMarker(evidence.output, CONTEXT_EXCEEDED_MARKERS)
  if (ctxMarker) {
    reasons.push(`output marker: "${ctxMarker}"`)
    return finish("context_exceeded")
  }
  const truncMarker = firstMarker(evidence.output, TRUNCATED_MARKERS)
  if (truncMarker) {
    reasons.push(`output marker: "${truncMarker}"`)
    return finish("truncated")
  }
  const refusedMarker = firstMarker(evidence.output, REFUSED_MARKERS)
  if (refusedMarker && changedFiles.length === 0) {
    reasons.push(`output marker: "${refusedMarker}" with no changed files`)
    return finish("refused")
  }

  if (exitCode !== null && exitCode !== 0) {
    reasons.push(`exit code ${exitCode}`)
    return finish("failed")
  }
  if (evidence.eval && evidence.eval.success === false) {
    reasons.push("eval did not run cleanly")
    return finish("failed")
  }

  if (missingRequired.length > 0) {
    reasons.push(`required files unchanged: ${missingRequired.join(", ")}`)
    return finish("unverified")
  }
  if (requiredFiles.length > 0) {
    reasons.push(`all ${requiredFiles.length} required files changed`)
    return finish("completed")
  }
  if (evidence.artifacts === "none") {
    reasons.push("task declared no artifacts; exit 0")
    return finish("completed")
  }
  if (changedFiles.length > 0) {
    reasons.push(`${changedFiles.length} file(s) changed`)
    return finish("completed")
  }
  if (evalScore !== undefined) {
    reasons.push(`eval score ${evalScore} with no file changes`)
    return finish("completed")
  }
  reasons.push("exit 0 with no changed files and no eval evidence")
  return finish("unverified")
}

export function outcomeExitCode(outcome: AgentOutcome): number {
  return OUTCOME_EXIT_CODES[outcome.status]
}

export function buildJournalPath(projectRoot: string): string {
  return join(projectRoot, ".tenet", "build-journal.jsonl")
}

export function recordAgentOutcome(
  projectRoot: string,
  outcome: AgentOutcome,
  meta: {
    path: OutcomeRecord["path"]
    agent: string
    legacyVerdict?: string
    mode?: OutcomeGateMode
    [key: string]: unknown
  },
): OutcomeRecord {
  const { path: dispatchPath, agent, legacyVerdict, mode, ...extra } = meta
  const record: OutcomeRecord = {
    ...extra,
    type: "build:outcome",
    ts: new Date().toISOString(),
    path: dispatchPath,
    agent,
    status: outcome.status,
    exitCode: outcome.exitCode,
    files: outcome.changedFiles,
    missingRequired: outcome.missingRequired,
    evalScore: outcome.evalScore,
    reasons: outcome.reasons,
    mode: mode ?? getOutcomeGateMode(),
    legacyVerdict,
  }
  try {
    const journalPath = buildJournalPath(projectRoot)
    mkdirSync(dirname(journalPath), { recursive: true })
    appendFileSync(journalPath, JSON.stringify(record) + "\n")
  } catch {
    // Recording is best-effort; the classification is still returned.
  }
  return record
}
