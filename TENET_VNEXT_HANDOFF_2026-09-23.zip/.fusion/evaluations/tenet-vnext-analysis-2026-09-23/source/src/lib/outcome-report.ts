/**
 * Outcome report — how often the legacy per-path verdict and the verified
 * AgentOutcome disagree, from the build:outcome rows in build-journal.jsonl.
 *
 * "Optimistic divergence" is the headline: the path would have called the
 * run a success, the evidence says otherwise. That count on real runs is the
 * measurement that decides whether TENET_OUTCOME_GATE moves from shadow to
 * enforce.
 *
 * @purpose Shadow-mode divergence measurement for the agent outcome gate
 */

import { existsSync, readFileSync } from "fs"
import type { AgentOutcomeStatus, OutcomeRecord } from "./agent-outcome.js"
import { buildJournalPath } from "./agent-outcome.js"

/** Legacy verdicts that mean "this path would have treated the run as a success". */
const LEGACY_SUCCESS = new Set(["converged", "completed", "kept", "exit-0"])

export interface OutcomeBucket {
  total: number
  byStatus: Partial<Record<AgentOutcomeStatus, number>>
  /** Legacy said success, outcome says otherwise. */
  optimistic: number
  /** Legacy said failure, outcome says completed. */
  pessimistic: number
  /** Exit-0 runs with no verifiable evidence at all. */
  unverified: number
}

export interface OutcomeReport {
  total: number
  since?: string
  overall: OutcomeBucket
  byPath: Record<string, OutcomeBucket>
  byAgent: Record<string, OutcomeBucket>
  /** Most recent optimistic divergences, newest first. */
  divergences: OutcomeRecord[]
  byMode: Record<string, number>
}

export function loadOutcomes(projectRoot: string): OutcomeRecord[] {
  const p = buildJournalPath(projectRoot)
  if (!existsSync(p)) return []
  const rows: OutcomeRecord[] = []
  for (const line of readFileSync(p, "utf-8").split("\n")) {
    if (!line.trim()) continue
    try {
      const parsed = JSON.parse(line)
      if (parsed && parsed.type === "build:outcome" && typeof parsed.status === "string") rows.push(parsed)
    } catch {
      // Malformed line — skip, never fail the report.
    }
  }
  return rows
}

export function legacyClaimedSuccess(row: OutcomeRecord): boolean {
  return row.legacyVerdict !== undefined && LEGACY_SUCCESS.has(row.legacyVerdict)
}

export function isOptimisticDivergence(row: OutcomeRecord): boolean {
  return legacyClaimedSuccess(row) && row.status !== "completed"
}

export function isPessimisticDivergence(row: OutcomeRecord): boolean {
  return row.legacyVerdict !== undefined && !legacyClaimedSuccess(row) && row.status === "completed"
}

function emptyBucket(): OutcomeBucket {
  return { total: 0, byStatus: {}, optimistic: 0, pessimistic: 0, unverified: 0 }
}

function add(bucket: OutcomeBucket, row: OutcomeRecord): void {
  bucket.total++
  bucket.byStatus[row.status] = (bucket.byStatus[row.status] ?? 0) + 1
  if (isOptimisticDivergence(row)) bucket.optimistic++
  if (isPessimisticDivergence(row)) bucket.pessimistic++
  if (row.status === "unverified") bucket.unverified++
}

export function buildOutcomeReport(
  rows: OutcomeRecord[],
  options: { since?: string; path?: string; limit?: number } = {},
): OutcomeReport {
  const limit = options.limit ?? 20
  const filtered = rows.filter(r => {
    if (options.since && r.ts < options.since) return false
    if (options.path && r.path !== options.path) return false
    return true
  })

  const report: OutcomeReport = {
    total: filtered.length,
    since: options.since,
    overall: emptyBucket(),
    byPath: {},
    byAgent: {},
    divergences: [],
    byMode: {},
  }

  for (const row of filtered) {
    add(report.overall, row)
    report.byPath[row.path] ??= emptyBucket()
    add(report.byPath[row.path], row)
    report.byAgent[row.agent] ??= emptyBucket()
    add(report.byAgent[row.agent], row)
    report.byMode[row.mode] = (report.byMode[row.mode] ?? 0) + 1
  }

  report.divergences = filtered
    .filter(isOptimisticDivergence)
    .sort((a, b) => b.ts.localeCompare(a.ts))
    .slice(0, limit)

  return report
}

function pct(n: number, d: number): string {
  return d === 0 ? "—" : `${((n / d) * 100).toFixed(1)}%`
}

function bucketLine(name: string, b: OutcomeBucket): string {
  const statuses = Object.entries(b.byStatus)
    .sort((x, y) => y[1] - x[1])
    .map(([s, n]) => `${s}=${n}`)
    .join(" ")
  return `  ${name.padEnd(18)} n=${String(b.total).padStart(4)}  optimistic=${String(b.optimistic).padStart(3)} (${pct(b.optimistic, b.total)})  unverified=${String(b.unverified).padStart(3)}  ${statuses}`
}

export function formatOutcomeReport(report: OutcomeReport): string {
  const lines: string[] = []
  const o = report.overall
  lines.push(`Agent outcomes — ${report.total} recorded run(s)${report.since ? ` since ${report.since}` : ""}`)
  if (report.total === 0) {
    lines.push("  No build:outcome rows yet. Outcomes are recorded on every agent run (TENET_OUTCOME_GATE=shadow by default).")
    return lines.join("\n")
  }
  lines.push(`  optimistic divergence: ${o.optimistic}/${o.total} (${pct(o.optimistic, o.total)}) — legacy verdict said success, evidence did not`)
  lines.push(`  pessimistic divergence: ${o.pessimistic}/${o.total} (${pct(o.pessimistic, o.total)}) — legacy said failure, evidence says completed`)
  lines.push(`  unverified (exit 0, no evidence): ${o.unverified}/${o.total} (${pct(o.unverified, o.total)})`)
  lines.push(`  modes: ${Object.entries(report.byMode).map(([m, n]) => `${m}=${n}`).join(" ") || "—"}`)
  lines.push("")
  lines.push("By path:")
  for (const [name, b] of Object.entries(report.byPath).sort((x, y) => y[1].total - x[1].total)) lines.push(bucketLine(name, b))
  lines.push("")
  lines.push("By agent:")
  for (const [name, b] of Object.entries(report.byAgent).sort((x, y) => y[1].optimistic - x[1].optimistic || y[1].total - x[1].total).slice(0, 15)) {
    lines.push(bucketLine(name, b))
  }
  if (report.divergences.length > 0) {
    lines.push("")
    lines.push(`Recent optimistic divergences (${report.divergences.length}):`)
    for (const d of report.divergences) {
      lines.push(`  ${d.ts}  ${d.path.padEnd(14)} ${d.agent.padEnd(24)} legacy=${d.legacyVerdict} -> ${d.status}: ${d.reasons[0] ?? ""}`)
    }
  }
  return lines.join("\n")
}
