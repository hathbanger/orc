**Evaluator and parity counterexamples — September 23, 2026**

Companion: [evaluation analysis](/Users/alectaggart/orc/TENET_VNEXT_EVALUATION_ANALYSIS_2026-09-23.md).

The archived source is from CLI `b0ec9c4b`. Unlike the other review probes that import current checkouts, this probe prefers its adjacent `source/` snapshot. Its TypeScript compiler dependency comes from the installed CLI checkout. No model or network calls occur. It creates temporary source fixtures and writes its JSON result beside the script; product source and data are not changed.

```sh
node /Users/alectaggart/orc/.fusion/evaluations/tenet-vnext-analysis-2026-09-23/evaluator-probe.cjs
```

The archived-source rerun reproduced a reference score change from 2/13 to 13/13 after comment additions and a type-literal quote change, with identical emitted JavaScript for every changed file. A separate input pair with equal scores and unrelated failed requirements returned `parity`. These are counterexamples to evaluator adequacy, not proofs about all task evaluators or actual refusal behavior.

The script executes the actual reference `evaluate()` body with its CLI entrypoint omitted. It compares transpiled output with comments removed and records source hashes, individual changes and the scorer's output in `evaluator-probe.json`. Successful execution means the counterexamples ran, not that the product passed acceptance. Rerunning overwrites that receipt and changes temporary paths; copy it first to retain an exact historical comparison.

`manifest.json` identifies the reviewed revisions and SHA-256 hashes of archived source, script and receipt. Its `verification_rerun` records that the archived script was executed after its source lookup was adjusted for this directory.
