// Isolated source-loaded reproduction: sibling jfl-ide only, not CLI's shipped IDE.
const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { execFileSync } = require('node:child_process');
const root = '/Users/alectaggart/CascadeProjects/jfl-ide';
const ts = require(root + '/node_modules/typescript');
const calls = [];
const hashes = {};
const fakeFetch = async (url) => {
  calls.push(url);
  return { ok: true, json: async () => ({ events: [{ type: 'fixture:event' }], flows: [{ enabled: true }] }) };
};
function load(rel, injected = {}) {
  const source = fs.readFileSync(root + '/' + rel, 'utf8');
  hashes[rel] = crypto.createHash('sha256').update(source).digest('hex');
  const code = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText;
  const fixtureModule = { exports: {} };
  vm.runInNewContext(code, {
    exports: fixtureModule.exports,
    module: fixtureModule,
    require: name => name in injected ? injected[name] : require(name),
    fetch: fakeFetch,
    AbortSignal, setTimeout, clearTimeout, setInterval, clearInterval, console,
  }, { filename: rel });
  return fixtureModule.exports;
}
(async () => {
  const hub = load('src/hub-client.ts');
  const { DataPipeline } = load('src/data-pipeline.ts', {
    './hub-client.js': hub,
    './surface-registry.js': { readProjectConfig: () => ({}) },
  });
  const pipeline = new DataPipeline({}, '/fixture');
  await pipeline.pollHubData();
  const pipelineResult = { requests: calls.length, data: pipeline.getLiveData() };
  await hub.hubFetch('/api/events/recent?limit=100', { baseUrl: 'http://fixture.invalid' });
  assert.equal(pipelineResult.requests, 0, 'Expected sibling polling defect to reproduce');
  assert.equal(calls.length, 1, 'Configured positive control must issue one fake request');
  console.log(JSON.stringify({
    scope: 'sibling jfl-ide; not tenet-cli/src/lib/workspace',
    source: root,
    revision: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
    source_sha256: hashes,
    boundaries: 'Source transpiled into VM; network replaced with fakeFetch; no filesystem mutation or configuration reads',
    pipelinePolling: pipelineResult,
    explicitConfigPositiveControl: { requests: calls.length, urls: calls },
  }, null, 2));
})().catch(error => { console.error(error); process.exitCode = 1; });
