**TENET vNext platform/IDE evidence — September 23, 2026**

Companion analysis: [platform/UX report](/Users/alectaggart/orc/TENET_VNEXT_PLATFORM_UX_ANALYSIS_2026-09-23.md).

These are source-loaded isolated reproductions. They do not contact production, use credentials, load `.env`, install packages, launch paid agents, or mutate product data. Scripts use the existing TypeScript dependency in sibling `jfl-ide/node_modules`. Source revisions and SHA-256 hashes are included in each JSON receipt; the full source/context inventory is in `source-manifest.json`.

Run from this folder:

```sh
node ide-polling-probe.cjs > ide-polling-probe.json
node unified-search-probe.cjs > unified-search-probe.json
```

Scripts assert the reviewed defects are present. After a product repair they should fail, prompting replacement with a positive behavior test rather than being treated as permanent regression tests.

- `ide-polling-probe.cjs`: loads sibling `jfl-ide`'s actual DataPipeline and Hub helper. Polling has no config and makes zero requests; explicitly supplying config makes one fake request. This defect is **not attributed to shipped `tenet ide`**, which imports a diverged engine inside `tenet-cli/src/lib/workspace` and a different Hub helper. The shipped engine's separate `{flows}` versus array mismatch is source evidence in the report, not the result of this probe.
- `unified-search-probe.cjs`: loads platform's actual `/api/memory/unified-search` POST handler. Auth fixture is user A. Source-generated team query has no principal/project predicate; snapshot query is optionally caller-scoped. Fixture foreign team/snapshot rows reach the response with workspace omitted and explicitly foreign. Auth, SQL construction, storage and NextResponse are mocked; this establishes handler/query scope, not deployed exposure, SQL execution or PostgreSQL row-level security.
- `ide-typecheck.log`: sibling IDE `tsc --noEmit --incremental false`, command/working directory/exit code and raw output. Typecheck passed despite the polling seam. No assertion about shipped CLI typecheck follows from this result.
- `source-manifest.json`: HEAD revisions and source SHA-256 inventory for the probed sources and adjacent shipped-vs-sibling/API contracts, plus script hashes.

Captured receipts reproduce the original in-memory probes; only archive/provenance fields and assertions were added. No production source was changed by archiving.
