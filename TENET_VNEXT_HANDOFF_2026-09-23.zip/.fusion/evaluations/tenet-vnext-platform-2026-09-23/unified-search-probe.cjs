// Isolated source-handler/query-scope reproduction. No live credentials or database.
const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { execFileSync } = require('node:child_process');
const ts = require('/Users/alectaggart/CascadeProjects/jfl-ide/node_modules/typescript');
const root = '/Users/alectaggart/CascadeProjects/jfl-platform';
const relativeFile = 'src/app/api/memory/unified-search/route.ts';
const file = root + '/' + relativeFile;
const source = fs.readFileSync(file, 'utf8');
const code = ts.transpileModule(source, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText;
const queries = [];
// SQL tag is a printable fixture query, not a real SQL builder/database driver.
const sql = (strings, ...values) => strings.reduce((acc, text, i) => acc + text +
  (i < values.length ? typeof values[i] === 'string' ? JSON.stringify(values[i]) : String(values[i]) : ''), '');
const db = { execute: async query => {
  queries.push(query);
  if (query.includes('FROM team_memories')) return [{
    id: 'foreign-team', type: 'fact', content: 'FOREIGN_TEAM_SENTINEL',
    source_file: 'private.md', created_at: '2026-09-23',
  }];
  if (query.includes('FROM workspace_sync')) return [{
    workspace: 'foreign-workspace', data_type: 'journal',
    data: [{ summary: 'FOREIGN_SYNC_SENTINEL' }], synced_at: '2026-09-23',
  }];
  return [];
} };
const fixtureModule = { exports: {} };
const deps = {
  'next/server': { NextResponse: { json: (body, options = {}) => ({ status: options.status || 200, body }) } },
  '@/lib/auth/tenet-auth': { requireTenetAuth: async () => ({ id: 'user-a' }) },
  '@/lib/db': { db },
  'drizzle-orm': { sql },
  'openai': class { constructor() { throw new Error('Unexpected embedding use'); } },
};
vm.runInNewContext(code, {
  exports: fixtureModule.exports,
  module: fixtureModule,
  require: name => { if (name in deps) return deps[name]; throw new Error(name); },
  process: { env: {} },
  console,
}, { filename: file });
(async () => {
  const results = [];
  for (const workspace of [undefined, 'foreign-workspace']) {
    const response = await fixtureModule.exports.POST({ json: async () => ({ query: 'sentinel', workspace }) });
    assert.equal(response.status, 200);
    assert.equal(response.body.sources.team, 1);
    assert.equal(response.body.sources.sync, 1);
    results.push({
      workspace: workspace || '(omitted)', status: response.status, sources: response.body.sources,
      results: response.body.results.map(result => ({ id: result.id, content: result.content, workspace: result.workspace })),
    });
  }
  const teamQuery = queries.find(query => query.includes('FROM team_memories'));
  const unscopedSyncQuery = queries.find(query => query.includes('FROM workspace_sync'));
  assert.ok(!teamQuery.includes('project_id') && !teamQuery.includes('user-a'));
  assert.ok(!unscopedSyncQuery.includes('user-a') && !unscopedSyncQuery.includes('workspace_members'));
  console.log(JSON.stringify({
    source: file,
    revision: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
    source_sha256: { [relativeFile]: crypto.createHash('sha256').update(source).digest('hex') },
    boundaries: 'Actual handler in VM; auth, SQL tag, database, NextResponse and OpenAI mocked; process.env empty; no network or production data',
    authenticatedUser: 'user-a', fixtureResults: results, teamQuery, unscopedSyncQuery,
  }, null, 2));
})().catch(error => { console.error(error); process.exitCode = 1; });
