TENET vNext analysis and handoff — 2026-09-23

Start with TENET_VNEXT_ANALYSIS_2026-09-23.md. It contains architecture decisions, current findings, the Oasis operating method, release gates, cleanup and unresolved experiments. Four companion investigations provide source links and reproductions. Earlier review/dogfood reports are included for context.

New probe evidence is under .fusion/evaluations/tenet-vnext-*. Read each README before rerunning: some scripts import the current absolute source checkouts, others use archived sources. They are diagnostic fixtures, not a claim that the combined product was implemented or deployed. Historical source revisions are retained; concurrent fixes are acknowledged in the reports.

Source and report links use the original local /Users/alectaggart paths for this workspace. When sharing to another machine, adjust paths or navigate the included reports by filename. This bundle contains the new probes and earlier reports, not the full repositories or every older review artifact.

No production source/configuration changes, deployments, paid coding sessions or training jobs were performed by this analysis.
